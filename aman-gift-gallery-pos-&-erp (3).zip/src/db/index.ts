import Dexie, { Table } from 'dexie';
import { 
  Product, 
  Invoice, 
  PurchaseEntry, 
  Party, 
  KhataTransaction, 
  WastageEntry, 
  ShopProfile,
  GoogleSheetsSyncConfig
} from '../types';

export class RetailDatabase extends Dexie {
  products!: Table<Product, number>;
  invoices!: Table<Invoice, number>;
  purchases!: Table<PurchaseEntry, number>;
  parties!: Table<Party, number>;
  khataTransactions!: Table<KhataTransaction, number>;
  wastage!: Table<WastageEntry, number>;
  settings!: Table<{ key: string; value: any }, string>;

  constructor() {
    super('AmanGiftGalleryPOS_DB');
    
    this.version(1).stores({
      products: '++id, barcode, name, brand, category, stockQty, mrp, sellingPrice, updatedAt',
      invoices: '++id, invoiceNumber, date, customerPhone, grandTotal, paymentMethod, isExchangeBill, createdAt',
      purchases: '++id, voucherNo, supplierName, billDate, totalBillAmount, source, createdAt',
      parties: '++id, name, phone, type, balance, isArchived, updatedAt',
      khataTransactions: '++id, partyId, partyName, partyType, date, type, createdAt',
      wastage: '++id, productId, date, reason',
      settings: 'key'
    });
  }
}

export const db = new RetailDatabase();

export const DEFAULT_SHOP_PROFILE: ShopProfile = {
  name: 'Aman Gift Gallery',
  tagline: 'An Exclusive Gift, Crockery, Toy & Home Essentials Gallery',
  address: 'Shop No. 12-14, Upper Bazar, Main Road',
  city: 'Ranchi',
  state: 'Jharkhand',
  pincode: '834001',
  phone: '+91 98351 23456',
  altPhone: '+91 94311 78900',
  email: 'amangiftgallery.ranchi@gmail.com',
  gstin: '',
  bankName: 'State Bank of India (Main Branch Ranchi)',
  accountNo: '30491823901',
  ifscCode: 'SBIN0000167',
  upiId: 'amangifts.ranchi@sbi',
  footerDisclaimer: 'Warranty is valid only on Manufacturing Defects. Physical/Accidental Damage is strictly non-refundable. Goods once sold can be exchanged within 7 days with original invoice.',
  logoUrl: '',
  signatureUrl: ''
};

export const INITIAL_PRODUCTS: Omit<Product, 'id'>[] = [
  {
    barcode: '890123456001',
    name: 'Milton Thermosteel Flip Lid Flask 1000ml (Matte Black)',
    brand: 'Milton',
    category: 'Bottles / Flasks',
    hsn: '96170011',
    stockQty: 24,
    minThreshold: 4,
    basicPurchaseRate: 610,
    gstPercent: 18,
    landingCost: 719.8,
    mrp: 1099,
    sellingPrice: 949,
    lastPurchaseDate: '2026-08-15',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456002',
    name: 'Milton Spotzero Compact Spin Mop with Bucket',
    brand: 'Milton',
    category: 'Home Essentials',
    hsn: '96039000',
    stockQty: 8,
    minThreshold: 3,
    basicPurchaseRate: 850,
    gstPercent: 18,
    landingCost: 1003,
    mrp: 1599,
    sellingPrice: 1349,
    lastPurchaseDate: '2026-08-10',
    lastSoldDate: '2026-08-23',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-23'
  },
  {
    barcode: '890123456003',
    name: 'Cello Opalware Dazzle Tropical Dinner Set (18 Pcs)',
    brand: 'Cello',
    category: 'Crockery',
    hsn: '69111019',
    stockQty: 14,
    minThreshold: 3,
    basicPurchaseRate: 1100,
    gstPercent: 12,
    landingCost: 1232,
    mrp: 1899,
    sellingPrice: 1649,
    lastPurchaseDate: '2026-08-12',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456004',
    name: 'Cello Puro Steel-X Insulated Water Bottle 750ml',
    brand: 'Cello',
    category: 'Bottles / Flasks',
    hsn: '96170011',
    stockQty: 32,
    minThreshold: 5,
    basicPurchaseRate: 280,
    gstPercent: 18,
    landingCost: 330.4,
    mrp: 499,
    sellingPrice: 420,
    lastPurchaseDate: '2026-08-18',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456005',
    name: 'Borosil Vision Classic Glass Tumbler Set of 6 (295ml)',
    brand: 'Borosil',
    category: 'Crockery',
    hsn: '70133700',
    stockQty: 2, // Low stock alert trigger
    minThreshold: 4,
    basicPurchaseRate: 290,
    gstPercent: 12,
    landingCost: 324.8,
    mrp: 525,
    sellingPrice: 440,
    lastPurchaseDate: '2026-07-20',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-07-15',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456006',
    name: 'Borosil Klip N Store Microwave Safe Glass Lunch Box (Set of 3)',
    brand: 'Borosil',
    category: 'Home Essentials',
    hsn: '70134900',
    stockQty: 18,
    minThreshold: 3,
    basicPurchaseRate: 780,
    gstPercent: 12,
    landingCost: 873.6,
    mrp: 1395,
    sellingPrice: 1199,
    lastPurchaseDate: '2026-08-05',
    lastSoldDate: '2026-08-22',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-22'
  },
  {
    barcode: '890123456007',
    name: 'Treo by Milton Bistro Glass Mixing Bowl 1500ml',
    brand: 'Treo',
    category: 'Crockery',
    hsn: '70134900',
    stockQty: 11,
    minThreshold: 2,
    basicPurchaseRate: 210,
    gstPercent: 12,
    landingCost: 235.2,
    mrp: 375,
    sellingPrice: 310,
    lastPurchaseDate: '2026-08-01',
    lastSoldDate: '2026-08-21',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-21'
  },
  {
    barcode: '890123456008',
    name: 'Pigeon Handy Chopper Plus with 3 Stainless Blades 400ml',
    brand: 'Pigeon',
    category: 'Home Essentials',
    hsn: '82055100',
    stockQty: 1, // Critical low stock
    minThreshold: 5,
    basicPurchaseRate: 140,
    gstPercent: 18,
    landingCost: 165.2,
    mrp: 345,
    sellingPrice: 260,
    lastPurchaseDate: '2026-07-28',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-07-15',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456009',
    name: 'Nayasa Orbit Insulated 3-Tier Lunch Box with Jacket',
    brand: 'Nayasa',
    category: 'Plastics',
    hsn: '39241010',
    stockQty: 16,
    minThreshold: 3,
    basicPurchaseRate: 360,
    gstPercent: 18,
    landingCost: 424.8,
    mrp: 699,
    sellingPrice: 580,
    lastPurchaseDate: '2026-08-14',
    lastSoldDate: '2026-08-20',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-20'
  },
  {
    barcode: '890123456010',
    name: 'Hot Mugs Premium Ceramic Coffee Mug Set with Golden Spoon (Gift Box)',
    brand: 'Hot Mugs',
    category: 'Gifts',
    hsn: '69120040',
    stockQty: 28,
    minThreshold: 4,
    basicPurchaseRate: 190,
    gstPercent: 12,
    landingCost: 212.8,
    mrp: 499,
    sellingPrice: 380,
    lastPurchaseDate: '2026-08-16',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456011',
    name: 'Hot Wheels 5-Car Collector Gift Pack (Original Mattel)',
    brand: 'Hot Wheels',
    category: 'Toys',
    hsn: '95030030',
    stockQty: 22,
    minThreshold: 4,
    basicPurchaseRate: 480,
    gstPercent: 18,
    landingCost: 566.4,
    mrp: 849,
    sellingPrice: 749,
    lastPurchaseDate: '2026-08-10',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-24'
  },
  {
    barcode: '890123456012',
    name: 'Fisher-Price Rock-a-Stack Classic Colorful Rings Infant Toy',
    brand: 'Fisher-Price',
    category: 'Toys',
    hsn: '95030010',
    stockQty: 12,
    minThreshold: 3,
    basicPurchaseRate: 230,
    gstPercent: 18,
    landingCost: 271.4,
    mrp: 449,
    sellingPrice: 379,
    lastPurchaseDate: '2026-08-08',
    lastSoldDate: '2026-08-19',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-19'
  },
  {
    barcode: '890123456013',
    name: 'Handcrafted Antique Brass Peacock Diya with Bells (Home Decor Gift)',
    brand: 'Unbranded',
    category: 'Gifts',
    hsn: '74198030',
    stockQty: 7,
    minThreshold: 2,
    basicPurchaseRate: 550,
    gstPercent: 12,
    landingCost: 616,
    mrp: 1250,
    sellingPrice: 990,
    lastPurchaseDate: '2026-08-02',
    lastSoldDate: '2026-08-23',
    isUnbranded: true,
    createdAt: '2026-08-01',
    updatedAt: '2026-08-23'
  },
  {
    barcode: '890123456014',
    name: 'Crystal Glass Flower Vase 12 Inch (Royal Bohemia Style)',
    brand: 'Unbranded',
    category: 'Gifts',
    hsn: '70139900',
    stockQty: 9,
    minThreshold: 2,
    basicPurchaseRate: 340,
    gstPercent: 18,
    landingCost: 401.2,
    mrp: 799,
    sellingPrice: 650,
    lastPurchaseDate: '2026-05-10', // Dead stock item (zero sales in >60 days)
    lastSoldDate: '2026-05-15',
    isUnbranded: true,
    createdAt: '2026-05-01',
    updatedAt: '2026-05-15'
  },
  {
    barcode: '890123456015',
    name: 'Rechargeable LED Desk Lamp with 3 Color Modes & Touch Dimmer',
    brand: 'Generic Electronics',
    category: 'Electronics',
    hsn: '85131010',
    stockQty: 15,
    minThreshold: 3,
    basicPurchaseRate: 260,
    gstPercent: 18,
    landingCost: 306.8,
    mrp: 599,
    sellingPrice: 480,
    lastPurchaseDate: '2026-08-11',
    lastSoldDate: '2026-08-24',
    createdAt: '2026-08-01',
    updatedAt: '2026-08-24'
  }
];

export const INITIAL_PARTIES: Omit<Party, 'id'>[] = [
  {
    type: 'customer',
    name: 'Rajesh Agarwal (Upper Bazar)',
    phone: '9835112233',
    address: 'Near Kali Mandir, Upper Bazar, Ranchi',
    balance: 1450, // Customer owes shop (Receivable)
    createdAt: '2026-08-01',
    updatedAt: '2026-08-20'
  },
  {
    type: 'customer',
    name: 'Dr. Priya Sharma (Lalpur)',
    phone: '9431155667',
    address: 'Circular Road, Lalpur, Ranchi',
    balance: 0, // Settled
    isArchived: true,
    createdAt: '2026-08-05',
    updatedAt: '2026-08-18'
  },
  {
    type: 'customer',
    name: 'Vikram Singh (Doranda)',
    phone: '8709123456',
    address: 'South Office Para, Doranda, Ranchi',
    balance: 850,
    createdAt: '2026-08-10',
    updatedAt: '2026-08-22'
  },
  {
    type: 'supplier',
    name: 'Apex Crockery & Glass Distributors',
    phone: '9835009988',
    address: 'Main Road, Near Overbridge, Ranchi',
    gstin: '20AABCA1234F1Z8',
    balance: -14500, // Shop owes supplier (Payable)
    createdAt: '2026-07-01',
    updatedAt: '2026-08-15'
  },
  {
    type: 'supplier',
    name: 'National Plastic & Milton Agency',
    phone: '9431100223',
    address: 'Daily Market, Ranchi',
    gstin: '20BBAPA4455G1Z2',
    balance: -8200,
    createdAt: '2026-07-05',
    updatedAt: '2026-08-18'
  }
];

export async function initializeDatabase() {
  const existingProfile = await db.settings.get('shopProfile');
  if (!existingProfile) {
    await db.settings.put({
      key: 'shopProfile',
      value: DEFAULT_SHOP_PROFILE
    });
  }
}

