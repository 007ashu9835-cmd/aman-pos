import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { getTranslation } from '../../utils/translations';
import { db } from '../../db';
import { Party, KhataTransaction } from '../../types';
import { formatCurrency } from '../../utils/calculations';
import { 
  Users2, 
  Search, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Share2, 
  Phone, 
  IndianRupee, 
  Calendar, 
  Check, 
  FileText,
  UserCheck
} from 'lucide-react';

export const KhataModule: React.FC = () => {
  const { language, shopProfile, products } = useApp();
  const t = getTranslation(language);

  const [parties, setParties] = useState<Party[]>([]);
  const [transactions, setTransactions] = useState<KhataTransaction[]>([]);
  const [selectedParty, setSelectedParty] = useState<Party | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [partyTypeFilter, setPartyTypeFilter] = useState<'all' | 'customer' | 'supplier'>('all');

  // New Party Modal
  const [newPartyModalOpen, setNewPartyModalOpen] = useState(false);
  const [newPartyName, setNewPartyName] = useState('');
  const [newPartyPhone, setNewPartyPhone] = useState('');
  const [newPartyType, setNewPartyType] = useState<'customer' | 'supplier'>('customer');
  const [newPartyAddress, setNewPartyAddress] = useState('');

  // New Entry Modal
  const [entryModalOpen, setEntryModalOpen] = useState(false);
  const [entryType, setEntryType] = useState<'gave' | 'got'>('gave'); // gave = gave/udhar, got = payment received
  const [entryAmount, setEntryAmount] = useState<number>(500);
  const [entryDescription, setEntryDescription] = useState('');

  const loadData = async () => {
    const pts = await db.parties.toArray();
    const txs = await db.khataTransactions.reverse().toArray();
    setParties(pts);
    setTransactions(txs);
    if (selectedParty) {
      const refreshed = pts.find(p => p.id === selectedParty.id) || null;
      setSelectedParty(refreshed);
    }
  };

  useEffect(() => {
    loadData();
  }, [products]);

  // Filtered Parties
  const filteredParties = useMemo(() => {
    return parties.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.phone.includes(searchTerm);
      const matchesType = partyTypeFilter === 'all' || p.type === partyTypeFilter;
      return matchesSearch && matchesType;
    });
  }, [parties, searchTerm, partyTypeFilter]);

  // Selected party's transaction log
  const partyTransactions = useMemo(() => {
    if (!selectedParty?.id) return [];
    return transactions.filter(t => t.partyId === selectedParty.id);
  }, [transactions, selectedParty]);

  // Total Receivables & Payables
  const totalReceivable = useMemo(() => {
    return parties.filter(p => p.type === 'customer' && p.balance > 0).reduce((s, p) => s + p.balance, 0);
  }, [parties]);

  const totalPayable = useMemo(() => {
    return parties.filter(p => p.type === 'supplier' && p.balance < 0).reduce((s, p) => s + Math.abs(p.balance), 0);
  }, [parties]);

  // Save New Party
  const handleCreateParty = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPartyName.trim()) return;

    const newId = await db.parties.add({
      name: newPartyName.trim(),
      phone: newPartyPhone.trim(),
      type: newPartyType,
      address: newPartyAddress.trim(),
      balance: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    setNewPartyName('');
    setNewPartyPhone('');
    setNewPartyAddress('');
    setNewPartyModalOpen(false);
    await loadData();
    const created = (await db.parties.get(newId)) || null;
    setSelectedParty(created);
  };

  // Add Transaction Entry (You Gave vs You Got)
  const handleAddTransaction = async () => {
    if (!selectedParty?.id || entryAmount <= 0) return;

    const prevBal = selectedParty.balance;
    // For customer: gave = udhar given (+balance), got = payment received (-balance)
    // For supplier: gave = payment paid to supplier (+balance toward zero), got = goods received (-balance)
    let newBal = prevBal;
    if (selectedParty.type === 'customer') {
      newBal = entryType === 'gave' ? prevBal + entryAmount : prevBal - entryAmount;
    } else {
      newBal = entryType === 'gave' ? prevBal + entryAmount : prevBal - entryAmount;
    }

    await db.khataTransactions.add({
      partyId: selectedParty.id,
      partyName: selectedParty.name,
      partyType: selectedParty.type,
      amount: entryAmount,
      type: entryType,
      notes: entryDescription || (entryType === 'gave' ? 'उधार दिया / Goods Issued' : 'भुगतान प्राप्त / Payment Received'),
      date: new Date().toISOString().split('T')[0],
      paymentMode: 'cash',
      createdAt: new Date().toISOString()
    });

    await db.parties.update(selectedParty.id, {
      balance: newBal,
      updatedAt: new Date().toISOString()
    });

    setEntryModalOpen(false);
    setEntryDescription('');
    await loadData();
  };

  // 1-Click WhatsApp Reminder
  const handleSendWhatsAppReminder = (party: Party) => {
    const text = `*Payment Reminder from ${shopProfile.name}*
Namaste ${party.name} ji,
Your current pending balance at our store is *₹${Math.abs(party.balance).toFixed(2)}*.
Please clear the balance at your earliest convenience via Cash / UPI (${shopProfile.phone}).
Thank you for your business!`;

    window.open(`https://wa.me/91${party.phone.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto overflow-y-auto bg-slate-50">
      {/* Header with Balance Summary */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Users2 className="w-5 h-5 text-red-600" />
            <h2 className="text-xl font-black text-slate-900">
              Khata / Party Ledger
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {language === 'hi' 
              ? 'ग्राहकों और सप्लायरों का डिजिटल उधार-जमा हिसाब व 1-क्लिक व्हाट्सएप रिमाइंडर्स' 
              : 'Customer & vendor credit balance tracking + 1-click WhatsApp reminders'}
          </p>
        </div>

        <button
          onClick={() => setNewPartyModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold rounded-xl shadow-lg shadow-red-600/30 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'hi' ? 'नया खाता जोड़ें' : 'Add New Party / Khata'}</span>
        </button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 p-5 rounded-2xl flex justify-between items-center shadow-xs">
          <div>
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              {language === 'hi' ? 'बाजार से कुल लेना (You Will Get / Receivable)' : 'Total Receivable (You Will Get)'}
            </span>
            <h3 className="text-2xl font-black text-slate-900 mt-1">{formatCurrency(totalReceivable)}</h3>
            <p className="text-[11px] text-slate-500 font-medium mt-1">Pending from regular customers</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl border border-emerald-200">
            <ArrowDownLeft className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-5 rounded-2xl flex justify-between items-center shadow-xs">
          <div>
            <span className="text-xs font-bold text-red-700 uppercase tracking-wider">
              {language === 'hi' ? 'सप्लायरों को देना (You Will Pay / Payable)' : 'Total Payable (You Will Pay)'}
            </span>
            <h3 className="text-2xl font-black text-slate-900 mt-1">{formatCurrency(totalPayable)}</h3>
            <p className="text-[11px] text-slate-500 font-medium mt-1">Due to Milton/Cello distributors</p>
          </div>
          <div className="p-3 bg-red-50 text-red-600 rounded-xl border border-red-200">
            <ArrowUpRight className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Ledger Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT: Parties Directory */}
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col h-[560px] shadow-xs">
          <div className="p-3.5 border-b border-slate-200 space-y-2 bg-slate-50">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search party by name or phone..."
                className="w-full bg-white border border-slate-300 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-red-600"
              />
            </div>

            <div className="flex gap-1 bg-slate-200/60 p-1 rounded-xl">
              <button
                onClick={() => setPartyTypeFilter('all')}
                className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition cursor-pointer ${partyTypeFilter === 'all' ? 'bg-red-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                All
              </button>
              <button
                onClick={() => setPartyTypeFilter('customer')}
                className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition cursor-pointer ${partyTypeFilter === 'customer' ? 'bg-red-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Customers
              </button>
              <button
                onClick={() => setPartyTypeFilter('supplier')}
                className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition cursor-pointer ${partyTypeFilter === 'supplier' ? 'bg-red-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Suppliers
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filteredParties.map((p) => {
              const isSelected = selectedParty?.id === p.id;
              const absBal = Math.abs(p.balance);
              return (
                <div
                  key={p.id}
                  onClick={() => setSelectedParty(p)}
                  className={`p-3 flex justify-between items-center cursor-pointer transition ${
                    isSelected ? 'bg-red-50/80 border-l-4 border-red-600' : 'hover:bg-slate-50'
                  }`}
                >
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{p.name}</h4>
                    <p className="text-[10px] text-slate-500 flex items-center gap-1 font-medium mt-0.5">
                      <Phone className="w-2.5 h-2.5 text-slate-400" /> {p.phone || 'No phone'}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className={`text-xs font-black ${absBal > 0 ? (p.type === 'customer' ? 'text-emerald-700' : 'text-red-600') : 'text-slate-400'}`}>
                      ₹{absBal.toFixed(0)}
                    </span>
                    <p className="text-[9px] uppercase tracking-wider text-slate-500 font-bold">{p.type}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT: Active Selected Party Ledger & Actions */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 flex flex-col h-[560px] shadow-xs">
          {selectedParty ? (
            <div className="flex-1 flex flex-col justify-between space-y-4 overflow-hidden">
              {/* Party Header Bar */}
              <div className="flex flex-wrap justify-between items-start border-b border-slate-200 pb-4 gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-lg text-slate-900">{selectedParty.name}</h3>
                    <span className="text-[10px] font-bold uppercase bg-red-100 text-red-700 px-2 py-0.5 rounded-sm border border-red-200">
                      {selectedParty.type}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Ph: {selectedParty.phone} {selectedParty.address && `• ${selectedParty.address}`}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {Math.abs(selectedParty.balance) > 0 && selectedParty.phone && (
                    <button
                      onClick={() => handleSendWhatsAppReminder(selectedParty)}
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs shadow-emerald-600/20 transition cursor-pointer"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>{language === 'hi' ? 'तगादा / रिमाइंड भेजें' : 'WhatsApp Reminder'}</span>
                    </button>
                  )}
                  <div className="bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-200 text-right">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">Net Balance</span>
                    <p className={`text-base font-black ${selectedParty.balance !== 0 ? (selectedParty.type === 'customer' ? 'text-emerald-700' : 'text-red-600') : 'text-slate-400'}`}>
                      ₹{Math.abs(selectedParty.balance).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Transactions List */}
              <div className="flex-1 overflow-y-auto divide-y divide-slate-100 pr-1 space-y-1">
                {partyTransactions.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-xs text-slate-400">
                    No transactions recorded for this party yet.
                  </div>
                ) : (
                  partyTransactions.map((tx) => (
                    <div key={tx.id} className="py-2.5 flex justify-between items-center text-xs hover:bg-slate-50 px-2 rounded-lg transition">
                      <div>
                        <p className="font-bold text-slate-900">{tx.notes || (tx.type === 'gave' ? 'Gave / Debit' : 'Got / Payment')}</p>
                        <p className="text-[10px] text-slate-500 font-medium">{tx.date}</p>
                      </div>
                      <div className="text-right">
                        <span className={`font-black text-sm ${tx.type === 'gave' ? 'text-red-600' : 'text-emerald-700'}`}>
                          {tx.type === 'gave' ? '+₹' : '-₹'}{tx.amount.toFixed(2)}
                        </span>
                        <p className="text-[9px] text-slate-500 font-medium">{tx.type === 'gave' ? 'Gave (Red)' : 'Got (Green)'}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Bottom Action Bar (Gave / Got buttons) */}
              <div className="pt-3 border-t border-slate-200 grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    setEntryType('gave');
                    setEntryModalOpen(true);
                  }}
                  className="py-2.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-xs shadow-red-600/30 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>{language === 'hi' ? 'उधार दिया (You Gave)' : 'You Gave (Credit)'}</span>
                </button>

                <button
                  onClick={() => {
                    setEntryType('got');
                    setEntryModalOpen(true);
                  }}
                  className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs shadow-emerald-600/30 flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <ArrowDownLeft className="w-4 h-4" />
                  <span>{language === 'hi' ? 'पैसा मिला (You Got)' : 'You Got (Payment)'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs">
              <Users2 className="w-10 h-10 opacity-30 mb-2 text-slate-400" />
              <p>Select a party from the left list to view their ledger entries.</p>
            </div>
          )}
        </div>
      </div>

      {/* CREATE NEW PARTY MODAL */}
      {newPartyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 text-slate-900 shadow-2xl space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3">
              <h3 className="font-bold text-base text-slate-900">Create New Customer / Supplier Party</h3>
              <button onClick={() => setNewPartyModalOpen(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleCreateParty} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-600 font-medium block mb-1">Party Name *</label>
                <input
                  type="text"
                  required
                  value={newPartyName}
                  onChange={(e) => setNewPartyName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar / City Distributors"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Party Type *</label>
                <select
                  value={newPartyType}
                  onChange={(e) => setNewPartyType(e.target.value as 'customer' | 'supplier')}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
                >
                  <option value="customer">Retail Customer (ग्राहक)</option>
                  <option value="supplier">Distributor / Supplier (सप्लायर)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Phone Number (WhatsApp)</label>
                <input
                  type="tel"
                  value={newPartyPhone}
                  onChange={(e) => setNewPartyPhone(e.target.value)}
                  placeholder="9876543210"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Address / Locality</label>
                <input
                  type="text"
                  value={newPartyAddress}
                  onChange={(e) => setNewPartyAddress(e.target.value)}
                  placeholder="e.g. Kanke Road, Ranchi"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-red-600/30 transition mt-3 cursor-pointer"
              >
                Save Party
              </button>
            </form>
          </div>
        </div>
      )}

      {/* RECORD TRANSACTION MODAL */}
      {entryModalOpen && selectedParty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 text-slate-900 shadow-2xl space-y-4 animate-fade-in">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3">
              <h3 className="font-bold text-base text-slate-900">
                {entryType === 'gave' ? 'Record Credit Given (उधार दिया)' : 'Record Payment Received (पैसा मिला)'}
              </h3>
              <button onClick={() => setEntryModalOpen(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-600 font-medium block mb-1">Amount (₹) *</label>
                <input
                  type="number"
                  min="1"
                  value={entryAmount}
                  onChange={(e) => setEntryAmount(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-black text-xl text-emerald-700 focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Description / Bill Ref:</label>
                <input
                  type="text"
                  value={entryDescription}
                  onChange={(e) => setEntryDescription(e.target.value)}
                  placeholder="e.g. Borosil dinner set balance or UPI transfer"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <button
                onClick={handleAddTransaction}
                className={`w-full py-3 text-white font-extrabold text-xs rounded-xl shadow-lg transition mt-3 cursor-pointer ${
                  entryType === 'gave' ? 'bg-red-600 hover:bg-red-700 shadow-red-600/30' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/30'
                }`}
              >
                Confirm Transaction Entry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
