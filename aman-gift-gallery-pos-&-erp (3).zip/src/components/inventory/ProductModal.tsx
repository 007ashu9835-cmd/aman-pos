import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, ItemCategory } from '../../types';
import { calculateLandingCost } from '../../utils/calculations';
import { decodeBarcodeFromImage, playScanAudioTone } from '../../utils/barcodeImageDecoder';
import { 
  findMatchingProduct, 
  mergeWithExistingProduct, 
  inferBrandFromName, 
  inferCategoryFromName 
} from '../../utils/aiSyncEngine';
import { 
  X, 
  Camera, 
  Zap, 
  Barcode, 
  Check, 
  Loader2, 
  GitMerge, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  ChevronDown,
  Sparkles
} from 'lucide-react';

export const DEFAULT_CATEGORIES = ['Perfumes', 'Gifts', 'Crockery', 'Toys', 'Plastics', 'Books', 'General'];

export const CATEGORY_TAX_MAP: Record<string, { hsn: string; gstRate: number }> = {
  'Perfumes': { hsn: '3303', gstRate: 18 },
  'Toys': { hsn: '9503', gstRate: 12 },
  'Plastics': { hsn: '3924', gstRate: 18 },
  'Crockery': { hsn: '7013', gstRate: 12 },
  'Gifts': { hsn: '3926', gstRate: 18 },
  'Books': { hsn: '4901', gstRate: 0 },
  'General': { hsn: '3924', gstRate: 18 }
};

interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  productToEdit?: Product | null;
  onSave?: (product: Product | Omit<Product, 'id'>) => Promise<void> | void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  onClose,
  productToEdit,
  onSave
}) => {
  const { 
    products,
    addProduct, 
    updateProduct, 
    openCameraScanner, 
    playBeep,
    language,
    masterCategories,
    addCategory
  } = useApp();

  // Form states
  const [barcode, setBarcode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('General');
  const [vendor, setVendor] = useState('General');
  const [hsn, setHsn] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [mrp, setMrp] = useState('');
  const [gstPercent, setGstPercent] = useState<number>(18);
  const [quantity, setQuantity] = useState('');
  const [minThreshold, setMinThreshold] = useState('3');
  const [autoMergeDuplicate, setAutoMergeDuplicate] = useState<boolean>(true);

  // Vendor / Supplier suggestions list
  const vendorSuggestions = useMemo(() => {
    const vSet = new Set<string>();
    vSet.add('General');
    products.forEach((p) => {
      if (p.vendor && p.vendor.trim() && p.vendor !== 'General') {
        vSet.add(p.vendor.trim());
      }
    });
    return Array.from(vSet);
  }, [products]);

  // Custom Categories from localStorage
  const [customCategories, setCustomCategories] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pos_custom_categories');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Could not read pos_custom_categories from localStorage', e);
    }
    return [];
  });

  // Inline Category & Vendor Addition State
  const [isAddingCategory, setIsAddingCategory] = useState<boolean>(false);
  const [newCategoryName, setNewCategoryName] = useState<string>('');
  const [isAddingVendor, setIsAddingVendor] = useState<boolean>(false);
  const [newVendorName, setNewVendorName] = useState<string>('');

  // Barcode Camera / Photo Capture for Product SKU
  const productDirectCameraInputRef = useRef<HTMLInputElement>(null);
  const [isDecodingBarcodePhoto, setIsDecodingBarcodePhoto] = useState(false);
  const [barcodeFeedback, setBarcodeFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  // Category Options combining default categories with any existing custom/master/product categories
  const categoryOptions = Array.from(
    new Set([
      ...DEFAULT_CATEGORIES,
      ...customCategories,
      ...(masterCategories || []),
      ...products.map(p => p.category).filter(Boolean),
      ...(category ? [category] : [])
    ])
  );

  // Category change handler with automatic HSN & GST auto-population
  const handleCategoryChange = (selectedCategory: string) => {
    setCategory(selectedCategory);
    if (selectedCategory && CATEGORY_TAX_MAP[selectedCategory]) {
      const taxData = CATEGORY_TAX_MAP[selectedCategory];
      setHsn(taxData.hsn);
      setGstPercent(taxData.gstRate);
    }
  };

  // Save new category inline
  const handleSaveNewCategory = () => {
    const trimmed = newCategoryName.trim();
    if (trimmed) {
      setCustomCategories(prev => {
        const updated = Array.from(new Set([...prev, trimmed]));
        try {
          localStorage.setItem('pos_custom_categories', JSON.stringify(updated));
        } catch (e) {
          console.warn('Failed saving custom category to localStorage', e);
        }
        return updated;
      });

      if (addCategory) {
        addCategory(trimmed);
      }

      setCategory(trimmed);
      if (CATEGORY_TAX_MAP[trimmed]) {
        const taxData = CATEGORY_TAX_MAP[trimmed];
        setHsn(taxData.hsn);
        setGstPercent(taxData.gstRate);
      } else {
        setHsn(prev => (!prev || prev.trim() === '' ? '9999' : prev));
      }
      playBeep('success');
    }
    setIsAddingCategory(false);
    setNewCategoryName('');
  };

  // Load product data when editing, or reset for new product
  useEffect(() => {
    if (isOpen) {
      if (productToEdit) {
        setName(productToEdit.name || '');
        setBarcode(productToEdit.barcode || '');
        setCategory(productToEdit.category || 'General');
        setVendor(productToEdit.vendor || 'General');
        setHsn(productToEdit.hsn || '');
        setQuantity(productToEdit.stockQty !== undefined ? String(productToEdit.stockQty) : '');
        setMinThreshold(productToEdit.minThreshold !== undefined ? String(productToEdit.minThreshold) : '3');
        setPurchasePrice(productToEdit.basicPurchaseRate !== undefined ? String(productToEdit.basicPurchaseRate) : '');
        setMrp(productToEdit.mrp !== undefined ? String(productToEdit.mrp) : (productToEdit.sellingPrice !== undefined ? String(productToEdit.sellingPrice) : ''));
        setGstPercent(productToEdit.gstPercent !== undefined ? productToEdit.gstPercent : 18);
      } else {
        setName('');
        const generatedCode = 'AGG-' + Math.floor(10000 + Math.random() * 90000);
        setBarcode(generatedCode);
        setCategory('General');
        setVendor('General');
        setHsn('3924');
        setQuantity('');
        setMinThreshold('3');
        setPurchasePrice('');
        setMrp('');
        setGstPercent(18);
      }
      setIsAddingCategory(false);
      setNewCategoryName('');
      setBarcodeFeedback(null);

      // Auto-focus the name input for immediate keyboard entry
      setTimeout(() => {
        nameInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, productToEdit]);

  // Handle direct barcode photo snap
  const handleBarcodePhotoSnap = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsDecodingBarcodePhoto(true);
    setBarcodeFeedback(null);

    try {
      const detected = await decodeBarcodeFromImage(file);
      if (detected) {
        playScanAudioTone(true);
        setBarcode(detected.trim());
        setBarcodeFeedback({
          type: 'success',
          text: language === 'hi' ? `✓ बारकोड प्राप्त: ${detected.trim()}` : `✓ Barcode Captured: ${detected.trim()}`
        });
      } else {
        playScanAudioTone(false);
        setBarcodeFeedback({
          type: 'error',
          text: language === 'hi' ? 'फोटो में बारकोड नहीं मिला। कृपया सीधा फोटो लें।' : 'No barcode found in photo. Try a closer snap.'
        });
      }
    } catch (err) {
      console.error('Barcode photo error in product modal:', err);
      playScanAudioTone(false);
      setBarcodeFeedback({
        type: 'error',
        text: language === 'hi' ? 'बारकोड पढ़ने में असमर्थ' : 'Could not decode barcode'
      });
    } finally {
      setIsDecodingBarcodePhoto(false);
      if (productDirectCameraInputRef.current) productDirectCameraInputRef.current.value = '';
    }
  };

  // Handle Live Camera Barcode Scanner
  const handleScanBarcode = () => {
    openCameraScanner('inventory', (scannedCode) => {
      setBarcode(scannedCode);
      playBeep('scan');
      setBarcodeFeedback({
        type: 'success',
        text: `✓ Scanned: ${scannedCode}`
      });
    });
  };

  // Generate a random unique barcode
  const handleGenerateBarcode = () => {
    const code = 'AGG-' + Math.floor(10000 + Math.random() * 90000);
    setBarcode(code);
    playBeep('scan');
  };

  if (!isOpen) return null;

  // Real-time matched product in catalog
  const matchedExistingProduct = (!productToEdit && (name.trim().length >= 3 || barcode.trim().length >= 4))
    ? findMatchingProduct({ name, barcode }, products)
    : null;

  const currentParsedQty = parseInt(quantity, 10) || 0;
  const currentParsedBuy = parseFloat(purchasePrice) || 0;
  const existingStock = matchedExistingProduct?.stockQty || 0;
  const existingBuyRate = matchedExistingProduct?.basicPurchaseRate || 0;
  const previewTotalQty = existingStock + currentParsedQty;
  const previewWeightedRate = previewTotalQty > 0
    ? Math.round((((existingStock * existingBuyRate) + (currentParsedQty * currentParsedBuy)) / previewTotalQty) * 100) / 100
    : currentParsedBuy;

  // Real-time landing cost
  const numericCost = parseFloat(purchasePrice) || 0;
  const numericGst = Number(gstPercent) || 0;
  const calculatedLanding = calculateLandingCost(numericCost, numericGst);

  // Form Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const parsedBasic = parseFloat(purchasePrice) || 0;
    const parsedGst = Number(gstPercent) || 0;
    const landing = calculateLandingCost(parsedBasic, parsedGst);
    const parsedStock = parseInt(quantity, 10) || 0;
    const parsedMinThreshold = parseInt(minThreshold, 10) || 3;
    const parsedMrp = parseFloat(mrp) || 0;

    const brand = inferBrandFromName(name, productToEdit?.brand);
    const productCategory = (category.trim() || inferCategoryFromName(name, productToEdit?.category) || 'General') as ItemCategory;
    const vendorName = isAddingVendor ? newVendorName : (vendor || productToEdit?.vendor || 'General');
    const finalVendor = (vendorName || 'General').trim();

    // Check if updating an existing matched product via Auto De-duplication
    if (!productToEdit && matchedExistingProduct && matchedExistingProduct.id && autoMergeDuplicate) {
      const mergeResult = mergeWithExistingProduct(
        {
          name: name.trim(),
          barcode: barcode.trim(),
          quantity: parsedStock,
          purchasePrice: parsedBasic,
          mrp: parsedMrp,
          gst: parsedGst,
          brand,
          category: productCategory,
          vendor: finalVendor
        },
        matchedExistingProduct
      );

      if (onSave) {
        await onSave({ ...mergeResult.product, vendor: finalVendor });
      } else {
        await updateProduct(matchedExistingProduct.id, { ...mergeResult.product, vendor: finalVendor });
      }
    } else {
      const productPayload: Omit<Product, 'id'> = {
        name: name.trim(),
        barcode: barcode.trim() || ('AGG-' + Math.floor(10000 + Math.random() * 90000)),
        brand,
        category: productCategory,
        vendor: finalVendor,
        hsn: hsn.trim() || productToEdit?.hsn || '9999',
        stockQty: parsedStock,
        minThreshold: parsedMinThreshold,
        basicPurchaseRate: parsedBasic,
        gstPercent: parsedGst,
        landingCost: landing,
        mrp: parsedMrp,
        sellingPrice: parsedMrp,
        createdAt: productToEdit?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (onSave) {
        if (productToEdit?.id) {
          await onSave({ ...productPayload, id: productToEdit.id });
        } else {
          await onSave(productPayload);
        }
      } else {
        if (productToEdit?.id) {
          await updateProduct(productToEdit.id, productPayload);
        } else {
          await addProduct(productPayload);
        }
      }
    }

    playBeep('success');
    onClose();
  };

  const gstRates = [0, 5, 12, 18, 28];

  return (
    <div 
      id="product-inventory-modal"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto"
    >
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-slate-900 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between gap-3 bg-slate-50/80">
          <div>
            <h3 className="font-black text-lg text-slate-900 tracking-tight flex items-center gap-2">
              <span>{productToEdit ? 'Edit Product' : 'Add New Product'}</span>
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {productToEdit ? 'Update product pricing, category, and inventory levels' : 'Enter product details to add to inventory'}
            </p>
          </div>

          <button
            id="btn-close-product-modal"
            type="button"
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-xl transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Existing Inventory Match Banner */}
        {matchedExistingProduct && !productToEdit && (
          <div className="mx-6 mt-4 p-3 bg-indigo-50/90 border border-indigo-200 rounded-2xl space-y-1.5 text-xs animate-in fade-in">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-indigo-950 flex items-center gap-1.5">
                <GitMerge className="w-4 h-4 text-indigo-600" />
                Existing Product Match: "{matchedExistingProduct.name}"
              </span>
              <span className="text-[10px] font-black bg-indigo-200/80 text-indigo-800 px-2 py-0.5 rounded-md">
                Auto-Merge
              </span>
            </div>

            <p className="text-[11px] text-indigo-900 leading-relaxed font-medium">
              Current stock: <strong>{existingStock} pcs</strong> @ <strong>₹{existingBuyRate}</strong>. 
              Adding <strong>{currentParsedQty} pcs</strong> updates stock to <strong>{previewTotalQty} pcs</strong> with average cost: <strong className="text-emerald-700 font-bold">₹{previewWeightedRate}</strong>.
            </p>

            <label className="flex items-center gap-2 pt-0.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={autoMergeDuplicate}
                onChange={(e) => setAutoMergeDuplicate(e.target.checked)}
                className="w-3.5 h-3.5 text-indigo-600 rounded-sm accent-indigo-600 cursor-pointer"
              />
              <span className="text-[11px] font-bold text-indigo-950">
                Merge & update average cost on save
              </span>
            </label>
          </div>
        )}

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          
          {/* 1. Barcode / SKU Field */}
          <div>
            <input 
              ref={productDirectCameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              id="direct-camera-barcode-input-product"
              className="hidden"
              onChange={handleBarcodePhotoSnap}
            />

            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor="input-product-barcode" className="text-slate-700 font-bold text-xs">
                Barcode / SKU *
              </label>
              <span className="text-[11px] text-slate-400 font-medium">
                USB Scanner / Camera / Auto-generated
              </span>
            </div>

            <div className="relative flex items-center bg-slate-50 hover:bg-slate-100/70 focus-within:bg-white border border-slate-200 rounded-xl transition duration-150 shadow-2xs focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 min-w-0">
              <Barcode className="w-4 h-4 text-slate-400 ml-3.5 shrink-0" />
              <input
                id="input-product-barcode"
                tabIndex={1}
                type="text"
                required
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                onFocus={(e) => e.target.select()}
                placeholder="Scan or enter barcode..."
                className="w-full h-11 bg-transparent px-3 text-xs sm:text-sm font-mono font-bold text-slate-900 placeholder:font-sans placeholder:font-normal placeholder-slate-400 focus:outline-hidden"
              />

              <div className="flex items-center gap-1 pr-1.5 shrink-0">
                {barcode && (
                  <button
                    type="button"
                    onClick={() => setBarcode('')}
                    className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition cursor-pointer"
                    title="Clear barcode"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Live Camera Scanner Trigger */}
                <button
                  id="btn-scan-product-barcode"
                  type="button"
                  onClick={handleScanBarcode}
                  className="h-8 px-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                  title="Scan with Camera Barcode Scanner"
                >
                  <Zap className="w-3.5 h-3.5 text-indigo-600" />
                  <span className="hidden sm:inline">Scan</span>
                </button>

                {/* Photo Snap Camera */}
                <button
                  id="btn-photo-product-barcode"
                  type="button"
                  onClick={() => productDirectCameraInputRef.current?.click()}
                  disabled={isDecodingBarcodePhoto}
                  className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                  title="Take photo of barcode"
                >
                  {isDecodingBarcodePhoto ? (
                    <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  ) : (
                    <Camera className="w-4 h-4" />
                  )}
                </button>

                {/* Generate New SKU */}
                <button
                  id="btn-generate-product-barcode"
                  type="button"
                  onClick={handleGenerateBarcode}
                  className="h-8 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                  title="Generate new unique SKU"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span className="hidden sm:inline">New</span>
                </button>
              </div>
            </div>

            {/* Barcode feedback */}
            {barcodeFeedback && (
              <div 
                className={`mt-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 ${
                  barcodeFeedback.type === 'success' 
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                    : 'bg-red-50 text-red-800 border border-red-200'
                }`}
              >
                {barcodeFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                )}
                <span className="flex-1 text-[11px]">{barcodeFeedback.text}</span>
              </div>
            )}
          </div>

          {/* 1. Product Name Field (Row 1) */}
          <div className="w-full">
            <label htmlFor="input-product-name" className="text-slate-700 font-bold block mb-1.5 text-xs">
              Product Name *
            </label>
            <input
              id="input-product-name"
              ref={nameInputRef}
              tabIndex={2}
              type="text"
              required
              value={name}
              onChange={(e) => {
                const newName = e.target.value;
                setName(newName);
                if (!category || category === 'General') {
                  const inferred = inferCategoryFromName(newName);
                  if (inferred && inferred !== 'General') {
                    setCategory(inferred);
                    if (CATEGORY_TAX_MAP[inferred]) {
                      setHsn(CATEGORY_TAX_MAP[inferred].hsn);
                      setGstPercent(CATEGORY_TAX_MAP[inferred].gstRate);
                    }
                  }
                }
              }}
              placeholder="e.g. Milton Thermosteel Flask 1000ml"
              className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3.5 text-slate-900 text-sm font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
            />
          </div>

          {/* 2. Category Selector / Dropdown (Row 2 - Full-width) */}
          <div className="w-full">
            <label htmlFor="input-product-category" className="text-slate-700 font-bold block mb-1.5 text-xs">
              Category *
            </label>

            {!isAddingCategory ? (
              <div className="flex gap-2 items-center w-full">
                <div className="relative flex-1">
                  <select
                    id="input-product-category"
                    tabIndex={3}
                    required
                    value={category}
                    onChange={(e) => handleCategoryChange(e.target.value)}
                    className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3 text-slate-900 text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition appearance-none cursor-pointer pr-8"
                  >
                    <option value="Perfumes">Perfumes</option>
                    <option value="Gifts">Gifts</option>
                    <option value="Crockery">Crockery</option>
                    <option value="Toys">Toys</option>
                    <option value="Plastics">Plastics</option>
                    <option value="Books">Books</option>
                    <option value="General">General</option>
                    {customCategories
                      .filter((cat) => !DEFAULT_CATEGORIES.includes(cat))
                      .map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>

                <button
                  type="button"
                  id="btn-inline-add-category"
                  onClick={() => {
                    setIsAddingCategory(true);
                    setNewCategoryName('');
                  }}
                  className="h-11 px-3.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl font-bold text-xs flex items-center gap-1 transition shrink-0 cursor-pointer"
                  title="Add custom category"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ New</span>
                </button>
              </div>
            ) : (
              <div className="flex gap-2 items-center w-full">
                <input
                  type="text"
                  id="input-inline-new-category"
                  autoFocus
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleSaveNewCategory();
                    } else if (e.key === 'Escape') {
                      e.preventDefault();
                      setIsAddingCategory(false);
                    }
                  }}
                  placeholder="Category name..."
                  className="flex-1 h-11 bg-white border-2 border-indigo-500 rounded-xl px-3 text-slate-900 text-xs sm:text-sm font-bold focus:outline-hidden"
                />
                <button
                  type="button"
                  id="btn-save-new-category"
                  onClick={handleSaveNewCategory}
                  className="h-11 px-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center gap-1 transition shrink-0 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save</span>
                </button>
                <button
                  type="button"
                  id="btn-cancel-new-category"
                  onClick={() => {
                    setIsAddingCategory(false);
                    setNewCategoryName('');
                  }}
                  className="h-11 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition shrink-0 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* 3. Supplier / Vendor Selector with "+" button (Row 3 - Full-width) */}
          <div className="w-full">
            <label htmlFor="input-product-vendor" className="text-slate-700 font-bold block mb-1.5 text-xs">
              Supplier / Vendor <span className="text-slate-400 font-normal text-[11px]">(Optional)</span>
            </label>

            {!isAddingVendor ? (
              <div className="flex gap-2 items-center w-full">
                <div className="relative flex-1">
                  <select
                    id="input-product-vendor"
                    value={vendor}
                    onChange={(e) => setVendor(e.target.value)}
                    className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3 text-slate-900 text-xs sm:text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition appearance-none cursor-pointer pr-8"
                  >
                    <option value="General">General</option>
                    {vendorSuggestions
                      .filter((v) => v !== 'General')
                      .map((v) => (
                        <option key={v} value={v}>
                          {v}
                        </option>
                      ))}
                    {vendor && !vendorSuggestions.includes(vendor) && (
                      <option value={vendor}>{vendor}</option>
                    )}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>

                <button
                  type="button"
                  id="btn-inline-add-vendor"
                  onClick={() => {
                    setIsAddingVendor(true);
                    setNewVendorName('');
                  }}
                  className="h-11 px-3.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl font-bold text-xs flex items-center gap-1 transition shrink-0 cursor-pointer"
                  title="Add new supplier / vendor"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+</span>
                </button>
              </div>
            ) : (
              <div className="flex gap-2 items-center w-full">
                <input
                  type="text"
                  id="input-inline-new-vendor"
                  autoFocus
                  value={newVendorName}
                  onChange={(e) => setNewVendorName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const trimmed = (newVendorName || 'General').trim();
                      setVendor(trimmed || 'General');
                      setIsAddingVendor(false);
                      setNewVendorName('');
                    } else if (e.key === 'Escape') {
                      e.preventDefault();
                      setIsAddingVendor(false);
                      setNewVendorName('');
                    }
                  }}
                  placeholder="Vendor name..."
                  className="flex-1 min-w-0 h-11 bg-white border-2 border-indigo-500 rounded-xl px-3 text-slate-900 text-xs sm:text-sm font-bold focus:outline-hidden"
                />
                <button
                  type="button"
                  id="btn-save-new-vendor"
                  onClick={() => {
                    const trimmed = (newVendorName || 'General').trim();
                    setVendor(trimmed || 'General');
                    setIsAddingVendor(false);
                    setNewVendorName('');
                  }}
                  className="h-11 px-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center gap-1 transition shrink-0 cursor-pointer"
                  title="Save Vendor"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  id="btn-cancel-new-vendor"
                  onClick={() => {
                    setIsAddingVendor(false);
                    setNewVendorName('');
                  }}
                  className="h-11 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold text-xs transition shrink-0 cursor-pointer"
                  title="Cancel"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* 4. HSN Code */}
          <div className="w-full">
            <label htmlFor="input-product-hsn" className="text-slate-700 font-bold block mb-1.5 text-xs">
              HSN Code <span className="text-slate-400 font-normal text-[11px]">(Optional)</span>
            </label>
            <input
              id="input-product-hsn"
              tabIndex={4}
              type="text"
              value={hsn}
              onChange={(e) => setHsn(e.target.value)}
              placeholder="e.g. 3303"
              className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3 text-slate-900 text-xs sm:text-sm font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
            />
          </div>

          {/* 4. GST % Selector */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-slate-700 font-bold text-xs">
                GST Rate (%)
              </label>
              <span className="text-[11px] text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                {gstPercent === 0 
                  ? 'Exempt (0%)' 
                  : `${gstPercent}% GST (${gstPercent/2}% CGST + ${gstPercent/2}% SGST)`}
              </span>
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              {gstRates.map((rate) => {
                const isSelected = gstPercent === rate;
                return (
                  <button
                    key={rate}
                    id={`btn-gst-${rate}`}
                    type="button"
                    onClick={() => setGstPercent(rate)}
                    className={`h-10 rounded-xl text-center transition cursor-pointer border flex flex-col items-center justify-center p-1 ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    <span className="text-xs font-black">{rate}%</span>
                    <span className={`text-[8px] ${isSelected ? 'text-indigo-100 font-medium' : 'text-slate-400'}`}>
                      {rate === 0 ? 'Exempt' : `${rate/2}+${rate/2}%`}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5. Purchase Price (Cost) & MRP / Selling Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label htmlFor="input-product-purchase-price" className="text-slate-700 font-bold text-xs">
                  Purchase Price / Cost (₹) *
                </label>
              </div>
              <input
                id="input-product-purchase-price"
                tabIndex={5}
                type="number"
                min="0"
                step="0.01"
                required
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
                onFocus={(e) => e.target.select()}
                placeholder="e.g. 200"
                className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3.5 text-slate-900 text-sm font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
              />
              {numericCost > 0 && (
                <p className="text-[10px] text-slate-500 font-medium mt-1">
                  Landing: <strong className="text-indigo-700">₹{calculatedLanding.toFixed(2)}</strong> (+{numericGst}% GST)
                </p>
              )}
            </div>

            <div>
              <label htmlFor="input-product-mrp" className="text-slate-700 font-bold block mb-1.5 text-xs">
                MRP / Selling Price (₹) *
              </label>
              <input
                id="input-product-mrp"
                tabIndex={6}
                type="number"
                min="0"
                step="0.01"
                required
                value={mrp}
                onChange={(e) => setMrp(e.target.value)}
                onFocus={(e) => e.target.select()}
                placeholder="e.g. 399"
                className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3.5 text-slate-900 text-sm font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
              />
              {parseFloat(mrp) > 0 && numericCost > 0 && (
                <p className="text-[10px] text-emerald-600 font-semibold mt-1">
                  Margin: ₹{(parseFloat(mrp) - calculatedLanding).toFixed(2)} ({Math.round(((parseFloat(mrp) - calculatedLanding) / parseFloat(mrp)) * 100)}%)
                </p>
              )}
            </div>
          </div>

          {/* 6. Opening Stock Quantity & Low Stock Alert Limit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="input-product-stock-qty" className="text-slate-700 font-bold block mb-1.5 text-xs">
                Opening Stock Qty (Pcs) *
              </label>
              <input
                id="input-product-stock-qty"
                tabIndex={7}
                type="number"
                min="0"
                step="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                onFocus={(e) => e.target.select()}
                placeholder="e.g. 10"
                className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3.5 text-slate-900 text-sm font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>

            <div>
              <label htmlFor="input-product-min-threshold" className="text-slate-700 font-bold block mb-1.5 text-xs">
                Low Stock Alert Limit (Pcs)
              </label>
              <input
                id="input-product-min-threshold"
                tabIndex={8}
                type="number"
                min="1"
                step="1"
                value={minThreshold}
                onChange={(e) => setMinThreshold(e.target.value)}
                onFocus={(e) => e.target.select()}
                placeholder="e.g. 3"
                className="w-full h-11 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200 rounded-xl px-3.5 text-slate-900 text-sm font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-100 flex items-center gap-3">
            <button
              id="btn-cancel-product-modal"
              type="button"
              onClick={onClose}
              className="flex-1 h-12 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>

            <button
              id="btn-submit-product-modal"
              tabIndex={9}
              type="submit"
              className="flex-[2] h-12 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-indigo-600/20 transition cursor-pointer active:scale-[0.99] flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>
                {matchedExistingProduct && !productToEdit && autoMergeDuplicate
                  ? 'Merge & Update Stock'
                  : productToEdit ? 'Save Changes' : 'Add to Inventory'}
              </span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};

export const AddProductModal = ProductModal;
