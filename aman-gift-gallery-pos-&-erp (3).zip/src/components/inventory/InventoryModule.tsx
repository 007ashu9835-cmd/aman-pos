import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { getTranslation } from '../../utils/translations';
import { Product, ItemCategory, WastageReason } from '../../types';
import { formatCurrency, calculateLandingCost } from '../../utils/calculations';
import { db } from '../../db';
import { generateBrandPurchaseOrderPdf, sharePurchaseOrderPdf, POItem } from '../../utils/purchaseOrderPdf';
import { decodeBarcodeFromImage, playScanAudioTone } from '../../utils/barcodeImageDecoder';
import { parseCSVToTable, dissectItemSemantic } from '../../utils/aiSyncEngine';
import JsBarcode from 'jsbarcode';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { ProductModal, CATEGORY_TAX_MAP } from './ProductModal';
import { CategoryManagerModal } from '../common/CategoryManagerModal';
import { 
  Package, 
  Search, 
  Plus, 
  AlertTriangle, 
  Edit, 
  Trash2, 
  Barcode, 
  Printer, 
  Hourglass, 
  Share2, 
  Check, 
  TrendingDown, 
  SlidersHorizontal,
  X,
  FileDown,
  Camera,
  Zap,
  Sparkles,
  FolderTree,
  Loader2,
  FileText,
  Download,
  Building2,
  CheckCircle2,
  Layers,
  MessageSquare,
  Image as ImageIcon,
  Truck,
  Upload
} from 'lucide-react';

// Barcode Sticker Card component to dynamically render a valid barcode for each individual sticker
interface BarcodeSizeConfig {
  id: string;
  name: string;
  gridColsClass: string;
  cardPadding: string;
  headerSize: string;
  titleSize: string;
  priceSize: string;
  barcodeWidth: number;
  barcodeHeight: number;
  barcodeFontSize: number;
  minHeight: string;
  widthMm: number;
  heightMm: number;
  printCols: number;
}

export const STICKER_SIZE_PRESETS: BarcodeSizeConfig[] = [
  {
    id: '50x25',
    name: '50mm x 25mm (Standard Thermal 2x1 inch)',
    gridColsClass: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4',
    cardPadding: 'p-2.5',
    headerSize: 'text-[11px]',
    titleSize: 'text-[10px]',
    priceSize: 'text-xs',
    barcodeWidth: 1.35,
    barcodeHeight: 34,
    barcodeFontSize: 9,
    minHeight: '100px',
    widthMm: 50,
    heightMm: 25,
    printCols: 4
  },
  {
    id: '38x25',
    name: '38mm x 25mm (Compact Thermal)',
    gridColsClass: 'grid-cols-2 sm:grid-cols-4 lg:grid-cols-5',
    cardPadding: 'p-2',
    headerSize: 'text-[10px]',
    titleSize: 'text-[9px]',
    priceSize: 'text-[11px]',
    barcodeWidth: 1.15,
    barcodeHeight: 28,
    barcodeFontSize: 8,
    minHeight: '88px',
    widthMm: 38,
    heightMm: 25,
    printCols: 5
  },
  {
    id: '24-up',
    name: '24-up A4 Sticker Sheet (3x8 Grid)',
    gridColsClass: 'grid-cols-1 sm:grid-cols-3 lg:grid-cols-3',
    cardPadding: 'p-3',
    headerSize: 'text-xs',
    titleSize: 'text-xs',
    priceSize: 'text-sm',
    barcodeWidth: 1.6,
    barcodeHeight: 40,
    barcodeFontSize: 10,
    minHeight: '115px',
    widthMm: 63.5,
    heightMm: 33.9,
    printCols: 3
  },
  {
    id: '65-up',
    name: '65-up A4 Mini Label Sheet (5x13 Grid)',
    gridColsClass: 'grid-cols-2 sm:grid-cols-4 lg:grid-cols-5',
    cardPadding: 'p-1.5',
    headerSize: 'text-[9px]',
    titleSize: 'text-[8px]',
    priceSize: 'text-[10px]',
    barcodeWidth: 1.0,
    barcodeHeight: 22,
    barcodeFontSize: 8,
    minHeight: '75px',
    widthMm: 38.1,
    heightMm: 21.2,
    printCols: 5
  }
];

const BarcodeStickerCard: React.FC<{
  product: Product;
  shopName: string;
  sizeConfig: BarcodeSizeConfig;
}> = ({ product, shopName, sizeConfig }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (svgRef.current && product.barcode) {
      try {
        JsBarcode(svgRef.current, product.barcode, {
          format: 'CODE128',
          width: sizeConfig.barcodeWidth,
          height: sizeConfig.barcodeHeight,
          displayValue: true,
          fontSize: sizeConfig.barcodeFontSize,
          font: 'monospace',
          margin: 1
        });
      } catch (err) {
        console.warn('JsBarcode render error for sticker:', err);
      }
    }
  }, [product.barcode, sizeConfig]);

  const displayPrice = product.mrp || product.sellingPrice;

  return (
    <div 
      className={`bg-white text-slate-900 ${sizeConfig.cardPadding} rounded-xl border border-slate-200/80 text-center shadow-xs flex flex-col items-center justify-between sticker-card transition-all`}
      style={{ minHeight: sizeConfig.minHeight }}
    >
      <div className="w-full">
        {/* Top Store Name */}
        <p className={`font-black ${sizeConfig.headerSize} uppercase tracking-tight text-slate-900 truncate w-full text-center leading-tight`}>
          {shopName}
        </p>
        {/* Product Name */}
        <p className={`${sizeConfig.titleSize} font-bold text-slate-700 line-clamp-1 w-full mt-0.5 text-center`} title={product.name}>
          {product.name}
        </p>
      </div>

      {/* Barcode SVG in Center */}
      <div className="w-full flex justify-center items-center py-0.5 overflow-hidden">
        <svg ref={svgRef} className="max-w-full h-auto"></svg>
      </div>

      {/* Single Bold MRP Bottom */}
      <div className="w-full text-center border-t border-slate-200 pt-1">
        <p className={`font-black text-slate-900 ${sizeConfig.priceSize} tracking-tight`}>
          MRP: ₹{displayPrice}
        </p>
      </div>
    </div>
  );
};

export const InventoryModule: React.FC = () => {
  const { 
    products, 
    lowStockProducts, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    language, 
    shopProfile,
    openCameraScanner,
    masterCategories,
    playBeep,
    setActiveTab
  } = useApp();
  const t = getTranslation(language);

  const [activeSubTab, setActiveSubTab] = useState<'grid' | 'lowstock' | 'deadstock' | 'barcodeGen' | 'wastage'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBrand, setSelectedBrand] = useState<string>('All');
  const [selectedVendor, setSelectedVendor] = useState<string>('All');
  const [isCatManagerOpen, setIsCatManagerOpen] = useState(false);

  // Direct Camera Photo Barcode Capture for Inventory
  const invDirectCameraInputRef = useRef<HTMLInputElement>(null);
  const invGalleryInputRef = useRef<HTMLInputElement>(null);
  const [isDecodingInvBarcodePhoto, setIsDecodingInvBarcodePhoto] = useState(false);
  const [invBarcodeFeedback, setInvBarcodeFeedback] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  useEffect(() => {
    if (invBarcodeFeedback) {
      const timer = setTimeout(() => setInvBarcodeFeedback(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [invBarcodeFeedback]);

  const handleInventoryBarcodeImageCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsDecodingInvBarcodePhoto(true);
    setInvBarcodeFeedback(null);

    try {
      const detected = await decodeBarcodeFromImage(file);
      if (detected) {
        playScanAudioTone(true);
        const cleanCode = detected.trim();
        setSearchTerm(cleanCode);
        
        const matched = products.find(p => 
          p.barcode.toLowerCase() === cleanCode.toLowerCase() || 
          p.barcode.toLowerCase() === cleanCode.replace(/^0+/, '').toLowerCase()
        );

        if (matched) {
          setInvBarcodeFeedback({
            type: 'success',
            text: language === 'hi' 
              ? `✓ उत्पाद मिला: "${matched.name}" (SKU: ${cleanCode})` 
              : `✓ Item Found: "${matched.name}" (SKU: ${cleanCode})`
          });
        } else {
          setInvBarcodeFeedback({
            type: 'info',
            text: language === 'hi' 
              ? `बारकोड डिटेक्ट: ${cleanCode} (इन्वेंट्री में नया बारकोड)` 
              : `Detected Barcode: ${cleanCode} (Ready to search or add)`
          });
        }
      } else {
        playScanAudioTone(false);
        setInvBarcodeFeedback({
          type: 'error',
          text: language === 'hi' 
            ? 'फोटो में बारकोड नहीं मिला। कृपया सीधा और साफ फोटो लें।' 
            : 'No barcode found in captured photo. Please try snapping closer with good lighting.'
        });
      }
    } catch (err) {
      console.error('Inventory barcode decode error:', err);
      playScanAudioTone(false);
      setInvBarcodeFeedback({
        type: 'error',
        text: language === 'hi' ? 'बारकोड प्रोसेस करने में त्रुटि हुई।' : 'Error decoding barcode photo.'
      });
    } finally {
      setIsDecodingInvBarcodePhoto(false);
      if (invDirectCameraInputRef.current) invDirectCameraInputRef.current.value = '';
      if (invGalleryInputRef.current) invGalleryInputRef.current.value = '';
    }
  };

  // Product Add/Edit Modal
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Barcode Gun (Hardware Scanner) Global Keydown Listener
  useEffect(() => {
    let barcodeBuffer = '';
    let lastKeyTime = Date.now();

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is inside a modal or typing in a modal textarea
      if (isProductModalOpen || isCatManagerOpen) return;
      if (e.ctrlKey || e.altKey || e.metaKey) return;

      const currentTime = Date.now();
      const timeDiff = currentTime - lastKeyTime;
      lastKeyTime = currentTime;

      // Hardware barcode scanners send keystrokes extremely rapidly (< 75ms apart)
      if (timeDiff > 80) {
        barcodeBuffer = '';
      }

      if (e.key === 'Enter') {
        if (barcodeBuffer.trim().length >= 3) {
          e.preventDefault();
          const scannedCode = barcodeBuffer.trim();
          barcodeBuffer = '';

          setSearchTerm(scannedCode);
          playScanAudioTone(true);

          const matched = products.find(p => 
            p.barcode?.toLowerCase() === scannedCode.toLowerCase() || 
            p.barcode?.toLowerCase() === scannedCode.replace(/^0+/, '').toLowerCase()
          );

          if (matched) {
            setInvBarcodeFeedback({
              type: 'success',
              text: language === 'hi' 
                ? `✓ उत्पाद मिला: "${matched.name}" (बारकोड: ${scannedCode})` 
                : `✓ Item Found: "${matched.name}" (Barcode: ${scannedCode})`
            });
          } else {
            setInvBarcodeFeedback({
              type: 'info',
              text: language === 'hi' 
                ? `बारकोड डिटेक्ट: ${scannedCode} (इन्वेंट्री में नया बारकोड)` 
                : `Scanned Barcode: ${scannedCode} (Ready to search or add)`
            });
          }
        } else {
          barcodeBuffer = '';
        }
      } else if (e.key.length === 1) {
        barcodeBuffer += e.key;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [products, language, isProductModalOpen, isCatManagerOpen]);

  // CSV / Excel Import & Export States
  const csvFileInputRef = useRef<HTMLInputElement>(null);
  const [isImportingCsv, setIsImportingCsv] = useState(false);
  const [importFeedback, setImportFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (importFeedback) {
      const timer = setTimeout(() => setImportFeedback(null), 6000);
      return () => clearTimeout(timer);
    }
  }, [importFeedback]);

  // CSV Import Handler
  const handleImportCSV = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImportingCsv(true);
    setImportFeedback(null);

    try {
      const text = await file.text();
      const { headers, rows } = parseCSVToTable(text);
      if (rows.length === 0) {
        throw new Error('CSV file is empty or could not be parsed.');
      }

      const lowerHeaders = headers.map(h => h.toLowerCase().trim());
      const findCol = (keywords: string[]) => lowerHeaders.findIndex(h => keywords.some(k => h.includes(k)));

      const barcodeIdx = findCol(['barcode', 'sku', 'code', 'item code']);
      const nameIdx = findCol(['name', 'item', 'product', 'description', 'title']);
      const categoryIdx = findCol(['category', 'type', 'dept', 'group']);
      const brandIdx = findCol(['brand', 'company', 'mfg']);
      const vendorIdx = findCol(['vendor', 'supplier', 'dealer', 'distributor']);
      const hsnIdx = findCol(['hsn', 'sac']);
      const costIdx = findCol(['purchase', 'cost', 'buy', 'basic', 'landing', 'rate']);
      const mrpIdx = findCol(['mrp', 'sell', 'price', 'retail']);
      const stockIdx = findCol(['stock', 'qty', 'quantity', 'opening', 'count']);
      const gstIdx = findCol(['gst', 'tax', 'vat']);
      const minThreshIdx = findCol(['min', 'threshold', 'alert', 'low']);

      let importedCount = 0;
      let updatedCount = 0;

      for (const row of rows) {
        const rawName = (nameIdx !== -1 ? row[nameIdx] : '').trim();
        const rawBarcode = (barcodeIdx !== -1 ? row[barcodeIdx] : '').trim();
        if (!rawName && !rawBarcode) continue;

        const dissected = dissectItemSemantic(rawName);
        const itemName = dissected.cleanName || rawName || 'Item';
        const itemBrand = (brandIdx !== -1 && row[brandIdx]?.trim()) || dissected.brand || 'General';
        const itemCategory = ((categoryIdx !== -1 && row[categoryIdx]?.trim()) || dissected.category || 'General') as ItemCategory;
        const itemVendor = (vendorIdx !== -1 && row[vendorIdx]?.trim()) || 'General';

        const parsedCost = parseFloat(costIdx !== -1 ? row[costIdx]?.replace(/[^0-9.]/g, '') : '') || 0;
        const parsedMrp = parseFloat(mrpIdx !== -1 ? row[mrpIdx]?.replace(/[^0-9.]/g, '') : '') || (dissected.embeddedMrp || parsedCost);
        const parsedStock = parseInt(stockIdx !== -1 ? row[stockIdx]?.replace(/[^0-9-]/g, '') : '', 10) || 0;
        const parsedGst = parseFloat(gstIdx !== -1 ? row[gstIdx]?.replace(/[^0-9.]/g, '') : '') || 18;
        const parsedHsn = (hsnIdx !== -1 && row[hsnIdx]?.trim()) || (CATEGORY_TAX_MAP[itemCategory]?.hsn || '9999');
        const parsedMin = parseInt(minThreshIdx !== -1 ? row[minThreshIdx]?.replace(/[^0-9]/g, '') : '', 10) || 3;
        const finalBarcode = rawBarcode || ('AGG-' + Math.floor(10000 + Math.random() * 90000));
        const landingCost = calculateLandingCost(parsedCost, parsedGst);

        // Check if existing product by barcode or exact name
        const existing = products.find(p => 
          (rawBarcode && p.barcode.toLowerCase() === rawBarcode.toLowerCase()) || 
          p.name.toLowerCase() === itemName.toLowerCase()
        );

        if (existing && existing.id) {
          await updateProduct(existing.id, {
            ...existing,
            vendor: itemVendor !== 'General' ? itemVendor : (existing.vendor || 'General'),
            stockQty: existing.stockQty + (parsedStock > 0 ? parsedStock : 0),
            basicPurchaseRate: parsedCost > 0 ? parsedCost : existing.basicPurchaseRate,
            mrp: parsedMrp > 0 ? parsedMrp : existing.mrp,
            sellingPrice: parsedMrp > 0 ? parsedMrp : existing.sellingPrice,
            landingCost: parsedCost > 0 ? landingCost : existing.landingCost,
            updatedAt: new Date().toISOString()
          });
          updatedCount++;
        } else {
          await addProduct({
            name: itemName,
            barcode: finalBarcode,
            brand: itemBrand,
            category: itemCategory,
            vendor: itemVendor,
            hsn: parsedHsn,
            stockQty: parsedStock,
            minThreshold: parsedMin,
            basicPurchaseRate: parsedCost,
            gstPercent: parsedGst,
            landingCost: landingCost,
            mrp: parsedMrp,
            sellingPrice: parsedMrp,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
          importedCount++;
        }
      }

      playBeep('success');
      setImportFeedback({
        type: 'success',
        text: `✓ Processed ${rows.length} rows (${importedCount} new products added, ${updatedCount} products updated).`
      });
    } catch (err: any) {
      console.error('CSV Import error:', err);
      playBeep('error');
      setImportFeedback({
        type: 'error',
        text: err?.message || 'Failed to import CSV file. Please check file format.'
      });
    } finally {
      setIsImportingCsv(false);
      if (csvFileInputRef.current) csvFileInputRef.current.value = '';
    }
  };

  // CSV Export Handler
  const handleExportCSV = () => {
    if (products.length === 0) {
      alert('No products to export.');
      return;
    }

    const headers = ['Barcode', 'Product Name', 'Category', 'Brand', 'Vendor / Supplier', 'HSN Code', 'Stock Qty', 'Basic Cost (Rs)', 'GST %', 'Landing Cost (Rs)', 'MRP (Rs)', 'Selling Price (Rs)', 'Min Stock Alert'];
    const rows = products.map(p => [
      `"${(p.barcode || '').replace(/"/g, '""')}"`,
      `"${(p.name || '').replace(/"/g, '""')}"`,
      `"${(p.category || '').replace(/"/g, '""')}"`,
      `"${(p.brand || '').replace(/"/g, '""')}"`,
      `"${(p.vendor || 'General').replace(/"/g, '""')}"`,
      `"${(p.hsn || '').replace(/"/g, '""')}"`,
      p.stockQty,
      p.basicPurchaseRate,
      p.gstPercent,
      p.landingCost,
      p.mrp,
      p.sellingPrice,
      p.minThreshold || 3
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Inventory_Stock_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    playBeep('scan');
  };

  // Wastage Deduction Modal
  const [wastageModalOpen, setWastageModalOpen] = useState(false);
  const [selectedWastageProduct, setSelectedWastageProduct] = useState<Product | null>(null);
  const [wastageQty, setWastageQty] = useState(1);
  const [wastageReason, setWastageReason] = useState<WastageReason>('Broken');
  const [wastageNotes, setWastageNotes] = useState('');

  // Barcode Label Generation State - default empty so user can type without unwanted leading 1
  const [selectedBarcodeProduct, setSelectedBarcodeProduct] = useState<Product | null>(null);
  const [stickerCopies, setStickerCopies] = useState<string>('');
  const [selectedStickerSize, setSelectedStickerSize] = useState<string>('50x25');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Brand-wise Reorder PO State
  const [reorderFilterBrand, setReorderFilterBrand] = useState<string>('All');
  const [reorderQtyMap, setReorderQtyMap] = useState<Record<number, number>>({});
  const [sharingBrand, setSharingBrand] = useState<string | null>(null);
  const [downloadingBrand, setDownloadingBrand] = useState<string | null>(null);
  const [poSuccessFeedback, setPoSuccessFeedback] = useState<string | null>(null);
  const [poNotes, setPoNotes] = useState<string>('1. Please dispatch fresh stock with original retail packaging.\n2. Ensure safe transit handling for fragile/giftware items.\n3. Mention PO Number on the invoice and delivery challan.');

  const currentSizeConfig = useMemo(() => {
    return STICKER_SIZE_PRESETS.find(s => s.id === selectedStickerSize) || STICKER_SIZE_PRESETS[0];
  }, [selectedStickerSize]);

  // Group low stock products strictly by Brand
  const brandLowStockGroups = useMemo(() => {
    const map = new Map<string, Product[]>();
    lowStockProducts.forEach((p) => {
      const bName = (p.brand || 'Unbranded').trim();
      const list = map.get(bName) || [];
      list.push(p);
      map.set(bName, list);
    });

    const groups = Array.from(map.entries()).map(([brand, items]) => ({
      brand,
      items
    }));

    // Sort brands alphabetically
    return groups.sort((a, b) => a.brand.localeCompare(b.brand));
  }, [lowStockProducts]);

  // Unique brands present in low-stock list
  const lowStockBrands = useMemo(() => {
    return ['All', ...brandLowStockGroups.map(g => g.brand)];
  }, [brandLowStockGroups]);

  // Filtered brand groups for UI
  const filteredBrandGroups = useMemo(() => {
    if (reorderFilterBrand === 'All') return brandLowStockGroups;
    return brandLowStockGroups.filter(g => g.brand === reorderFilterBrand);
  }, [brandLowStockGroups, reorderFilterBrand]);

  const getItemReorderQty = (prod: Product): number => {
    if (prod.id && reorderQtyMap[prod.id] !== undefined) {
      return reorderQtyMap[prod.id];
    }
    // Default recommended reorder quantity: 12 pcs
    return 12;
  };

  const updateItemReorderQty = (prodId: number, qty: number) => {
    setReorderQtyMap(prev => ({
      ...prev,
      [prodId]: Math.max(1, qty)
    }));
  };

  // 1-Click Share Brand PO PDF Handler
  const handleShareBrandPo = async (brandName: string, items: Product[]) => {
    try {
      setSharingBrand(brandName);
      const poItems: POItem[] = items.map(p => ({
        product: p,
        reorderQty: getItemReorderQty(p)
      }));

      const result = await sharePurchaseOrderPdf({
        brandName,
        items: poItems,
        shopProfile,
        notes: poNotes
      });

      playBeep('success');
      setPoSuccessFeedback(
        language === 'hi'
          ? `${brandName} का पर्चेस आर्डर PDF (${result.poNumber}) तैयार है!`
          : `Purchase Order PDF (${result.poNumber}) generated for ${brandName}!`
      );
      setTimeout(() => setPoSuccessFeedback(null), 3500);
    } catch (err) {
      console.error('Error sharing PO PDF:', err);
    } finally {
      setSharingBrand(null);
    }
  };

  // Direct Download Brand PO PDF Handler
  const handleDownloadBrandPo = async (brandName: string, items: Product[]) => {
    try {
      setDownloadingBrand(brandName);
      const poItems: POItem[] = items.map(p => ({
        product: p,
        reorderQty: getItemReorderQty(p)
      }));

      const { doc, fileName, poNumber } = generateBrandPurchaseOrderPdf({
        brandName,
        items: poItems,
        shopProfile
      });

      doc.save(fileName);
      playBeep('success');
      setPoSuccessFeedback(
        language === 'hi'
          ? `${brandName} का पर्चेस आर्डर PDF (${poNumber}) डाउनलोड हो गया!`
          : `Downloaded ${fileName} (${poNumber}) successfully!`
      );
      setTimeout(() => setPoSuccessFeedback(null), 3500);
    } catch (err) {
      console.error('Error downloading PO PDF:', err);
    } finally {
      setDownloadingBrand(null);
    }
  };

  // Master Combined PO for all low stock items
  const handleShareMasterCombinedPo = async () => {
    try {
      setSharingBrand('ALL');
      const poItems: POItem[] = lowStockProducts.map(p => ({
        product: p,
        reorderQty: getItemReorderQty(p)
      }));

      const result = await sharePurchaseOrderPdf({
        brandName: 'All Brands (Master Reorder)',
        items: poItems,
        shopProfile,
        notes: poNotes
      });

      playBeep('success');
      setPoSuccessFeedback(
        language === 'hi'
          ? `मास्टर पर्चेस आर्डर PDF (${result.poNumber}) तैयार है!`
          : `Master Reorder PO PDF (${result.poNumber}) generated!`
      );
      setTimeout(() => setPoSuccessFeedback(null), 3500);
    } catch (err) {
      console.error('Error sharing master PO:', err);
    } finally {
      setSharingBrand(null);
    }
  };

  // Dynamic Master Categories, Brands & Vendors list
  const categories = useMemo(() => ['All', ...masterCategories], [masterCategories]);
  const uniqueBrands = useMemo(() => {
    const bSet = new Set(products.map(p => p.brand || 'Unbranded'));
    return ['All', ...Array.from(bSet)];
  }, [products]);
  const uniqueVendors = useMemo(() => {
    const vSet = new Set(products.map(p => p.vendor || 'General').filter(Boolean));
    return ['All', ...Array.from(vSet)];
  }, [products]);

  // Dead stock items: no sale in >60 days or lastSoldDate empty with created > 60 days
  const deadStockItems = useMemo(() => {
    const sixtyDaysAgo = new Date();
    sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
    const limitStr = sixtyDaysAgo.toISOString().split('T')[0];

    return products.filter(p => {
      if (p.stockQty <= 0) return false;
      const lastActivity = p.lastSoldDate || p.createdAt;
      return lastActivity < limitStr;
    });
  }, [products]);

  const deadStockBlockedCapital = useMemo(() => {
    return deadStockItems.reduce((sum, p) => sum + (p.landingCost * p.stockQty), 0);
  }, [deadStockItems]);

  // Filtered Items for Live Search & Vendor Filtering
  const filteredItems = useMemo(() => {
    const query = searchTerm.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    return products.filter((item: any) => {
      const matchesSearch = !query || 
        item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.barcode?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.sku?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.mrp && item.mrp.toString().replace(/[^0-9]/g, '').includes(query)) ||
        (item.sellingRate && item.sellingRate.toString().replace(/[^0-9]/g, '').includes(query)) ||
        (item.sellingPrice && item.sellingPrice.toString().replace(/[^0-9]/g, '').includes(query));
      const matchesVendor = selectedVendor === 'All' || item.vendor?.toLowerCase().trim() === selectedVendor.toLowerCase().trim();
      return matchesSearch && matchesVendor;
    });
  }, [products, searchTerm, selectedVendor]);
  const filteredProducts = filteredItems;

  // Handle open Add/Edit
  const handleOpenAddModal = (prod?: Product) => {
    setEditingProduct(prod || null);
    setIsProductModalOpen(true);
  };

  // Wastage Deduction Submission
  const handleConfirmWastage = async () => {
    if (!selectedWastageProduct?.id) return;
    const prod = selectedWastageProduct;
    const newStock = Math.max(0, prod.stockQty - wastageQty);
    const lossVal = wastageQty * prod.landingCost;

    await db.wastage.add({
      productId: prod.id,
      productName: prod.name,
      brand: prod.brand,
      quantity: wastageQty,
      reason: wastageReason,
      lossValue: lossVal,
      date: new Date().toISOString().split('T')[0],
      notes: wastageNotes
    });

    await updateProduct(prod.id, { stockQty: newStock });
    setWastageModalOpen(false);
    setSelectedWastageProduct(null);
  };

  // Re-Order List WhatsApp generator
  const handleShareReorderList = () => {
    const text = `*Supplier Re-Order Requirement List - ${shopProfile.name}*
📅 Date: ${new Date().toLocaleDateString('en-IN')}
📍 Store: ${shopProfile.address}, ${shopProfile.city}
━━━━━━━━━━━━━━━━━━━━━
${lowStockProducts.map((p, i) => `${i + 1}. *${p.brand}* - ${p.name}\n   Current Stock: ${p.stockQty} Pcs | Re-order Qty: 12 Pcs`).join('\n\n')}
━━━━━━━━━━━━━━━━━━━━━
Please confirm dispatch schedule and invoice pricing.`;

    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  // Dedicated Print Sticker Sheet Handler with Popup Window & Fallback
  const handlePrintStickers = () => {
    if (!selectedBarcodeProduct) return;
    
    // Ensure we have stickers to print
    const count = stickerCopies === '' ? 0 : parseInt(stickerCopies, 10);
    if (isNaN(count) || count <= 0) {
      setStickerCopies('12');
    }

    setTimeout(() => {
      const printArea = document.getElementById('barcode-sticker-sheet');
      if (!printArea) {
        window.print();
        return;
      }

      try {
        const printWindow = window.open('', '_blank', 'width=850,height=650');
        if (printWindow) {
          printWindow.document.write(`
            <!DOCTYPE html>
            <html>
              <head>
                <meta charset="utf-8" />
                <title>Print Barcode Stickers - ${selectedBarcodeProduct.name}</title>
                <style>
                  @page { 
                    size: auto; 
                    margin: 4mm; 
                  }
                  * {
                    box-sizing: border-box;
                  }
                  body { 
                    margin: 0; 
                    padding: 6px; 
                    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; 
                    display: grid;
                    grid-template-columns: repeat(${currentSizeConfig.printCols}, 1fr);
                    gap: 6px;
                    background: #ffffff;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                  }
                  .sticker-card { 
                    border: 1px dashed #94a3b8 !important; 
                    padding: 4px 6px !important; 
                    text-align: center; 
                    page-break-inside: avoid !important;
                    break-inside: avoid !important;
                    border-radius: 6px !important;
                    background: #ffffff !important;
                    display: flex !important;
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: space-between !important;
                    min-height: ${currentSizeConfig.minHeight} !important;
                  }
                  .sticker-card svg {
                    max-width: 100% !important;
                    height: auto !important;
                  }
                </style>
              </head>
              <body>
                ${printArea.innerHTML}
                <script>
                  window.onload = function() {
                    setTimeout(function() {
                      window.focus();
                      window.print();
                    }, 250);
                  };
                </script>
              </body>
            </html>
          `);
          printWindow.document.close();
          printWindow.focus();
          setTimeout(() => {
            printWindow.print();
          }, 350);
        } else {
          // Fallback if popup is blocked
          window.print();
        }
      } catch (err) {
        console.error('Print popup error, falling back to window.print():', err);
        window.print();
      }
    }, 100);
  };

  // Direct 1-click Download Sticker Sheet PDF handler
  const handleDownloadStickersPDF = async () => {
    if (!selectedBarcodeProduct) return;
    const printArea = document.getElementById('barcode-sticker-sheet');
    if (!printArea) return;

    setIsGeneratingPdf(true);
    try {
      const canvas = await html2canvas(printArea, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = 210;
      const pdfHeight = 297;
      const margin = 10;
      const contentWidth = pdfWidth - (margin * 2);
      const contentHeight = (canvas.height * contentWidth) / canvas.width;
      
      let heightLeft = contentHeight;
      let position = margin;

      pdf.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight);
      heightLeft -= (pdfHeight - margin * 2);

      while (heightLeft > 0) {
        position = heightLeft - contentHeight + margin;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight);
        heightLeft -= (pdfHeight - margin * 2);
      }

      const safeName = (selectedBarcodeProduct.name || 'item').replace(/[^a-zA-Z0-9]/g, '_');
      pdf.save(`Barcode_Stickers_${safeName}.pdf`);
    } catch (err) {
      console.error('Failed to generate sticker sheet PDF:', err);
      alert('Could not generate PDF directly. You can use Print Sticker Sheet and select "Save as PDF" in your print dialog.');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto overflow-y-auto bg-slate-50 select-none">
      {/* Header with Navigation Sub-tabs */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white border border-slate-100 p-5 sm:p-6 rounded-2xl shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Package className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Stock / Inventory
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-medium">
            {products.length} {language === 'hi' ? 'कुल सामान पंजीकृत हैं' : 'Total Registered Stock SKUs'}
          </p>
        </div>

        {/* Sub-tabs & Primary Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto justify-between lg:justify-end">
          <div className="flex items-center bg-slate-100/80 p-1 rounded-xl border border-slate-200/60 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveSubTab('grid')}
              className={`h-8 sm:h-9 px-3 sm:px-3.5 text-xs font-bold rounded-lg transition cursor-pointer ${
                activeSubTab === 'grid' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'hi' ? 'सभी सामान' : 'All Stock'}
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab('lowstock')}
              className={`h-8 sm:h-9 px-3 sm:px-3.5 text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer ${
                activeSubTab === 'lowstock' ? 'bg-amber-600 text-white shadow-xs' : 'text-amber-700 hover:text-amber-900'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'कम स्टॉक' : 'Low Stock'} ({lowStockProducts.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab('deadstock')}
              className={`h-8 sm:h-9 px-3 sm:px-3.5 text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer ${
                activeSubTab === 'deadstock' ? 'bg-rose-600 text-white shadow-xs' : 'text-rose-700 hover:text-rose-900'
              }`}
            >
              <Hourglass className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'डेड स्टॉक' : 'Dead Stock'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveSubTab('barcodeGen');
                if (!selectedBarcodeProduct && products[0]) {
                  setSelectedBarcodeProduct(products[0]);
                }
              }}
              className={`h-8 sm:h-9 px-3 sm:px-3.5 text-xs font-bold rounded-lg transition flex items-center gap-1 cursor-pointer ${
                activeSubTab === 'barcodeGen' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Barcode className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'बारकोड प्रिंटर' : 'Barcode Labels'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Hidden CSV File Input */}
            <input
              ref={csvFileInputRef}
              type="file"
              accept=".csv,.txt"
              id="csv-file-import-input"
              className="hidden"
              onChange={handleImportCSV}
            />

            {/* Import CSV Button */}
            <button
              type="button"
              id="btn-import-csv-header"
              onClick={() => csvFileInputRef.current?.click()}
              disabled={isImportingCsv}
              className="h-10 sm:h-11 px-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title="Import products from CSV file"
            >
              {isImportingCsv ? (
                <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              ) : (
                <Upload className="w-4 h-4 text-slate-600" />
              )}
              <span>📥 Import CSV</span>
            </button>

            {/* Export CSV Button */}
            <button
              type="button"
              id="btn-export-csv-header"
              onClick={handleExportCSV}
              className="h-10 sm:h-11 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title="Export all inventory to CSV"
            >
              <Download className="w-4 h-4 text-slate-600" />
              <span className="hidden sm:inline">Export</span>
            </button>

            {/* Primary Add New Product Button */}
            <button
              type="button"
              id="btn-add-new-product"
              onClick={() => handleOpenAddModal()}
              className="h-10 sm:h-11 px-4 sm:px-5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-black rounded-xl shadow-md shadow-indigo-600/25 transition active:scale-[0.99] flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Add New Product</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW 1: LIVE INVENTORY GRID */}
      {activeSubTab === 'grid' && (
        <div className="space-y-4">
          {/* Hidden Direct Camera Capture Input for Inventory */}
          <input
            ref={invDirectCameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            id="direct-camera-barcode-input-inventory"
            className="hidden"
            onChange={handleInventoryBarcodeImageCapture}
          />

          {/* Hidden Gallery Upload Input for Inventory */}
          <input
            ref={invGalleryInputRef}
            type="file"
            accept="image/*"
            id="gallery-file-barcode-input-inventory"
            className="hidden"
            onChange={handleInventoryBarcodeImageCapture}
          />

          {/* Filter Bar */}
          <div className="space-y-2 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 sm:gap-3 flex-1 min-w-[280px]">
                <div className="relative flex-1 min-w-[220px] max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by name, barcode, or SKU..."
                    className="w-full h-11 bg-slate-50 border border-slate-200/80 rounded-xl pl-10 pr-8 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:bg-white font-medium"
                  />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Camera Scan Button */}
                <button
                  type="button"
                  id="btn-inventory-camera-scan"
                  onClick={() => openCameraScanner('inventory', (barcode) => {
                    const cleanCode = barcode.trim();
                    setSearchTerm(cleanCode);
                    playScanAudioTone(true);
                    const matched = products.find(p => 
                      p.barcode?.toLowerCase() === cleanCode.toLowerCase() || 
                      p.barcode?.toLowerCase() === cleanCode.replace(/^0+/, '').toLowerCase()
                    );
                    if (matched) {
                      setInvBarcodeFeedback({
                        type: 'success',
                        text: language === 'hi' 
                          ? `✓ उत्पाद मिला: "${matched.name}" (बारकोड: ${cleanCode})` 
                          : `✓ Item Found: "${matched.name}" (Barcode: ${cleanCode})`
                      });
                    } else {
                      setInvBarcodeFeedback({
                        type: 'info',
                        text: language === 'hi' 
                          ? `बारकोड डिटेक्ट: ${cleanCode} (इन्वेंट्री में नया बारकोड)` 
                          : `Detected Barcode: ${cleanCode} (Ready to search or add)`
                      });
                    }
                  })}
                  className="h-11 px-3 sm:px-3.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/80 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-xs"
                  title="Scan with Camera / Webcam"
                >
                  <Camera className="w-4 h-4 text-indigo-600" />
                  <span className="hidden sm:inline">Camera Scan</span>
                </button>

                {/* Vendor Dropdown */}
                <select
                  id="select-filter-vendor"
                  value={selectedVendor}
                  onChange={(e) => setSelectedVendor(e.target.value)}
                  className="h-11 bg-slate-50 border border-slate-200/80 text-xs text-slate-800 font-semibold rounded-xl px-3 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  title="Filter by Supplier / Vendor"
                >
                  {uniqueVendors.map((v) => (
                    <option key={v} value={v}>{v === 'All' ? 'All Vendors' : `Vendor: ${v}`}</option>
                  ))}
                </select>
              </div>

              <div className="text-xs text-slate-400 font-bold px-2">
                Showing {filteredItems.length} items
              </div>
            </div>

            {/* Import Feedback Banner */}
            {importFeedback && (
              <div 
                className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                  importFeedback.type === 'success' 
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-xs' 
                    : 'bg-red-50 text-red-800 border border-red-200 shadow-xs'
                }`}
              >
                {importFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                )}
                <span className="flex-1">{importFeedback.text}</span>
                <button 
                  type="button" 
                  onClick={() => setImportFeedback(null)} 
                  className="text-slate-400 hover:text-slate-600 p-0.5 rounded-sm cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Barcode Snap Feedback Banner for Inventory */}
            {invBarcodeFeedback && (
              <div 
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                  invBarcodeFeedback.type === 'success' 
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-xs' 
                    : invBarcodeFeedback.type === 'error'
                    ? 'bg-red-50 text-red-800 border border-red-200 shadow-xs'
                    : 'bg-blue-50 text-blue-800 border border-blue-200 shadow-xs'
                }`}
              >
                {invBarcodeFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                )}
                <span className="flex-1">{invBarcodeFeedback.text}</span>
                <button 
                  type="button" 
                  onClick={() => setInvBarcodeFeedback(null)} 
                  className="text-slate-400 hover:text-slate-600 p-0.5 rounded-sm"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* Table */}
          <div className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead>
                  <tr className="bg-slate-50/80 text-slate-500 uppercase text-[10px] tracking-wider border-b border-slate-100 font-extrabold">
                    <th className="py-3.5 px-4">Barcode / Item Name</th>
                    <th className="py-3.5 px-3">Category & Brand</th>
                    <th className="py-3.5 px-3 text-center">Stock Qty</th>
                    <th className="py-3.5 px-3 text-right">Basic + GST%</th>
                    <th className="py-3.5 px-3 text-right">Landing Cost</th>
                    <th className="py-3.5 px-3 text-right">MRP</th>
                    <th className="py-3.5 px-3 text-right">Selling Rate</th>
                    <th className="py-3.5 px-3 text-right">Margin %</th>
                    <th className="py-3.5 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredItems.map((p, idx) => {
                    const isLow = p.stockQty <= (p.minThreshold || 3);
                    const profitPerUnit = p.sellingPrice - p.landingCost;
                    const marginPct = p.sellingPrice > 0 ? ((profitPerUnit / p.sellingPrice) * 100).toFixed(1) : '0';

                    return (
                      <tr key={p.barcode || (p.id ? `p-${p.id}` : `prod-${idx}`)} className="hover:bg-slate-50/60 transition">
                        <td className="py-3.5 px-4">
                          <p className="font-bold text-slate-900 text-xs sm:text-sm">{p.name}</p>
                          <span className="font-mono text-[11px] text-indigo-600 font-semibold flex items-center gap-1 mt-0.5">
                            <Barcode className="w-3.5 h-3.5 inline" /> {p.barcode}
                          </span>
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-bold text-slate-800">{p.brand}</span>
                            {p.vendor && p.vendor !== 'General' && (
                              <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium border border-slate-200/60" title={`Supplier: ${p.vendor}`}>
                                {p.vendor}
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-400">{p.category}</p>
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <span className={`px-2.5 py-1 rounded-lg text-xs font-black inline-block ${
                            isLow ? 'bg-rose-50 text-rose-700 border border-rose-100' : 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                          }`}>
                            {p.stockQty} Pcs
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-right text-slate-500 font-medium">
                          ₹{p.basicPurchaseRate} + {p.gstPercent}%
                        </td>
                        <td className="py-3.5 px-3 text-right font-bold text-slate-800">
                          ₹{p.landingCost}
                        </td>
                        <td className="py-3.5 px-3 text-right font-medium text-slate-700">
                          ₹{p.mrp}
                        </td>
                        <td className="py-3.5 px-3 text-right font-black text-indigo-600 text-sm">
                          ₹{p.sellingPrice}
                        </td>
                        <td className="py-3.5 px-3 text-right font-bold text-emerald-600">
                          {marginPct}%
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenAddModal(p)}
                              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-900 transition cursor-pointer"
                              title="Edit Item"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedWastageProduct(p);
                                setWastageQty(1);
                                setWastageModalOpen(true);
                              }}
                              className="p-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/80 transition cursor-pointer"
                              title="Deduct Damage / Broken"
                            >
                              <TrendingDown className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedBarcodeProduct(p);
                                setActiveSubTab('barcodeGen');
                              }}
                              className="p-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-100 transition cursor-pointer"
                              title="Print Barcode Labels"
                            >
                              <Barcode className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: LOW STOCK ALERTS & BRAND-WISE RE-ORDER PO GENERATOR */}
      {activeSubTab === 'lowstock' && (
        <div className="space-y-5">
          {/* Top Master Header & Action Bar */}
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50/50 border border-amber-200/90 p-5 sm:p-6 rounded-2xl shadow-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-500 text-white rounded-xl shadow-xs">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-base sm:text-lg text-amber-950">
                    {language === 'hi' ? 'ब्रांड-वाइज री-ऑर्डर व पर्चेस आर्डर (PO) जेनरेटर' : 'Brand-Wise Re-Order & Purchase Order (PO) Hub'}
                  </h3>
                  <p className="text-xs text-amber-900 font-medium">
                    {lowStockProducts.length} {language === 'hi' ? 'आइटम सुरक्षा सीमा (≤ 3 pcs) से नीचे हैं।' : 'items below safety threshold'} • {brandLowStockGroups.length} {language === 'hi' ? 'ब्रांड्स शामिल हैं' : 'supplier brands affected'}
                  </p>
                </div>
              </div>
            </div>

            {/* Master Action Buttons */}
            <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
              <button
                type="button"
                onClick={handleShareMasterCombinedPo}
                disabled={lowStockProducts.length === 0 || sharingBrand === 'ALL'}
                className="h-11 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-2 transition cursor-pointer active:scale-[0.99]"
                title="Generate combined PO PDF for all brands"
              >
                {sharingBrand === 'ALL' ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <FileText className="w-4 h-4" />
                )}
                <span>{language === 'hi' ? 'सभी ब्रांड्स का मास्टर PO शेयर करें' : 'Share Master PO PDF (All Brands)'}</span>
              </button>

              <button
                type="button"
                onClick={handleShareReorderList}
                disabled={lowStockProducts.length === 0}
                className="h-11 px-3.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl shadow-2xs flex items-center gap-1.5 transition cursor-pointer"
                title="Share plain text reorder list on WhatsApp"
              >
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                <span>Text Re-Order</span>
              </button>
            </div>
          </div>

          {/* PO Success Feedback Toast */}
          {poSuccessFeedback && (
            <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-4 rounded-xl flex items-center gap-3 text-xs font-bold shadow-xs animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{poSuccessFeedback}</span>
            </div>
          )}

          {/* Order & Dispatch Details Input */}
          <div className="bg-[#FFFFFF] p-4 sm:p-5 rounded-2xl border border-[#E2E8F0] shadow-sm mb-4">
            <label className="text-[#0F172A] font-bold text-sm block mb-2 flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              Order & Dispatch Details
            </label>
            <textarea
              value={poNotes}
              onChange={(e) => setPoNotes(e.target.value)}
              className="w-full bg-[#FFFFFF] text-[#0F172A] font-medium border border-[#E2E8F0] rounded-xl p-3 text-sm caret-[#2563EB] focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100 selection:bg-blue-100 selection:text-[#0F172A] resize-none outline-none transition-all"
              rows={3}
              placeholder="Enter dispatch and packaging instructions here..."
            />
          </div>

          {/* Brand Filter Selector Chips */}
          {brandLowStockGroups.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 bg-white p-3 rounded-2xl border border-slate-100 shadow-2xs">
              <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider px-2 flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-slate-400" /> Filter Brand:
              </span>
              <button
                type="button"
                onClick={() => setReorderFilterBrand('All')}
                className={`h-8 px-3 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                  reorderFilterBrand === 'All'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                <span>All Brands</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                  reorderFilterBrand === 'All' ? 'bg-indigo-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}>
                  {lowStockProducts.length}
                </span>
              </button>

              {brandLowStockGroups.map((grp) => {
                const isSelected = reorderFilterBrand === grp.brand;
                return (
                  <button
                    key={grp.brand}
                    type="button"
                    onClick={() => setReorderFilterBrand(grp.brand)}
                    className={`h-8 px-3 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <span>{grp.brand}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                      isSelected ? 'bg-indigo-700 text-white' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {grp.items.length}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Empty State */}
          {lowStockProducts.length === 0 ? (
            <div className="bg-white border border-slate-100 p-12 rounded-2xl text-center space-y-3 shadow-sm">
              <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h4 className="font-black text-lg text-slate-900">
                {language === 'hi' ? 'स्टॉक पर्याप्त है!' : 'All Items Well Stocked!'}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {language === 'hi'
                  ? 'किसी भी उत्पाद का स्टॉक सुरक्षा स्तर (≤ 3 pcs) से नीचे नहीं है।'
                  : 'No inventory items are currently running below safety threshold. All brand stocks are healthy.'}
              </p>
            </div>
          ) : (
            /* Brand-Wise Dedicated PO Cards */
            <div className="space-y-6">
              {filteredBrandGroups.map((group) => {
                const brandTotalItems = group.items.length;
                const brandTotalUnits = group.items.reduce(
                  (sum, p) => sum + getItemReorderQty(p),
                  0
                );
                const brandEstVal = group.items.reduce(
                  (sum, p) => sum + ((p.basicPurchaseRate || p.landingCost) * getItemReorderQty(p)),
                  0
                );
                const isSharingThis = sharingBrand === group.brand;
                const isDownloadingThis = downloadingBrand === group.brand;

                return (
                  <div 
                    key={group.brand}
                    className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition"
                  >
                    {/* Brand PO Header Bar */}
                    <div className="bg-slate-50/90 border-b border-slate-200/80 p-4 sm:p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white font-black text-sm flex items-center justify-center shadow-xs uppercase">
                          {group.brand.substring(0, 2)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-black text-base sm:text-lg text-slate-900 uppercase tracking-tight">
                              {group.brand}
                            </h4>
                            <span className="text-[10px] font-extrabold uppercase bg-amber-100 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-md">
                              {brandTotalItems} Low Stock {brandTotalItems === 1 ? 'Item' : 'Items'}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 font-medium mt-0.5">
                            Supplier Re-order: <span className="font-bold text-slate-900">{brandTotalUnits} Units Needed</span> • Est. Basic Value: <span className="font-bold text-slate-900">{formatCurrency(brandEstVal)}</span>
                          </p>
                        </div>
                      </div>

                      {/* Brand Action Buttons */}
                      <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                        <button
                          type="button"
                          onClick={() => handleShareBrandPo(group.brand, group.items)}
                          disabled={isSharingThis}
                          className="h-10 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black rounded-xl shadow-xs flex items-center gap-2 transition cursor-pointer active:scale-[0.99]"
                          title="Generate official Brand PO PDF and attach to WhatsApp / Web Share"
                        >
                          {isSharingThis ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Share2 className="w-4 h-4" />
                          )}
                          <span>{language === 'hi' ? 'सप्लायर को PO PDF भेजें' : 'Share PO PDF to Supplier'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDownloadBrandPo(group.brand, group.items)}
                          disabled={isDownloadingThis}
                          className="h-10 px-3.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition cursor-pointer"
                          title="Download Brand Purchase Order PDF"
                        >
                          {isDownloadingThis ? (
                            <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                          ) : (
                            <Download className="w-4 h-4" />
                          )}
                          <span>PO PDF</span>
                        </button>
                      </div>
                    </div>

                    {/* Brand Items Table */}
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs text-slate-700">
                        <thead className="bg-slate-100/50 text-slate-500 uppercase text-[10px] tracking-wider border-b border-slate-100 font-extrabold">
                          <tr>
                            <th className="py-3 px-4">#</th>
                            <th className="py-3 px-3">Item Name / Barcode</th>
                            <th className="py-3 px-3 text-center">Current Stock</th>
                            <th className="py-3 px-3 text-center">Reorder Qty</th>
                            <th className="py-3 px-3 text-right">Basic Rate</th>
                            <th className="py-3 px-3 text-right">Est. Total</th>
                            <th className="py-3 px-4 text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {group.items.map((p, idx) => {
                            const reqQty = getItemReorderQty(p);
                            const estItemTotal = (p.basicPurchaseRate || p.landingCost) * reqQty;

                            return (
                              <tr key={p.barcode || (p.id ? `grp-${p.id}` : `grp-p-${idx}`)} className="hover:bg-slate-50/80 transition">
                                <td className="py-3 px-4 font-bold text-slate-400">
                                  {idx + 1}
                                </td>
                                <td className="py-3 px-3">
                                  <p className="font-black text-slate-900 text-xs sm:text-sm">{p.name}</p>
                                  <div className="flex items-center gap-2 mt-0.5">
                                    {p.barcode && (
                                      <span className="text-[10px] font-mono text-slate-400">
                                        {p.barcode}
                                      </span>
                                    )}
                                    <span className="text-[10px] font-semibold text-slate-400">
                                      • Landing: ₹{p.landingCost}
                                    </span>
                                  </div>
                                </td>
                                <td className="py-3 px-3 text-center">
                                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-black bg-rose-50 text-rose-700 border border-rose-200">
                                    {p.stockQty} Pcs Left
                                  </span>
                                </td>
                                <td className="py-3 px-3 text-center">
                                  <div className="inline-flex items-center gap-1.5 bg-slate-50 border border-slate-200 p-1 rounded-xl">
                                    <button
                                      type="button"
                                      onClick={() => p.id && updateItemReorderQty(p.id, reqQty - 1)}
                                      className="w-7 h-7 bg-white hover:bg-slate-200 text-slate-700 rounded-lg font-bold text-xs flex items-center justify-center shadow-2xs cursor-pointer"
                                      title="Decrease qty"
                                    >
                                      -
                                    </button>
                                    <input
                                      type="number"
                                      min="1"
                                      max="9999"
                                      value={reqQty}
                                      onChange={(e) => p.id && updateItemReorderQty(p.id, parseInt(e.target.value, 10) || 1)}
                                      className="w-12 h-7 text-center font-black text-slate-900 text-xs bg-transparent focus:outline-hidden"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => p.id && updateItemReorderQty(p.id, reqQty + 1)}
                                      className="w-7 h-7 bg-white hover:bg-slate-200 text-slate-700 rounded-lg font-bold text-xs flex items-center justify-center shadow-2xs cursor-pointer"
                                      title="Increase qty"
                                    >
                                      +
                                    </button>
                                  </div>
                                </td>
                                <td className="py-3 px-3 text-right font-medium text-slate-600">
                                  ₹{p.basicPurchaseRate || p.landingCost}
                                </td>
                                <td className="py-3 px-3 text-right font-black text-indigo-700">
                                  {formatCurrency(estItemTotal)}
                                </td>
                                <td className="py-3 px-4 text-center">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenAddModal(p)}
                                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 transition cursor-pointer"
                                    title="Edit Product Details"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {/* Brand PO Card Footer */}
                    <div className="bg-slate-50/50 border-t border-slate-100 px-5 py-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs text-slate-500">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>
                          {language === 'hi' 
                            ? `PO PDF में केवल ${group.brand} के सामान और आधिकारिक हैडर शामिल रहेगा।`
                            : `Official isolated Purchase Order PDF ready for ${group.brand} distributorship.`}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 font-bold text-slate-700">
                        <span>Total: <b className="text-slate-900">{brandTotalUnits} Units</b></span>
                        <span>•</span>
                        <span>Est. Val: <b className="text-emerald-700">{formatCurrency(brandEstVal)}</b></span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 3: DEAD STOCK / SLOW-MOVING TRACKER (60+ Days) */}
      {activeSubTab === 'deadstock' && (
        <div className="space-y-4">
          <div className="bg-rose-50/70 border border-rose-200/80 p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <Hourglass className="w-5 h-5 text-rose-600" />
                <h3 className="font-bold text-base text-rose-950">
                  {language === 'hi' ? 'डेड स्टॉक ट्रैकर (60+ दिन से बिना बिक्री)' : 'Dead Stock & Slow-Moving SKUs (>60 Days)'}
                </h3>
              </div>
              <p className="text-xs text-rose-800 mt-1">
                Items with zero sales activity in the last 60-90 days. Consider promotional discount or supplier return.
              </p>
            </div>
            <div className="bg-white border border-rose-200/80 p-4 rounded-2xl text-right shadow-xs">
              <span className="text-[10px] text-slate-400 uppercase font-bold">Total Blocked Capital</span>
              <p className="text-2xl font-black text-rose-600">{formatCurrency(deadStockBlockedCapital)}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {deadStockItems.map((p, idx) => (
              <div key={p.barcode || (p.id ? `dead-${p.id}` : `dead-${idx}`)} className="bg-white border border-slate-100 p-5 rounded-2xl flex justify-between items-center shadow-sm hover:shadow-md transition">
                <div>
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">{p.brand}</span>
                  <h4 className="font-bold text-sm text-slate-900 mt-1.5">{p.name}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Stock: {p.stockQty} Pcs • Capital: <span className="font-bold text-rose-600">₹{(p.landingCost * p.stockQty).toFixed(0)}</span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleOpenAddModal(p)}
                  className="h-10 px-4 bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 rounded-xl cursor-pointer transition"
                >
                  Discount / Edit
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 4: CUSTOM THERMAL BARCODE LABEL GENERATOR */}
      {activeSubTab === 'barcodeGen' && (() => {
        const parsedCopies = stickerCopies === '' ? 0 : Math.max(0, parseInt(stickerCopies, 10) || 0);

        return (
          <div className="space-y-6">
            <div className="bg-white border border-slate-100 p-6 sm:p-7 rounded-2xl space-y-5 shadow-sm">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-bold text-base sm:text-lg text-slate-900">
                    {language === 'hi' ? 'थर्मल बारकोड स्टिकर प्रिंटर (Code128)' : 'Thermal Barcode Sticker Generator (Code128)'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Generate standard 50mm x 25mm barcode stickers for unbranded or loose gift items.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleDownloadStickersPDF}
                    disabled={isGeneratingPdf || parsedCopies === 0}
                    className={`h-11 sm:h-12 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-bold rounded-2xl border border-slate-200/80 flex items-center gap-2 cursor-pointer transition active:scale-95 ${
                      (isGeneratingPdf || parsedCopies === 0) ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isGeneratingPdf ? (
                      <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
                    ) : (
                      <FileDown className="w-4 h-4 text-slate-600" />
                    )}
                    <span>Download Sticker Sheet PDF</span>
                  </button>

                  <button
                    type="button"
                    onClick={handlePrintStickers}
                    className="h-11 sm:h-12 px-5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-black rounded-2xl shadow-lg shadow-indigo-600/25 flex items-center gap-2 cursor-pointer transition active:scale-95"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Sticker Sheet</span>
                  </button>
                </div>
              </div>

              {/* Select Product, Size/Paper & Copies */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs text-slate-600 font-medium mb-1.5 block">Select Item:</label>
                  <select
                    value={selectedBarcodeProduct?.id || ''}
                    onChange={(e) => {
                      const sel = products.find(p => p.id === Number(e.target.value));
                      if (sel) setSelectedBarcodeProduct(sel);
                    }}
                    className="w-full h-11 bg-slate-50 border border-slate-200/80 text-xs text-slate-900 rounded-xl px-3.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-semibold"
                  >
                    {products.map((p, idx) => (
                      <option key={p.barcode || (p.id ? `bc-opt-${p.id}` : `bc-opt-${idx}`)} value={p.id}>{p.brand} - {p.name} (MRP: ₹{p.mrp || p.sellingPrice})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-600 font-medium mb-1.5 block">Sticker Size / Paper Type:</label>
                  <select
                    value={selectedStickerSize}
                    onChange={(e) => setSelectedStickerSize(e.target.value)}
                    className="w-full h-11 bg-slate-50 border border-slate-200/80 text-xs text-slate-900 rounded-xl px-3.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-semibold"
                  >
                    {STICKER_SIZE_PRESETS.map((preset) => (
                      <option key={preset.id} value={preset.id}>
                        {preset.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs text-slate-600 font-medium mb-1.5 block">Number of Stickers:</label>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    placeholder="0"
                    value={stickerCopies}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '') {
                        setStickerCopies('');
                      } else {
                        const num = parseInt(val, 10);
                        if (!isNaN(num)) {
                          setStickerCopies(String(Math.max(0, Math.min(200, num))));
                        }
                      }
                    }}
                    onFocus={(e) => e.target.select()}
                    className="w-full h-11 bg-slate-50 border border-slate-200/80 text-xs text-slate-900 font-bold rounded-xl px-3.5 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                  <div className="flex flex-wrap items-center gap-1.5 mt-2">
                    <span className="text-[10px] text-slate-400 font-semibold">Presets:</span>
                    {[6, 12, 24, 48].map((qty) => (
                      <button
                        key={qty}
                        type="button"
                        onClick={() => setStickerCopies(String(qty))}
                        className="px-2 py-0.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 rounded-md text-[10px] font-bold text-slate-700 transition cursor-pointer"
                      >
                        {qty} Pcs
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Single Preview & Printable Sheet */}
              {selectedBarcodeProduct && (
                <div className="pt-4 border-t border-slate-100 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <p className="text-xs font-bold text-slate-800">
                      Sticker Sheet Preview ({parsedCopies} stickers):
                    </p>
                    <span className="text-[11px] text-indigo-600 font-bold bg-indigo-50 px-2.5 py-0.5 rounded-full w-fit">
                      {currentSizeConfig.name}
                    </span>
                  </div>

                  {parsedCopies === 0 ? (
                    <div className="bg-slate-50 border-2 border-dashed border-slate-200 p-8 rounded-2xl text-center space-y-2">
                      <Barcode className="w-8 h-8 text-slate-300 mx-auto" />
                      <p className="text-xs font-bold text-slate-700">No stickers to display</p>
                      <p className="text-[11px] text-slate-400">
                        Type desired quantity above (e.g. 8, 12, 24) or choose a preset
                      </p>
                    </div>
                  ) : (
                    <div 
                      id="barcode-sticker-sheet" 
                      className={`grid ${currentSizeConfig.gridColsClass} gap-3 bg-slate-50 p-4 sm:p-6 rounded-2xl border border-slate-100`}
                    >
                      {Array.from({ length: parsedCopies }).map((_, idx) => (
                        <BarcodeStickerCard
                          key={`${selectedBarcodeProduct.id}-${idx}-${selectedStickerSize}`}
                          product={selectedBarcodeProduct}
                          shopName={shopProfile.name}
                          sizeConfig={currentSizeConfig}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* PRODUCT ADD / EDIT MODAL */}
      <ProductModal
        isOpen={isProductModalOpen}
        onClose={() => {
          setIsProductModalOpen(false);
          setEditingProduct(null);
        }}
        productToEdit={editingProduct}
      />

      {/* WASTAGE DEDUCTION MODAL */}
      {wastageModalOpen && selectedWastageProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-md p-6 sm:p-7 text-slate-900 shadow-2xl space-y-4 my-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-amber-600" />
                Damage / Wastage Deduction
              </h3>
              <button
                type="button"
                onClick={() => setWastageModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs space-y-1">
              <p className="font-bold text-slate-900 text-sm">{selectedWastageProduct.name}</p>
              <p className="text-slate-400 font-medium">Current Stock: {selectedWastageProduct.stockQty} Pcs | Landing: ₹{selectedWastageProduct.landingCost}</p>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-600 font-medium block mb-1">Deduction Quantity (Pcs):</label>
                <input
                  type="number"
                  min="1"
                  max={selectedWastageProduct.stockQty}
                  value={wastageQty}
                  onChange={(e) => setWastageQty(Math.max(1, Number(e.target.value)))}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 text-slate-900 font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Reason Tag:</label>
                <select
                  value={wastageReason}
                  onChange={(e) => setWastageReason(e.target.value as WastageReason)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 text-slate-900 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Broken">Broken (टूट-फूट)</option>
                  <option value="Damaged">Damaged (खराब / स्क्रैच)</option>
                  <option value="Defect">Manufacturing Defect</option>
                  <option value="Sample">Display Sample Loss</option>
                </select>
              </div>

              <div>
                <label className="text-slate-600 font-medium block mb-1">Notes / Remarks:</label>
                <input
                  type="text"
                  value={wastageNotes}
                  onChange={(e) => setWastageNotes(e.target.value)}
                  placeholder="e.g. Glass chipped during transit"
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3 text-slate-900 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="bg-rose-50 border border-rose-100 p-3 rounded-2xl text-center text-xs text-rose-800">
                Total Store Loss: <b className="text-rose-950 font-black text-sm">₹{(wastageQty * selectedWastageProduct.landingCost).toFixed(2)}</b>
              </div>

              <button
                type="button"
                onClick={handleConfirmWastage}
                className="w-full h-13 bg-rose-600 hover:bg-rose-700 text-white font-black text-sm rounded-2xl shadow-lg transition cursor-pointer"
              >
                Confirm Stock Deduction
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Manager Modal */}
      <CategoryManagerModal
        isOpen={isCatManagerOpen}
        onClose={() => setIsCatManagerOpen(false)}
      />
    </div>
  );
};
