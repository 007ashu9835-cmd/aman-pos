import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  CalendarDays,
  BarChart3,
  Package, 
  Truck, 
  FileSpreadsheet, 
  Users2, 
  Settings, 
  AlertTriangle,
  Zap,
  RefreshCw,
  Sliders,
  ChevronDown,
  ChevronRight,
  CheckCircle2
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, lowStockProducts, cart, shopProfile } = useApp();
  
  // Accordion state for Utilities & Settings section
  const [isUtilitiesOpen, setIsUtilitiesOpen] = useState<boolean>(() => {
    // Open by default if current active tab is one of the utility tabs
    return ['reports', 'khata', 'data-sync', 'settings'].includes(activeTab);
  });

  const coreNavItems = [
    {
      id: 'dashboard',
      label: 'Dashboard & Brands',
      icon: LayoutDashboard
    },
    {
      id: 'pos',
      label: 'New Billing / POS',
      icon: Zap,
      badge: cart.length > 0 ? `${cart.length}` : undefined,
      badgeColor: 'bg-indigo-600 text-white shadow-xs'
    },
    {
      id: 'inventory',
      label: 'Stock / Inventory',
      icon: Package,
      badge: lowStockProducts.length > 0 ? `${lowStockProducts.length}` : undefined,
      badgeColor: 'bg-amber-100 border border-amber-300 text-amber-900 font-bold'
    },
    {
      id: 'daily-sales',
      label: 'Daily Sales Log',
      icon: CalendarDays,
      sublabel: 'दैनिक बिक्री'
    },
    {
      id: 'monthly-sales',
      label: 'Monthly Sales Report',
      icon: BarChart3,
      sublabel: 'मासिक रिपोर्ट'
    },
    {
      id: 'purchases',
      label: 'Purchase / Inward',
      icon: Truck
    }
  ];

  const utilityNavItems = [
    {
      id: 'reports',
      label: 'GST & CA Reports',
      icon: FileSpreadsheet
    },
    {
      id: 'khata',
      label: 'Khata / Party Ledger',
      icon: Users2
    },
    {
      id: 'data-sync',
      label: '🔄 Cloud & Sync',
      icon: RefreshCw,
      badge: 'Hub',
      badgeColor: 'bg-indigo-100 text-indigo-800 font-bold border border-indigo-200'
    },
    {
      id: 'settings',
      label: 'Shop Settings',
      icon: Settings
    }
  ];

  return (
    <aside className="w-68 bg-white border-r border-slate-100 flex flex-col justify-between shrink-0 select-none shadow-xs">
      {/* Navigation Links */}
      <div className="p-3 space-y-3 overflow-y-auto">
        
        {/* Core Operations Section */}
        <div className="space-y-1">
          <div className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500">
            STORE OPERATIONS
          </div>

          {coreNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full h-10 flex items-center justify-between px-3.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'text-slate-700 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span className="truncate text-xs font-bold">{item.label}</span>
                </div>

                {item.badge && (
                  <span className={`px-2 py-0.5 text-[10px] rounded-full font-bold ml-1.5 shrink-0 ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Utilities & Settings Accordion Section */}
        <div className="space-y-1 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={() => setIsUtilitiesOpen(!isUtilitiesOpen)}
            className="w-full px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded-lg flex items-center justify-between transition cursor-pointer"
          >
            <div className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="font-bold">UTILITIES & SETTINGS</span>
            </div>
            <div className="p-0.5 rounded text-slate-400 hover:text-slate-700">
              {isUtilitiesOpen ? (
                <ChevronDown className="w-3.5 h-3.5 shrink-0 text-slate-600" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 shrink-0 text-slate-500" />
              )}
            </div>
          </button>

          {/* Collapsible Utility Items */}
          {isUtilitiesOpen && (
            <div className="space-y-1 mt-1 pl-1 transition-all duration-200">
              {utilityNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full h-10 flex items-center justify-between px-3.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                        : 'text-slate-700 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      <span className="truncate text-xs font-bold">{item.label}</span>
                    </div>

                    {item.badge && (
                      <span className={`px-2 py-0.5 text-[10px] rounded-full font-bold ml-1.5 shrink-0 ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

      </div>

      {/* Footer Info Box */}
      <div className="p-3.5 border-t border-slate-100 bg-slate-50/50 text-[11px] text-slate-500 space-y-2.5">
        {lowStockProducts.length > 0 && (
          <div 
            onClick={() => setActiveTab('inventory')}
            className="flex items-center gap-2 p-2.5 rounded-2xl bg-amber-50 border border-amber-200/80 text-amber-900 cursor-pointer hover:bg-amber-100/80 transition shadow-xs"
          >
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
            <span className="truncate font-bold text-xs">
              {`${lowStockProducts.length} items low in stock`}
            </span>
          </div>
        )}

        <div className="text-[10px] text-slate-400 text-center space-y-0.5 pt-1">
          <p className="font-bold text-slate-700">{shopProfile?.name ? `${shopProfile.name} ERP` : 'Aman Gift Gallery ERP'}</p>
          <p className="font-bold text-slate-500">
            {shopProfile?.address 
              ? `${shopProfile.address}${shopProfile.city ? `, ${shopProfile.city}` : ''}${shopProfile.state ? ` (${shopProfile.state})` : ''}` 
              : 'Upper Bazar, Ranchi (JH)'}
          </p>
        </div>
      </div>
    </aside>
  );
};
