import React, { useState, useEffect } from 'react';
import { signOut } from 'firebase/auth';
import { auth } from '../../lib/firebase';
import { useApp } from '../../context/AppContext';
import { 
  Store, 
  Languages, 
  Wifi, 
  WifiOff, 
  Barcode, 
  RefreshCw,
  LogOut
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    shopProfile, 
    isOnline, 
    isCloudSyncing,
    cloudUser
  } = useApp();

  const [timeStr, setTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSafeLogout = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      if (auth) {
        await signOut(auth);
      }
    } catch (err) {
      console.error("Firebase signOut error:", err);
    } finally {
      // Only remove cloud session flag, KEEP PIN and custom settings intact
      localStorage.removeItem('firebase_cloud_authenticated');
      localStorage.removeItem('cloud_user_account');
      localStorage.removeItem('app_master_uid');
      localStorage.setItem('app_force_relogin', 'true');
      sessionStorage.clear();
      
      // Smoothly reset auth gatekeeper state to Step 1
      window.dispatchEvent(new CustomEvent('app_lock_required'));
    }
  };

  return (
    <header className="flex justify-between items-center px-4 sm:px-5 py-3 bg-gradient-to-r from-indigo-950 via-indigo-900 to-indigo-800 border-b border-indigo-700/40 shadow-md gap-4 text-white shrink-0 z-30 sticky top-0 select-none w-full">
      {/* 1. LEFT SECTION (Branding) */}
      <div className="flex items-center gap-3 shrink-0">
        {shopProfile.logoUrl ? (
          <img 
            src={shopProfile.logoUrl} 
            alt={shopProfile.name} 
            className="h-10 w-10 object-contain rounded-lg bg-indigo-950/60 p-0.5 border border-indigo-600/40 shrink-0 shadow-sm"
          />
        ) : (
          <div className="h-10 w-10 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black shrink-0 shadow-sm border border-indigo-400/30">
            <Store className="w-5 h-5" />
          </div>
        )}
        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-base sm:text-lg font-extrabold text-white tracking-tight leading-tight truncate max-w-[180px] sm:max-w-xs md:max-w-sm">
              {shopProfile.name}
            </h1>
            {shopProfile.city && (
              <span className="hidden sm:inline-block px-2 py-0.5 bg-indigo-950/70 text-indigo-300 font-mono text-[10px] font-bold rounded border border-indigo-500/30 shrink-0">
                {shopProfile.city}
              </span>
            )}
          </div>
          <p className="text-xs text-indigo-200 font-medium truncate max-w-[180px] sm:max-w-xs">
            {shopProfile.tagline || (language === 'hi' ? 'स्मार्ट बिलिंग एवं इन्वेंटरी सिस्टम' : 'Smart Billing & Inventory ERP')}
          </p>
        </div>
      </div>

      {/* 2. CENTER SECTION (Status Indicators) */}
      <div className="flex items-center gap-3 hidden md:flex">
        {/* WiFi / Cloud Sync Status */}
        {isOnline ? (
          <div 
            title={cloudUser ? `Cloud Sync Live (${cloudUser.email})` : 'Cloud & Network Online'}
            className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 shadow-2xs whitespace-nowrap"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
            <Wifi className="w-3.5 h-3.5 shrink-0" />
            <span>{cloudUser ? (language === 'hi' ? 'क्लाउड सिंक लाइव' : 'Cloud Sync Live') : (language === 'hi' ? 'ऑनलाइन' : 'Online Sync')}</span>
            {isCloudSyncing && <RefreshCw className="w-3 h-3 text-emerald-300 animate-spin shrink-0 ml-0.5" />}
          </div>
        ) : (
          <div 
            title="100% Offline Mode (Local IndexedDB Active)"
            className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1.5 shadow-2xs whitespace-nowrap"
          >
            <WifiOff className="w-3.5 h-3.5 shrink-0" />
            <span>{language === 'hi' ? 'ऑफ़लाइन मोड' : 'Offline Mode'}</span>
          </div>
        )}

        {/* Barcode Scanner Status */}
        <div 
          title="Hardware Barcode Scanner Ready & Listening"
          className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-950/60 text-blue-300 border border-blue-400/30 flex items-center gap-1.5 shadow-2xs whitespace-nowrap"
        >
          <Barcode className="w-3.5 h-3.5 shrink-0" />
          <span>{language === 'hi' ? 'स्कैनर सक्रिय' : 'Scanner Ready'}</span>
        </div>
      </div>

      {/* 3. RIGHT SECTION (Quick Actions & Logout) */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Language Switcher */}
        <button
          type="button"
          onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-950/60 hover:bg-indigo-950/80 text-white rounded-lg text-xs font-semibold border border-indigo-500/30 transition cursor-pointer shadow-2xs"
          title="Toggle English / हिंदी"
        >
          <Languages className="w-3.5 h-3.5 text-indigo-300 shrink-0" />
          <span>{language === 'en' ? 'हिंदी' : 'English'}</span>
        </button>

        {/* Live Clock (Optional Large Display) */}
        {timeStr && (
          <div className="hidden xl:block font-mono text-xs text-indigo-200 bg-indigo-950/50 px-2.5 py-1.5 rounded-lg border border-indigo-500/30 font-bold">
            {timeStr}
          </div>
        )}

        {/* Logout Button */}
        <button
          type="button"
          id="btn-header-master-logout"
          onClick={handleSafeLogout}
          title="Log Out & Lock Application"
          className="bg-red-600 hover:bg-red-700 text-white font-semibold text-xs px-3.5 py-2 rounded-lg flex items-center gap-2 shadow-sm transition-all cursor-pointer active:scale-95 shrink-0"
        >
          <LogOut className="w-3.5 h-3.5 shrink-0" />
          <span>Log Out</span>
        </button>
      </div>
    </header>
  );
};
