import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { db, DEFAULT_SHOP_PROFILE } from '../../db';
import { 
  Cloud, 
  DownloadCloud, 
  Sparkles, 
  Trash2, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  FileSpreadsheet, 
  ExternalLink,
  ShieldAlert,
  ArrowRight,
  Database,
  TrendingUp,
  BarChart3,
  Calendar,
  Layers,
  ShoppingBag,
  UploadCloud,
  Download,
  Smartphone,
  Monitor,
  Zap
} from 'lucide-react';
import { 
  fetchGoogleStockSheetDirect, 
  fetchGoogleSalesSheetDirect,
  fetchGoogleSheetData,
  parseSheetRows,
  parseSalesSheetAndAutoLink,
  MonthlySalesAggregate,
  parseCSVToTable,
  extractMrpAndCleanName,
  dissectItemSemantic
} from '../../utils/aiSyncEngine';
import { Product, Invoice } from '../../types';
import { writeBatchToCloud, batchSaveToInventory, saveItemToDb, addItem, saveItemToCloudDb } from '../../lib/firebase';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { CloudSyncSection } from './CloudSyncSection';
import confetti from 'canvas-confetti';

export const DataSyncView: React.FC = () => {
  const { 
    sheetsConfig, 
    updateSheetsConfig, 
    products, 
    setInventory,
    refreshData, 
    wipeAllData, 
    playBeep,
    registerDiscoveredCategories,
    isCloudSyncEnabled,
    setIsCloudSyncEnabled,
    cloudSyncStatus,
    lastCloudSyncTimestamp,
    cloudSyncedProductsCount,
    cloudSyncedInvoicesCount,
    pushAllLocalToCloud,
    pullAllFromCloud,
    isCloudSyncing
  } = useApp();

  const [firebaseSuccessMsg, setFirebaseSuccessMsg] = useState<string | null>(null);
  const [firebaseErrorMsg, setFirebaseErrorMsg] = useState<string | null>(null);

  // Card 1: Google Sheet Sync state
  const [sheetUrl, setSheetUrl] = useState<string>(
    sheetsConfig?.sheetId 
      ? `https://docs.google.com/spreadsheets/d/${sheetsConfig.sheetId}/edit` 
      : 'https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit'
  );
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [syncStats, setSyncStats] = useState<{ 
    products: number; 
    updated: number; 
    brands: number;
    salesInvoices: number;
    totalRevenue: number;
    totalProfit: number;
    monthlyAggregates: MonthlySalesAggregate[];
  } | null>(null);

  // Card 2: Smart Auto-Fix state
  const [isFixing, setIsFixing] = useState<boolean>(false);
  const [fixSuccessMsg, setFixSuccessMsg] = useState<string | null>(null);

  // Card 3: Danger Zone state
  const [isWiping, setIsWiping] = useState<boolean>(false);
  const [showWipeConfirm, setShowWipeConfirm] = useState<boolean>(false);

  // ----------------------------------------------------
  // Handler 1: Direct Google Sheet Sync (Cloud Database Save)
  // ----------------------------------------------------
  async function handleGoogleSheetSync(sheetUrlInput?: string) {
    const targetUrl = typeof sheetUrlInput === 'string' && sheetUrlInput.trim() ? sheetUrlInput : sheetUrl;
    try {
      setIsSyncing(true);
      setSyncError(null);
      setSyncStatus('Fetching Google Sheet data & syncing directly to Cloud DB...');
      playBeep('scan');

      const rawData = await fetchGoogleSheetData(targetUrl);
      const parsedItems = parseSheetRows(rawData); // map your sheet items
      
      // 1. DIRECT DATABASE SAVE (Uses exact same method as Manual Add)
      for (const item of parsedItems) {
        await saveItemToCloudDb(item); // or addDoc(collection(db, 'inventory'), item)
      }
      
      // 2. TRIGGER STATE UPDATE
      setInventory(parsedItems);

      // Keep local Dexie cache & categories updated
      const discoveredCategories = Array.from(new Set(parsedItems.map(p => p.Category || p.category).filter(Boolean)));
      if (discoveredCategories.length > 0) {
        await registerDiscoveredCategories(discoveredCategories as string[]);
      }
      await refreshData();

      setSyncStats({
        products: parsedItems.length,
        updated: parsedItems.length,
        brands: new Set(parsedItems.map(p => p.brand || p.Brand).filter(Boolean)).size,
        salesInvoices: 0,
        totalRevenue: 0,
        totalProfit: 0,
        monthlyAggregates: []
      });

      setSyncStatus(`✓ Synced ${parsedItems.length} items to Cloud Successfully!`);
      playBeep('success');
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
      alert("Synced to Cloud Successfully!");
    } catch (err: any) {
      console.error("Cloud Sync Error:", err);
      setSyncError(err?.message || "Cloud Sync Error");
      playBeep('alert');
    } finally {
      setIsSyncing(false);
    }
  }

  const handleSyncStockAndSales = () => handleGoogleSheetSync(sheetUrl);

  // ----------------------------------------------------
  // Handler 2: Smart Auto-Fix (Fix MRP & Brands)
  // Cleans '/, -, @' from titles and assigns true MRP
  // ----------------------------------------------------
  const handleFixMrpAndBrands = async () => {
    if (isFixing || products.length === 0) return;
    try {
      setIsFixing(true);
      setFixSuccessMsg(null);
      playBeep('scan');

      let fixedCount = 0;
      const allDbProducts = await db.products.toArray();

      for (const prod of allDbProducts) {
        if (!prod.id) continue;

        const dissected = dissectItemSemantic(prod.name, prod.category, prod.brand);
        const { cleanName, extractedMrp } = extractMrpAndCleanName(prod.name);

        let needsUpdate = false;
        const updates: Partial<typeof prod> = {};

        // 1. Clean product title if it contained trailing delimiters or rates
        if (cleanName && cleanName !== prod.name && cleanName.length >= 2) {
          updates.name = cleanName;
          needsUpdate = true;
        }

        // 2. Assign true MRP if extracted from title and different
        if (extractedMrp && extractedMrp > 0 && prod.mrp !== extractedMrp) {
          updates.mrp = extractedMrp;
          updates.sellingPrice = extractedMrp;
          needsUpdate = true;
        }

        // 3. Improve brand if previously 'General' or empty
        if ((!prod.brand || prod.brand === 'General' || prod.brand === 'Unbranded') && dissected.brand && dissected.brand !== 'General') {
          updates.brand = dissected.brand;
          needsUpdate = true;
        }

        if (needsUpdate) {
          await db.products.update(prod.id, updates);
          fixedCount++;
        }
      }

      await refreshData();
      setFixSuccessMsg(`✓ Fixed & optimized ${fixedCount} product titles, MRPs, and brand tags!`);
      playBeep('success');
      confetti({ particleCount: 40, spread: 50, origin: { y: 0.6 } });
    } catch (err: any) {
      console.error('Smart Auto-Fix error:', err);
      playBeep('alert');
    } finally {
      setIsFixing(false);
    }
  };

  // ----------------------------------------------------
  // Handler 3: Danger Zone (Clear All App Data)
  // Executes localStorage.clear() and resets state
  // ----------------------------------------------------
  const handleClearAllAppData = async () => {
    try {
      setIsWiping(true);
      playBeep('alert');

      // Clear all browser storage keys completely
      try {
        localStorage.clear();
        sessionStorage.clear();
      } catch (e) {
        console.warn('Storage clear error:', e);
      }

      // Mark app_data_wiped to prevent any mock data seeding on fresh boot
      localStorage.setItem('app_data_wiped', 'true');

      // Purge all IndexedDB tables completely
      await db.products.clear();
      await db.invoices.clear();
      await db.purchases.clear();
      await db.wastage.clear();
      await db.parties.clear();
      await db.khataTransactions.clear();
      await db.settings.clear();

      // Ensure minimal clean shop profile exists
      await db.settings.put({
        key: 'shopProfile',
        value: DEFAULT_SHOP_PROFILE
      });

      // Clear in-memory global state stores via wipeAllData
      await wipeAllData();

      // Force immediate full page reload for a totally clean 0-item blank canvas
      window.location.reload();
    } catch (err: any) {
      console.error('Nuclear wipe error:', err);
      setIsWiping(false);
      setShowWipeConfirm(false);
      playBeep('alert');
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-slate-50">
      {/* Header Banner */}
      <div className="bg-white border-b border-slate-200 px-6 py-5 shrink-0">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-xs">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                Cloud & Data Synchronization
                <span className="text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
                  Stock & Monthly Sales
                </span>
              </h1>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Sync live inventory & monthly sales reports from Google Sheets, auto-link SKUs, or clean titles & MRPs.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start sm:self-auto">
            <div className="px-3.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold text-slate-700 flex items-center gap-2">
              <Database className="w-3.5 h-3.5 text-indigo-600" />
              <span>Current Stock: <strong className="text-slate-900">{products.length}</strong> items</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cloud Master Sync Section */}
      <div className="max-w-6xl mx-auto w-full px-6 pt-6">
        <CloudSyncSection />
      </div>

      {/* 3 Action Cards */}
      <div className="max-w-6xl mx-auto w-full p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

          {/* ============================================================ */}
          {/* Card 1: 📥 Google Sheet Sync (Stock & Monthly Sales) */}
          {/* ============================================================ */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-indigo-300 transition group">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
                  <DownloadCloud className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Stock + Sales Sync
                </span>
              </div>

              <div>
                <h2 className="text-base font-black text-slate-900">1. Google Sheet Sync</h2>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Fetches live Stock inventory (Col E Purchase, Col J MRP) and Daily/Monthly Sales records auto-linked by SKU.
                </p>
              </div>

              {/* Input field for Sheet URL */}
              <div className="space-y-1.5 pt-1">
                <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                  Google Sheet URL / Link
                </label>
                <input
                  type="url"
                  id="input-sheet-url-sync"
                  value={sheetUrl}
                  onChange={(e) => setSheetUrl(e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 font-mono text-slate-700 transition"
                  disabled={isSyncing}
                />
              </div>

              {/* Status / Feedback info */}
              {syncStatus && (
                <div className="p-3 rounded-xl bg-emerald-50/90 border border-emerald-200 text-emerald-950 text-xs font-semibold flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{syncStatus}</span>
                </div>
              )}

              {syncError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-medium flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{syncError}</span>
                </div>
              )}

              {syncStats && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
                  <div className="p-2 bg-slate-50 rounded-xl border border-slate-100 text-center">
                    <div className="text-slate-400 font-medium">Products</div>
                    <div className="text-slate-900 font-black text-sm">{syncStats.products}</div>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-xl border border-slate-100 text-center">
                    <div className="text-slate-400 font-medium">Sales Invoices</div>
                    <div className="text-emerald-700 font-black text-sm">{syncStats.salesInvoices}</div>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-xl border border-slate-100 text-center">
                    <div className="text-slate-400 font-medium">Revenue</div>
                    <div className="text-indigo-700 font-black text-xs">₹{formatNumber(syncStats.totalRevenue)}</div>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-xl border border-slate-100 text-center">
                    <div className="text-slate-400 font-medium">Profit</div>
                    <div className="text-emerald-600 font-black text-xs">₹{formatNumber(syncStats.totalProfit)}</div>
                  </div>
                </div>
              )}
            </div>

            {/* One-click "Sync Stock & Sales" button with loading spinner */}
            <div className="pt-5 mt-4 border-t border-slate-100">
              <button
                type="button"
                id="btn-sync-stock-sales"
                onClick={handleSyncStockAndSales}
                disabled={isSyncing}
                className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                {isSyncing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Syncing Stock & Monthly Sales...</span>
                  </>
                ) : (
                  <>
                    <DownloadCloud className="w-4 h-4" />
                    <span>Sync Stock & Monthly Sales</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* ============================================================ */}
          {/* Card 2: 🏷️ Smart Auto-Fix */}
          {/* ============================================================ */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-indigo-300 transition group">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                  <Sparkles className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                  Auto Clean
                </span>
              </div>

              <div>
                <h2 className="text-base font-black text-slate-900">2. Smart Auto-Fix</h2>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  Cleans trailing <code className="font-mono text-[11px] bg-slate-100 px-1 py-0.5 rounded text-indigo-700">/</code>, <code className="font-mono text-[11px] bg-slate-100 px-1 py-0.5 rounded text-indigo-700">-</code>, <code className="font-mono text-[11px] bg-slate-100 px-1 py-0.5 rounded text-indigo-700">@</code> from item titles, extracts true MRP, and detects brand names.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2 text-xs text-slate-600">
                <div className="font-bold text-slate-800 text-[11px] uppercase tracking-wider">Example Transformation:</div>
                <div className="space-y-1 font-mono text-[11px]">
                  <div className="text-rose-600 bg-rose-50/60 p-1.5 rounded line-through truncate">
                    "Milton Thermosteel 1000ml 949/"
                  </div>
                  <div className="text-emerald-700 bg-emerald-50/80 p-1.5 rounded font-bold truncate">
                    → Name: "Milton Thermosteel 1000ml" | MRP: ₹949
                  </div>
                </div>
              </div>

              {fixSuccessMsg && (
                <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-semibold flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <span className="leading-snug">{fixSuccessMsg}</span>
                </div>
              )}
            </div>

            {/* Button: "Fix MRP & Brands" */}
            <div className="pt-5 mt-4 border-t border-slate-100">
              <button
                type="button"
                id="btn-fix-mrp-brands"
                onClick={handleFixMrpAndBrands}
                disabled={isFixing || products.length === 0}
                className="w-full h-11 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white font-black text-xs rounded-xl shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                {isFixing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Cleaning Titles & MRPs...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Fix MRP & Brands</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* ============================================================ */}
          {/* Card 3: 🗑️ Danger Zone */}
          {/* ============================================================ */}
          <div className="bg-white rounded-3xl border border-red-200 p-5 shadow-xs flex flex-col justify-between hover:border-red-300 transition group bg-gradient-to-b from-white to-red-50/30">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-2xl bg-red-50 border border-red-100 flex items-center justify-center text-red-600">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-100 text-red-800">
                  Danger Zone
                </span>
              </div>

              <div>
                <h2 className="text-base font-black text-red-950">3. Danger Zone</h2>
                <p className="text-xs text-red-700/80 mt-1 leading-relaxed">
                  Executes <code className="font-mono text-[11px] bg-red-100/70 px-1 py-0.5 rounded text-red-900">localStorage.clear()</code>, purges all IndexedDB tables, and resets app to a clean 0-item state.
                </p>
              </div>

              <div className="p-3.5 bg-red-50/60 rounded-2xl border border-red-200/80 text-[11px] text-red-800 space-y-1.5">
                <div className="font-bold flex items-center gap-1.5 text-red-900">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                  Irreversible Action
                </div>
                <p className="leading-snug">
                  Wipes all local inventory, invoices, sales ledger, and cashier history. Reloads fresh.
                </p>
              </div>
            </div>

            {/* Red button: "Clear All App Data" */}
            <div className="pt-5 mt-4 border-t border-red-100">
              {showWipeConfirm ? (
                <div className="space-y-2">
                  <p className="text-[11px] font-bold text-center text-red-700">Are you sure? This cannot be undone.</p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setShowWipeConfirm(false)}
                      disabled={isWiping}
                      className="h-9 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      id="btn-confirm-nuclear-wipe"
                      onClick={handleClearAllAppData}
                      disabled={isWiping}
                      className="h-9 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-md shadow-red-600/30 flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50"
                    >
                      {isWiping ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Trash2 className="w-3.5 h-3.5" />
                      )}
                      <span>Yes, Wipe All</span>
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  id="btn-clear-all-app-data"
                  onClick={() => setShowWipeConfirm(true)}
                  disabled={isWiping}
                  className="w-full h-11 bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white font-black text-xs rounded-xl shadow-md shadow-red-600/20 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Clear All App Data</span>
                </button>
              )}
            </div>
          </div>

        </div>

        {/* Monthly Breakdown Performance Preview when synced */}
        {syncStats && syncStats.monthlyAggregates && syncStats.monthlyAggregates.length > 0 && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <BarChart3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">Synchronized 2026 Monthly Sales Performance</h3>
                  <p className="text-xs text-slate-500">Live aggregated metrics calculated directly from synced sales receipts</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
                  Total Synced: ₹{formatNumber(syncStats.totalRevenue)}
                </span>
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-100">
                  Total Profit: ₹{formatNumber(syncStats.totalProfit)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              {syncStats.monthlyAggregates.slice(0, 8).map((m, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 flex flex-col justify-between space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black text-slate-800">{m.monthName.slice(0, 3)} 2026</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-200/70 text-slate-700">
                      {m.invoiceCount} bills
                    </span>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">Revenue</div>
                    <div className="text-xs font-black text-indigo-900">₹{formatNumber(m.revenue)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">Profit</div>
                    <div className="text-xs font-bold text-emerald-700">₹{formatNumber(m.profit)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Helpful Tips Section */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs text-xs text-slate-600 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="font-bold text-slate-900 flex items-center gap-2">
              <span className="text-base">💡</span>
              Need to view the Monthly Sales Report or Revenue Charts?
            </div>
            <p className="text-slate-500">
              Navigate to the <strong>Monthly Sales Report</strong> or <strong>Dashboard</strong> module from the top navigation to analyze detailed month-wise graphs and breakdowns.
            </p>
          </div>
          <a
            href={sheetUrl}
            target="_blank"
            rel="noreferrer"
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-1.5 transition shrink-0 cursor-pointer"
          >
            <span>Open Google Sheet</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
          </a>
        </div>
      </div>
    </div>
  );
};
