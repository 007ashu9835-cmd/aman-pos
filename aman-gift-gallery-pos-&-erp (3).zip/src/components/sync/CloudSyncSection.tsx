import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Cloud, 
  UploadCloud, 
  DownloadCloud, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  LogOut, 
  Smartphone, 
  Monitor, 
  Layers, 
  Database, 
  User, 
  Sparkles,
  ShieldCheck,
  Check,
  Send,
  Zap,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CloudSyncSectionProps {
  language?: 'en' | 'hi';
  compact?: boolean;
}

export const CloudSyncSection: React.FC<CloudSyncSectionProps> = ({ 
  language = 'en',
  compact = false 
}) => {
  const {
    isCloudSyncEnabled,
    setIsCloudSyncEnabled,
    cloudSyncStatus,
    lastCloudSyncTimestamp,
    cloudSyncedProductsCount,
    cloudSyncedInvoicesCount,
    pushAllLocalToCloud,
    pullAllFromCloud,
    isCloudSyncing,
    cloudUser,
    loginWithEmailAccount,
    registerWithEmailAccount,
    sendPasswordResetLink,
    products,
    masterCategories,
    isOnline
  } = useApp();

  // Auth Form State
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState<string>('007ashu9835@gmail.com');
  const [password, setPassword] = useState<string>('');
  const [shopOwnerName, setShopOwnerName] = useState<string>('Ashu / Store Admin');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccess, setAuthSuccess] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Manual Sync trigger state
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  // Quick helper to detect device environment
  const isMobile = typeof window !== 'undefined' && /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccess(null);

    if (!email.trim()) {
      setAuthError(language === 'hi' ? 'कृपया ईमेल पता दर्ज करें' : 'Please enter a valid email address.');
      return;
    }

    if (authMode !== 'forgot' && (!password || password.length < 6)) {
      setAuthError(language === 'hi' ? 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए' : 'Password must be at least 6 characters.');
      return;
    }

    try {
      setIsSubmitting(true);
      if (authMode === 'login') {
        await loginWithEmailAccount(email, password);
        setAuthSuccess(language === 'hi' ? 'सफलतापूर्वक लॉग इन किया गया! डेटा सिंक हो रहा है...' : 'Signed in successfully! Multi-device sync active.');
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      } else if (authMode === 'register') {
        await registerWithEmailAccount(email, password, shopOwnerName);
        setAuthSuccess(language === 'hi' ? 'खाता बनाया गया और क्लाउड सिंक चालू हो गया!' : 'Cloud account created & local records synced!');
        confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
      } else if (authMode === 'forgot') {
        await sendPasswordResetLink(email);
        setAuthSuccess(language === 'hi' ? 'पासवर्ड रीसेट लिंक आपके ईमेल पर भेज दिया गया है।' : 'Password reset link sent to your email.');
        setTimeout(() => setAuthMode('login'), 3000);
      }
    } catch (err: any) {
      console.error('Cloud auth error:', err);
      let msg = err.message || 'Authentication error';
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found') {
        msg = language === 'hi' ? 'अमान्य ईमेल या पासवर्ड। कृपया पुनः प्रयास करें।' : 'Invalid email or password. If new, please switch to Register.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = language === 'hi' ? 'यह ईमेल पहले से पंजीकृत है। कृपया लॉगिन करें।' : 'This email is already in use. Please switch to Login.';
      } else if (err.code === 'auth/network-request-failed') {
        msg = language === 'hi' ? 'नेटवर्क समस्या। कृपया इंटरनेट जांचें।' : 'Network error. Please check your internet connection.';
      }
      setAuthError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleManualPush = async () => {
    try {
      setSyncFeedback('Pushing all local inventory & sales to Firestore Cloud...');
      const res = await pushAllLocalToCloud();
      setSyncFeedback(`✓ Successfully pushed ${res.productsCount} products & ${res.invoicesCount} invoices to Cloud!`);
      confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
      setTimeout(() => setSyncFeedback(null), 5000);
    } catch (err: any) {
      setSyncFeedback(`Sync failed: ${err.message || 'Cloud connection error'}`);
    }
  };

  const handleManualPull = async () => {
    try {
      setSyncFeedback('Pulling latest data from Firestore Cloud...');
      const res = await pullAllFromCloud();
      setSyncFeedback(`✓ Successfully loaded ${res.productsCount} products & ${res.invoicesCount} invoices from Cloud!`);
      confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
      setTimeout(() => setSyncFeedback(null), 5000);
    } catch (err: any) {
      setSyncFeedback(`Pull failed: ${err.message || 'Cloud connection error'}`);
    }
  };

  return (
    <div 
      id="section-cloud-data-sync-account" 
      className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-6 overflow-hidden relative"
    >
      {/* Top Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-600/25 shrink-0">
            <Cloud className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                {language === 'hi' ? 'क्लाउड डेटा सिंक व मास्टर अकाउंट' : 'Cloud Data Sync & Master Account'}
              </h2>
              <span className={`text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full flex items-center gap-1.5 ${
                cloudUser ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${cloudUser ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`}></span>
                {cloudUser ? 'Logged In (Auto-Sync)' : 'Local Storage Only'}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {language === 'hi'
                ? 'मास्टर ईमेल से PC डेस्कटॉप व मोबाइल दोनों पर एक साथ बिलिंग, स्टॉक और बिक्री डेटा लाइव सिंक करें।'
                : 'Log in with your Master Email to seamlessly synchronize all sales, stock, and billing across PC (.exe) & Mobile.'}
            </p>
          </div>
        </div>

        {/* Master Cloud Toggle */}
        <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-2xl p-2 px-3.5 self-start sm:self-auto shrink-0">
          <div className="text-left">
            <div className="text-xs font-bold text-slate-800">
              {language === 'hi' ? 'क्लाउड सिंक' : 'Live Cloud Sync'}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              {isCloudSyncEnabled ? 'Real-Time Active' : 'Paused / Offline'}
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={isCloudSyncEnabled}
            id="toggle-master-cloud-sync"
            onClick={() => setIsCloudSyncEnabled(!isCloudSyncEnabled)}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
              isCloudSyncEnabled ? 'bg-indigo-600' : 'bg-slate-300'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                isCloudSyncEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Main Body: Logged In Card vs Login / Register Form */}
      {cloudUser ? (
        /* ============================================================ */
        /* Logged In Master Profile & Live Sync Hub                      */
        /* ============================================================ */
        <div className="space-y-6">
          {/* Account Profile Card */}
          <div className="bg-gradient-to-br from-indigo-50/70 via-white to-slate-50 border border-indigo-100 rounded-2xl p-5 shadow-xs">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                {cloudUser.photoURL ? (
                  <img 
                    src={cloudUser.photoURL} 
                    alt={cloudUser.displayName || 'User'} 
                    className="w-12 h-12 rounded-2xl object-cover border-2 border-indigo-200 shadow-xs shrink-0" 
                  />
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-black text-lg flex items-center justify-center shadow-md shadow-indigo-600/20 shrink-0">
                    {(cloudUser.displayName || cloudUser.email || 'A')[0].toUpperCase()}
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-sm text-slate-900">
                      {cloudUser.displayName || 'Master Store Admin'}
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Verified Master
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-600 mt-0.5">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono font-semibold">{cloudUser.email}</span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-1 font-medium">
                    <span className="flex items-center gap-1 text-indigo-700">
                      {isMobile ? <Smartphone className="w-3 h-3" /> : <Monitor className="w-3 h-3" />}
                      {isMobile ? 'Active on Mobile Web' : 'Active on PC Desktop / Web'}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-700 font-bold">
                      {isOnline ? '🟢 Connected to Cloud' : '🟡 Offline (Local IndexedDB)'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Connected Active Badge */}
              <div className="flex items-center gap-2 shrink-0">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-100/90 text-emerald-800 text-xs font-black border border-emerald-300 shadow-2xs">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'hi' ? 'क्लाउड सिंक सक्रिय' : 'SYNC LIVE'}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Sync Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-1">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                <span>Products in Cloud</span>
                <Database className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-lg font-black text-slate-900">
                {cloudSyncedProductsCount || products.length} <span className="text-xs font-normal text-slate-400">items</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-1">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                <span>Invoices Synced</span>
                <Layers className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-lg font-black text-emerald-700">
                {cloudSyncedInvoicesCount || 0} <span className="text-xs font-normal text-slate-400">bills</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-1">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                <span>Categories</span>
                <Sparkles className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-lg font-black text-slate-900">
                {masterCategories.length} <span className="text-xs font-normal text-slate-400">tags</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-1">
              <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
                <span>Last Synced</span>
                <RefreshCw className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-xs font-bold text-slate-700 truncate" title={lastCloudSyncTimestamp || 'Just now'}>
                {lastCloudSyncTimestamp ? new Date(lastCloudSyncTimestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : 'Live'}
              </div>
            </div>
          </div>

          {/* Feedback Info */}
          {syncFeedback && (
            <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-bold flex items-center gap-2">
              <Info className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>{syncFeedback}</span>
            </div>
          )}

          {/* Manual Push / Pull Trigger Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              type="button"
              id="btn-manual-push-to-cloud"
              onClick={handleManualPush}
              disabled={isCloudSyncing}
              className="w-full sm:w-auto flex-1 h-11 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-md shadow-indigo-600/25 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
            >
              {isCloudSyncing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Syncing with Cloud...</span>
                </>
              ) : (
                <>
                  <UploadCloud className="w-4 h-4" />
                  <span>Push Local Data to Cloud</span>
                </>
              )}
            </button>

            <button
              type="button"
              id="btn-manual-pull-from-cloud"
              onClick={handleManualPull}
              disabled={isCloudSyncing}
              className="w-full sm:w-auto flex-1 h-11 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 font-extrabold text-xs rounded-xl border border-slate-200 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
            >
              <DownloadCloud className="w-4 h-4 text-slate-600" />
              <span>Pull Remote Cloud Data to Device</span>
            </button>
          </div>
        </div>
      ) : (
        /* ============================================================ */
        /* Logged Out: Master Email Login / Register Form               */
        /* ============================================================ */
        <div className="space-y-5">
          {/* Mode Switcher Tabs */}
          <div className="flex items-center p-1 bg-slate-100 rounded-2xl w-full max-w-md">
            <button
              type="button"
              onClick={() => { setAuthMode('login'); setAuthError(null); setAuthSuccess(null); }}
              className={`flex-1 py-2 text-xs font-black rounded-xl transition cursor-pointer ${
                authMode === 'login' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'hi' ? 'मास्टर ईमेल लॉगिन' : 'Master Email Login'}
            </button>
            <button
              type="button"
              onClick={() => { setAuthMode('register'); setAuthError(null); setAuthSuccess(null); }}
              className={`flex-1 py-2 text-xs font-black rounded-xl transition cursor-pointer ${
                authMode === 'register' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'hi' ? 'नया सिंक खाता' : 'New Cloud Account'}
            </button>
          </div>

          {/* Error / Success Feedback */}
          {authError && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-bold flex items-start gap-2 animate-in fade-in duration-200">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{authError}</span>
            </div>
          )}

          {authSuccess && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-start gap-2 animate-in fade-in duration-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{authSuccess}</span>
            </div>
          )}

          <form onSubmit={handleEmailSubmit} className="space-y-4 max-w-xl">
            {authMode === 'register' && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Shop Owner / Manager Name</span>
                </label>
                <input
                  type="text"
                  value={shopOwnerName}
                  onChange={(e) => setShopOwnerName(e.target.value)}
                  placeholder="e.g. Aman / Store Manager"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-medium transition"
                  required
                />
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-indigo-600" />
                <span>Master Email Address (Cloud Sync ID)</span>
              </label>
              <input
                type="email"
                id="input-cloud-sync-email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. 007ashu9835@gmail.com"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-medium transition"
                required
              />
            </div>

            {authMode !== 'forgot' && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Cloud Password</span>
                  </label>
                  {authMode === 'login' && (
                    <button
                      type="button"
                      onClick={() => setAuthMode('forgot')}
                      className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="input-cloud-sync-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 pr-10 text-xs text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-medium transition"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              <button
                type="submit"
                id="btn-submit-cloud-auth"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-6 h-11 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-md shadow-indigo-600/25 flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : authMode === 'login' ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Log In & Enable Cloud Sync</span>
                  </>
                ) : authMode === 'register' ? (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Create Account & Sync Data</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Reset Email</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Multi-Device Info Card */}
      <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 text-xs text-slate-600 space-y-2">
        <div className="font-black text-slate-800 flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-indigo-600" />
          <span>How Multi-Device PC + Mobile Sync Works:</span>
        </div>
        <p className="leading-relaxed">
          1. Log in with this <strong>Master Email</strong> on your counter Windows PC Desktop.
          <br />
          2. Open the app link on your Mobile device or secondary laptop and log in with the <strong>same email</strong>.
          <br />
          3. All sales invoices created at the cash counter, barcode inventory additions, and Khata payments will synchronize automatically in real-time across both devices!
        </p>
      </div>
    </div>
  );
};
