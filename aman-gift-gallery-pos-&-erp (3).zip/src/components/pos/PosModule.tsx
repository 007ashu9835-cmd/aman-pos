import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { getTranslation } from '../../utils/translations';
import { Product, CartItem, PaymentMethod, Party } from '../../types';
import { calculateCartTotals, formatCurrency, formatNumber } from '../../utils/calculations';
import { generateWhatsAppLink, formatWhatsAppPhoneNumber } from '../../utils/invoiceGenerator';
import { decodeBarcodeFromImage, playScanAudioTone } from '../../utils/barcodeImageDecoder';
import { db } from '../../db';
import { 
  Search, 
  Barcode, 
  RotateCcw, 
  Trash2, 
  Plus, 
  Minus, 
  ShieldCheck, 
  CreditCard, 
  QrCode, 
  Banknote, 
  Users, 
  Eye, 
  EyeOff, 
  Printer, 
  Sparkles,
  Camera,
  ShoppingBag,
  X,
  User,
  Phone,
  Tag,
  Percent,
  CheckCircle2,
  Send,
  Calendar,
  FileText,
  Image as ImageIcon,
  Loader2,
  AlertCircle,
  Zap,
  CornerDownLeft
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const PosModule: React.FC = () => {
  const { 
    products, 
    cart, 
    addToCart, 
    removeFromCart, 
    updateCartQuantity, 
    updateCartPrice, 
    updateCartDiscount, 
    toggleCartWarranty, 
    clearCart, 
    completeCheckout,
    customerName,
    setCustomerName,
    customerPhone,
    setCustomerPhone,
    isExchangeMode,
    setIsExchangeMode,
    showCashierProfit,
    setShowCashierProfit,
    isGstInvoiceEnabled,
    setIsGstInvoiceEnabled,
    showDiscountOnBill,
    setShowDiscountOnBill,
    openCameraScanner,
    masterCategories,
    shopProfile,
    playBeep,
    language 
  } = useApp();

  const t = getTranslation(language);

  // Search & Catalog State
  const [searchTerm, setSearchTerm] = useState('');
  const [billingMode, setBillingMode] = useState<'Retail' | 'GST Retail' | 'GST Fixed'>('Retail');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Direct Camera Photo & Image Barcode Scanning State
  const posDirectCameraInputRef = useRef<HTMLInputElement>(null);
  const posGalleryInputRef = useRef<HTMLInputElement>(null);
  const [isDecodingBarcodePhoto, setIsDecodingBarcodePhoto] = useState(false);
  const [barcodeFeedback, setBarcodeFeedback] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Clear feedback after 4 seconds
  useEffect(() => {
    if (barcodeFeedback) {
      const timer = setTimeout(() => setBarcodeFeedback(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [barcodeFeedback]);

  
  const triggerDirectCameraScan = () => {
    posDirectCameraInputRef.current?.click();
  };

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    handlePosBarcodeImageCapture(e);
  };

  const handleBarcodeScan = (barcode: string) => {
    const cleanDetected = barcode.trim();
    const matched = products.find(p => 
      p.barcode.toLowerCase() === cleanDetected.toLowerCase() || 
      p.barcode.toLowerCase() === cleanDetected.replace(/^0+/, '').toLowerCase()
    );

    if (matched) {
      addToCart(matched, isExchangeMode, billingMode === 'GST Fixed' ? undefined : 0);
      setBarcodeFeedback({
        type: 'success',
        text: language === 'hi' 
          ? `✓ "${matched.name}" कार्ट में जोड़ा गया!` 
          : `✓ Added "${matched.name}" to cart!`
      });
    } else {
      setSearchTerm(cleanDetected);
      setBarcodeFeedback({
        type: 'info',
        text: language === 'hi'
          ? `बारकोड डिटेक्ट: ${cleanDetected} (उत्पाद कैटलॉग में नहीं मिला)`
          : `Scanned Barcode: ${cleanDetected} (Item not found in catalog)`
      });
    }
  };

  // Handle direct barcode photo snap / file upload
  const handlePosBarcodeImageCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsDecodingBarcodePhoto(true);
    setBarcodeFeedback(null);

    try {
      const detected = await decodeBarcodeFromImage(file);
      if (detected) {
        playScanAudioTone(true);
        playBeep(isExchangeMode ? 2 : 1);
        
        const cleanDetected = detected.trim();
        const matched = products.find(p => 
          p.barcode.toLowerCase() === cleanDetected.toLowerCase() || 
          p.barcode.toLowerCase() === cleanDetected.replace(/^0+/, '').toLowerCase()
        );

        if (matched) {
          addToCart(matched, isExchangeMode, billingMode === 'GST Fixed' ? undefined : 0);
          setBarcodeFeedback({
            type: 'success',
            text: language === 'hi' 
              ? `✓ "${matched.name}" कार्ट में जोड़ा गया!` 
              : `✓ Added "${matched.name}" to cart!`
          });
        } else {
          setSearchTerm(cleanDetected);
          setBarcodeFeedback({
            type: 'info',
            text: language === 'hi'
              ? `बारकोड डिटेक्ट: ${cleanDetected} (उत्पाद कैटलॉग में नहीं मिला)`
              : `Scanned Barcode: ${cleanDetected} (Item not found in catalog)`
          });
        }
      } else {
        playScanAudioTone(false);
        setBarcodeFeedback({
          type: 'error',
          text: language === 'hi'
            ? 'फोटो में बारकोड नहीं मिला। कृपया रोशनी में साफ फोटो लें।'
            : 'No barcode found in captured photo. Please try snapping closer with good lighting.'
        });
      }
    } catch (err) {
      console.error('POS Barcode Photo decode failed:', err);
      playScanAudioTone(false);
      setBarcodeFeedback({
        type: 'error',
        text: language === 'hi' ? 'बारकोड प्रोसेस करने में त्रुटि हुई।' : 'Error decoding barcode photo.'
      });
    } finally {
      setIsDecodingBarcodePhoto(false);
      if (posDirectCameraInputRef.current) posDirectCameraInputRef.current.value = '';
      if (posGalleryInputRef.current) posGalleryInputRef.current.value = '';
    }
  };

  // Billing & Metadata State
  const [invoiceDate, setInvoiceDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [invoiceNumberSuffix, setInvoiceNumberSuffix] = useState<string>(() => `${Math.floor(1000 + Math.random() * 9000)}`);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod>('cash');
  const [checkoutNotes, setCheckoutNotes] = useState('');
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [customerSuggestions, setCustomerSuggestions] = useState<Party[]>([]);
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);

  // Cart Calculations
  const totals = useMemo(() => calculateCartTotals(cart, isGstInvoiceEnabled), [cart, isGstInvoiceEnabled]);
  const totalQuantitySum = useMemo(() => {
    return cart.reduce((acc, item) => acc + Math.abs(item.quantity), 0);
  }, [cart]);

  // Master Categories list
  const categories = useMemo(() => ['All', ...masterCategories], [masterCategories]);

  // Filtered Products Catalog for instant click-to-add
  const filteredProducts = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return products.filter(p => {
      const matchesSearch = !term || 
        p.name.toLowerCase().includes(term) ||
        p.barcode.toLowerCase().includes(term) ||
        p.brand.toLowerCase().includes(term) ||
        (p.category && p.category.toLowerCase().includes(term));

      const matchesCat = 
        selectedCategory === 'All' || 
        (p.category && p.category.toLowerCase() === selectedCategory.toLowerCase());

      return matchesSearch && matchesCat;
    });
  }, [products, searchTerm, selectedCategory]);

  // Load parties for customer search suggestions
  useEffect(() => {
    if (customerName.trim().length > 1) {
      db.parties
        .filter(p => p.name.toLowerCase().includes(customerName.toLowerCase()) || p.phone.includes(customerName))
        .limit(5)
        .toArray()
        .then(res => setCustomerSuggestions(res))
        .catch(() => setCustomerSuggestions([]));
    } else {
      setCustomerSuggestions([]);
    }
  }, [customerName]);

  // Focus search input on mount
  useEffect(() => {
    searchInputRef.current?.focus();
  }, []);

  // Handle manual / Enter key submission to cart
  const handleManualSearchSubmit = () => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return;

    // Exact barcode match first
    const exactBarcode = products.find(p => p.barcode.toLowerCase() === term || p.barcode.toLowerCase() === term.replace(/^0+/, ''));
    if (exactBarcode) {
      addToCart(exactBarcode, isExchangeMode, billingMode === 'GST Fixed' ? undefined : 0);
      setSearchTerm('');
      return;
    }

    // If exactly 1 filtered product matches
    if (filteredProducts.length === 1) {
      addToCart(filteredProducts[0], isExchangeMode, billingMode === 'GST Fixed' ? undefined : 0);
      setSearchTerm('');
      return;
    }
  };

  // Barcode Scanner Enter Key Auto-Add
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleManualSearchSubmit();
    }
  };

  // Keyboard Shortcuts: F2 for Save & Print, F4 for Save & WhatsApp, F12 for Save Only, Esc for search reset
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        if (cart.length > 0) {
          handleSaveAndPrint();
        }
      } else if (e.key === 'F4') {
        e.preventDefault();
        if (cart.length > 0) {
          handleSaveAndWhatsApp();
        }
      } else if (e.key === 'F12') {
        e.preventDefault();
        if (cart.length > 0) {
          handleSaveOnly();
        }
      } else if (e.key === 'Escape') {
        if (searchTerm) {
          setSearchTerm('');
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [cart, selectedPaymentMethod, checkoutNotes]);

  // Handler: Save & Print Bill (F2)
  const handleSaveAndPrint = async () => {
    if (cart.length === 0 || isProcessingCheckout) return;
    setIsProcessingCheckout(true);
    try {
      await completeCheckout(selectedPaymentMethod, checkoutNotes, isGstInvoiceEnabled);
      setCheckoutNotes('');
      // Give the modal time to render the invoice before calling print
      setTimeout(() => {
        window.print();
      }, 500);
    } catch (err: any) {
      console.error('Checkout failed:', err);
      playBeep('alert');
      alert(err.message || 'Checkout failed');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  // Handler: Save Only (F12)
  const handleSaveOnly = async () => {
    if (cart.length === 0 || isProcessingCheckout) return;
    setIsProcessingCheckout(true);
    try {
      await completeCheckout(selectedPaymentMethod, checkoutNotes, isGstInvoiceEnabled);
      setCheckoutNotes('');
      playBeep('success');
    } catch (err: any) {
      console.error('Checkout failed:', err);
      playBeep('alert');
      alert(err.message || 'Checkout failed');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  // Handler: Save & WhatsApp (Instant Digital Receipt)
  const handleSaveAndWhatsApp = async () => {
    if (cart.length === 0 || isProcessingCheckout) return;

    const phoneValidation = formatWhatsAppPhoneNumber(customerPhone);
    if (!phoneValidation.isValid) {
      playBeep('alert');
      alert(phoneValidation.error || 'Please enter a valid 10-digit customer mobile number before sending bill on WhatsApp.');
      return;
    }

    // 1. Generate link & open window synchronously to bypass popup blockers
    const tempInvoice: any = {
      invoiceNumber: 'AGG-' + new Date().getTime().toString().slice(-6),
      date: new Date().toLocaleDateString('en-IN'),
      customerName: customerName || 'Customer',
      customerPhone: phoneValidation.formattedPhone,
      items: cart,
      subTotal: totals.subtotal,
      totalDiscount: totals.totalDiscount,
      grandTotal: totals.grandTotal,
      taxAmount: totals.totalGst,
      isGstInvoice: isGstInvoiceEnabled
    };

    try {
      const waUrl = generateWhatsAppLink(tempInvoice, shopProfile);
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch (e: any) {
      alert(e.message);
      return;
    }

    // 2. Perform Save asynchronously
    setIsProcessingCheckout(true);
    try {
      await completeCheckout(selectedPaymentMethod, checkoutNotes, isGstInvoiceEnabled);
      setCheckoutNotes('');
      playBeep('success');
    } catch (err: any) {
      console.error('Save & WhatsApp checkout failed:', err);
      playBeep('alert');
      alert(err.message || 'Checkout failed');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  // Apply Global Cart Discount %
  const handleApplyGlobalDiscount = (pct: number) => {
    cart.forEach((_, idx) => {
      updateCartDiscount(idx, pct);
    });
  };

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden bg-slate-100">
      
      {/* ========================================================================= */}
      {/* LEFT SECTION: Catalog & Product Browser */}
      {/* ========================================================================= */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0 bg-white border-r border-slate-200">
        
        {/* Hidden Direct Camera Capture Input for POS */}
        <input
          ref={posDirectCameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          id="direct-camera-barcode-input-pos"
          className="hidden"
          onChange={handlePosBarcodeImageCapture}
        />

        {/* Hidden Gallery Upload Input for POS */}
        <input
          ref={posGalleryInputRef}
          type="file"
          accept="image/*"
          id="gallery-file-barcode-input-pos"
          className="hidden"
          onChange={handlePosBarcodeImageCapture}
        />

        {/* Top Search, Barcode Scanner & Controls Bar */}
        <div className="p-4 border-b border-slate-200 bg-white space-y-2 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Unified Smart Input Bar */}
            <div className="relative flex-1 flex items-center bg-slate-50 hover:bg-slate-100/70 focus-within:bg-white border border-slate-200 rounded-xl transition duration-150 shadow-2xs focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500 min-w-0">
              <Search className="w-4 h-4 text-slate-400 ml-3.5 shrink-0" />
              <input
                ref={searchInputRef}
                type="text"
                id="input-pos-search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleSearchKeyDown}
                placeholder={language === 'hi' ? 'नाम लिखें या बारकोड स्कैन करें...' : 'Type name or scan barcode...'}
                className="w-full h-11 bg-transparent px-3 text-xs sm:text-sm font-medium text-slate-900 placeholder-slate-400 focus:outline-hidden"
              />

              {/* Inside Input Action Cluster */}
              <div className="flex items-center gap-0.5 sm:gap-1 pr-1.5 shrink-0">
                {searchTerm && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchTerm('');
                      searchInputRef.current?.focus();
                    }}
                    className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                    title="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                {/* Visual Separator */}
                <div className="w-px h-5 bg-slate-300 mx-1 hidden sm:block"></div>

                {/* Camera Barcode Scanner Trigger */}
                <button
                  type="button"
                  id="btn-pos-camera-scan"
                  onClick={() => openCameraScanner('pos', (barcode) => {
                    handleBarcodeScan(barcode);
                  })}
                  className="h-8 px-2 sm:px-3 flex items-center gap-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold transition cursor-pointer"
                  title="Open Camera Barcode Scanner"
                >
                  <Camera className="w-3.5 h-3.5 text-indigo-600" />
                  <span className="hidden sm:inline">Camera Scan</span>
                </button>

                {/* Hidden File Inputs for Scanning */}
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  ref={posDirectCameraInputRef}
                  className="hidden"
                  onChange={handleImageCapture}
                />
                <input
                  type="file"
                  accept="image/*"
                  ref={posGalleryInputRef}
                  className="hidden"
                  onChange={handleImageCapture}
                />
              </div>
            </div>
            <button
              type="button"
              id="btn-pos-exchange-mode"
              onClick={() => {
                const nextState = !isExchangeMode;
                setIsExchangeMode(nextState);
                playBeep(nextState ? 'exchange' : 'scan');
              }}
              className={`h-11 px-3 sm:px-3.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 sm:gap-2 transition cursor-pointer shrink-0 ${
                isExchangeMode 
                  ? 'bg-amber-500 text-white shadow-md shadow-amber-500/30 ring-2 ring-amber-400' 
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200'
              }`}
              title="Toggle Customer Return / Exchange Mode"
            >
              <RotateCcw className={`w-4 h-4 ${isExchangeMode ? 'text-white' : 'text-amber-700'}`} />
              <span className="hidden sm:inline">{isExchangeMode ? '⚡ Exchange Active' : 'Exchange Mode'}</span>
            </button>
          </div>

          {/* Tiny Helper Note Underneath */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium px-1">
            <p className="flex items-center gap-1">
              <span>💡</span>
              <span>{language === 'hi' ? 'टिप: छोटे बारकोड को तुरंत स्कैन करने के लिए कैमरा आइकन दबाएं।' : 'Tip: Click camera icon to snap small barcodes instantly.'}</span>
            </p>
            <span className="hidden sm:inline font-semibold text-slate-400">
              {filteredProducts.length} items
            </span>
          </div>

          {/* Barcode Snap Feedback Banner */}
          {barcodeFeedback && (
            <div 
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                barcodeFeedback.type === 'success' 
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-xs' 
                  : barcodeFeedback.type === 'error'
                  ? 'bg-red-50 text-red-800 border border-red-200 shadow-xs'
                  : 'bg-blue-50 text-blue-800 border border-blue-200 shadow-xs'
              }`}
            >
              {barcodeFeedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              )}
              <span className="flex-1">{barcodeFeedback.text}</span>
              <button 
                type="button" 
                onClick={() => setBarcodeFeedback(null)} 
                className="text-slate-400 hover:text-slate-600 p-0.5 rounded-sm"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`h-8 px-3.5 text-xs font-semibold rounded-lg whitespace-nowrap transition cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:text-slate-900 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Product Catalog Grid */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-50">
          {/* Active Exchange Mode Alert Banner */}
          {isExchangeMode && (
            <div className="mb-4 p-3.5 bg-amber-500/10 border-2 border-amber-500 rounded-2xl flex items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-2 bg-amber-500 text-white rounded-xl shrink-0 shadow-xs">
                  <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-black text-amber-950 flex items-center gap-1.5">
                    <span>{language === 'hi' ? '⚡ एक्सचेंज / रिटर्न मोड सक्रिय' : '⚡ Exchange & Return Mode Active'}</span>
                    <span className="px-1.5 py-0.5 bg-amber-500 text-white text-[9px] font-black uppercase rounded">
                      {language === 'hi' ? 'रिटर्न क्रेडिट' : 'Credit Return'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-amber-800/90 font-medium leading-tight mt-0.5">
                    {language === 'hi'
                      ? 'किसी भी उत्पाद पर क्लिक करके उसे रिटर्न क्रेडिट के रूप में जोड़ें (बिल में माइनस होगा और स्टॉक में वापस जुड़ेगा)।'
                      : 'Click or scan any item to add as Return Credit (deducts from bill total & automatically restocks inventory).'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsExchangeMode(false)}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer shrink-0"
              >
                {language === 'hi' ? 'मोड बंद करें' : 'Exit Mode'}
              </button>
            </div>
          )}

          {filteredProducts.length === 0 ? (
            <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center p-8 text-slate-400">
              <ShoppingBag className="w-12 h-12 text-slate-300 stroke-[1.5] mb-3" />
              <p className="text-sm font-bold text-slate-600">No products found matching "{searchTerm}"</p>
              <p className="text-xs text-slate-400 mt-1">Scan a barcode or change category filters to view items</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3.5 pb-4">
              {filteredProducts.map((prod, idx) => {
                const inCartRegular = cart.find(i => (i.product.barcode && i.product.barcode === prod.barcode) || (prod.id && i.product.id === prod.id) && !i.isExchangeReturn && i.quantity > 0);
                const inCartReturn = cart.find(i => (i.product.barcode && i.product.barcode === prod.barcode) || (prod.id && i.product.id === prod.id) && (i.isExchangeReturn || i.quantity < 0));
                const inCartItem = isExchangeMode ? inCartReturn : (inCartRegular || inCartReturn);
                const isLowStock = prod.stockQty <= (prod.minThreshold || 3);
                const displayPrice = prod.sellingPrice || prod.mrp || 0;

                return (
                  <div
                    key={prod.barcode || (prod.id ? `pos-${prod.id}` : `pos-prod-${idx}`)}
                    className={`rounded-2xl p-3.5 border transition-all duration-150 flex flex-col justify-between relative group ${
                      isExchangeMode
                        ? inCartReturn
                          ? 'border-2 border-amber-500 bg-amber-50/50 ring-2 ring-amber-500/20 shadow-sm'
                          : 'border-2 border-amber-400/80 bg-amber-50/20 hover:border-amber-500 hover:bg-amber-50/30 hover:shadow-xs'
                        : inCartItem
                          ? 'bg-white border-indigo-500 ring-2 ring-indigo-500/10 shadow-sm'
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-xs'
                    }`}
                  >
                    <div>
                      {/* Brand & Stock Header */}
                      <div className="flex items-center justify-between gap-1 mb-2">
                        {isExchangeMode ? (
                          <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded flex items-center gap-0.5 truncate max-w-[120px]">
                            <RotateCcw className="w-2.5 h-2.5 shrink-0" />
                            <span>Return / Credit</span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded truncate max-w-[90px]">
                            {prod.brand || 'General'}
                          </span>
                        )}
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          isLowStock 
                            ? 'bg-rose-50 text-rose-700 border border-rose-100' 
                            : 'bg-emerald-50 text-emerald-700'
                        }`}>
                          {prod.stockQty} in stock
                        </span>
                      </div>

                      {/* Product Name */}
                      <h4 className="font-bold text-sm text-slate-900 line-clamp-2 leading-snug">
                        {prod.name}
                      </h4>

                      {/* Barcode Subtext */}
                      {prod.barcode && (
                        <p className="text-[10px] text-slate-400 font-mono mt-1">
                          {prod.barcode}
                        </p>
                      )}
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-100">
                      <div className="flex items-baseline justify-between mb-2">
                        <div className="text-[11px] font-bold text-slate-700">
                          {prod.mrp && prod.sellingPrice && prod.mrp > prod.sellingPrice ? (
                            <span className="text-slate-600">MRP: <b className="text-slate-800">₹{prod.mrp}</b></span>
                          ) : (
                            <span className="text-[10px] text-slate-400 uppercase font-bold">Price</span>
                          )}
                        </div>
                        <span className={`text-base font-black ${isExchangeMode ? 'text-amber-700' : 'text-emerald-600'}`}>
                          {isExchangeMode ? `-₹${displayPrice}` : `₹${displayPrice}`}
                        </span>
                      </div>

                      {/* Add to Cart / Return CTA */}
                      <button
                        type="button"
                        onClick={() => addToCart(prod, isExchangeMode, billingMode === 'GST Fixed' ? undefined : 0)}
                        className={`w-full h-9 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer ${
                          isExchangeMode
                            ? inCartReturn
                              ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-xs'
                              : 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs'
                            : inCartItem
                              ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                              : 'bg-slate-100 hover:bg-indigo-600 text-slate-800 hover:text-white'
                        }`}
                      >
                        {isExchangeMode ? (
                          <>
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>{inCartReturn ? `Return Added (-${Math.abs(inCartReturn.quantity)})` : `+ Return Item (-₹${displayPrice})`}</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>{inCartItem ? `Added (${Math.abs(inCartItem.quantity)})` : '+ Add to Bill'}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* RIGHT SECTION: Cart / Billing Summary Panel */}
      {/* ========================================================================= */}
      <div className="w-full lg:w-[420px] xl:w-[460px] flex flex-col bg-white border-l border-slate-200 overflow-hidden shrink-0 shadow-lg z-10">
        
        {/* Customer Information Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 space-y-2.5 shrink-0">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span>Customer Details</span>
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono font-bold text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                INV-{invoiceNumberSuffix}
              </span>
              <button
                type="button"
                onClick={clearCart}
                disabled={cart.length === 0}
                className="text-slate-400 hover:text-rose-600 disabled:opacity-30 disabled:pointer-events-none p-1 rounded transition cursor-pointer"
                title="Clear all cart items"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Customer Details & 1-Click WhatsApp Setup */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {/* Customer Name with Autocomplete */}
            <div className="relative">
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="input-pos-customer-name" className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  <span>Customer Name</span>
                </label>
              </div>
              <input
                type="text"
                id="input-pos-customer-name"
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  setShowCustomerDropdown(true);
                }}
                onFocus={() => setShowCustomerDropdown(true)}
                placeholder="e.g. Rahul Sharma"
                className="w-full h-9 bg-white border border-slate-200 rounded-lg px-2.5 text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
              />

              {/* Suggestions Dropdown */}
              {showCustomerDropdown && customerSuggestions.length > 0 && (
                <div className="absolute left-0 top-full mt-1 w-full bg-white rounded-xl shadow-lg border border-slate-200 py-1 z-30">
                  {customerSuggestions.map(party => (
                    <button
                      key={party.id}
                      type="button"
                      onClick={() => {
                        setCustomerName(party.name);
                        if (party.phone) setCustomerPhone(party.phone);
                        setShowCustomerDropdown(false);
                      }}
                      className="w-full px-3 py-1.5 text-left text-xs hover:bg-slate-50 flex items-center justify-between cursor-pointer border-b border-slate-100 last:border-0"
                    >
                      <span className="font-bold text-slate-800">{party.name}</span>
                      <span className="text-[10px] text-slate-500">{party.phone}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Customer WhatsApp Phone (10 digits) */}
            <div className="relative">
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="input-pos-customer-phone" className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-emerald-600" />
                  <span>Customer WhatsApp Number</span>
                </label>
                {customerPhone && (
                  <span className={`text-[9px] font-bold ${customerPhone.replace(/\D/g, '').length === 10 ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {customerPhone.replace(/\D/g, '').length}/10 digits
                  </span>
                )}
              </div>
              <div className="relative flex items-center">
                <span className="absolute left-2.5 text-xs font-bold text-slate-400 select-none pointer-events-none">
                  +91
                </span>
                <input
                  type="tel"
                  id="input-pos-customer-phone"
                  value={customerPhone}
                  maxLength={13}
                  onChange={(e) => {
                    const val = e.target.value.replace(/[^0-9]/g, '');
                    setCustomerPhone(val.slice(0, 10));
                  }}
                  placeholder="10-digit Mobile"
                  className="w-full h-9 bg-white border border-slate-200 rounded-lg pl-10 pr-2.5 text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Smart GST / Tax Invoice Toggle & Show Discount Toggle */}
          <div className="pt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-4">
              <label htmlFor="toggle-pos-gst-invoice" className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  id="toggle-pos-gst-invoice"
                  checked={isGstInvoiceEnabled}
                  onChange={(e) => setIsGstInvoiceEnabled(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                />
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                  <span>Enable GST</span>
                </span>
              </label>

              <label htmlFor="toggle-pos-show-discount" className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  id="toggle-pos-show-discount"
                  checked={showDiscountOnBill}
                  onChange={(e) => setShowDiscountOnBill(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                />
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                  <span>Show Discount</span>
                </span>
              </label>
            </div>
            <div className="flex gap-2">
              {(['Retail', 'GST Retail', 'GST Fixed'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => {
                    setBillingMode(mode);
                    if (mode === 'Retail') {
                      setIsGstInvoiceEnabled(false);
                    } else {
                      setIsGstInvoiceEnabled(true);
                    }
                    if (mode === 'GST Fixed') {
                      cart.forEach((item, idx) => {
                        updateCartPrice(idx, item.product.mrp || item.product.sellingPrice || 0);
                      });
                    }
                  }}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                    billingMode === mode 
                      ? 'bg-blue-600 text-white shadow' 
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-3">
          {cart.length === 0 ? (
            <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <Barcode className="w-10 h-10 text-slate-300 stroke-[1.5] mb-2" />
              <p className="text-xs font-bold text-slate-600">Cart is empty</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Click products or scan barcode to add</p>
            </div>
          ) : (
            cart.map((item, idx) => {
              const isReturn = item.quantity < 0 || item.isExchangeReturn;
              const refMrp = item.product.mrp || item.product.sellingPrice || 0;
              const currentPrice = item.customPrice !== undefined ? item.customPrice : refMrp;
              const discountPct = item.discountPercent || 0;
              const priceAfterDiscount = currentPrice - (currentPrice * discountPct) / 100;
              const rowTotal = priceAfterDiscount * Math.abs(item.quantity);

              return (
                <div 
                  key={`${item.product.id}-${idx}`}
                  className={`py-3 px-2.5 rounded-xl transition ${
                    isReturn ? 'bg-amber-50/70 border border-amber-300 shadow-2xs' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        {isReturn && (
                          <span className="px-1.5 py-0.5 bg-amber-600 text-white text-[9px] font-black rounded uppercase flex items-center gap-0.5 shadow-2xs">
                            <RotateCcw className="w-2.5 h-2.5" />
                            <span>Return Item</span>
                          </span>
                        )}
                        <h4 className="text-xs font-bold text-slate-900 truncate">
                          {item.product.name}
                        </h4>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 mt-0.5 text-[11px] text-slate-500 font-medium">
                        <span>MRP: <b className="text-slate-800">₹{item.product.mrp || currentPrice}</b></span>
                        <span className="text-slate-300">|</span>
                        <span>Rate: <b className={`${isReturn ? 'text-amber-700' : 'text-indigo-700'} font-black`}>{isReturn ? '-' : ''}₹{(Number(currentPrice) || 0).toFixed(0)}</b></span>
                        {discountPct > 0 && (
                          <span className="text-emerald-700 font-bold">(-{discountPct}%)</span>
                        )}
                        {item.warranty?.enabled && item.warranty.duration && item.warranty.duration !== 'No Warranty' && (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded border border-indigo-200">
                            🛡️ {item.warranty.duration}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Row Total */}
                    <div className="text-right">
                      <div className={`text-sm font-black ${isReturn ? 'text-amber-700' : 'text-slate-900'}`}>
                        {isReturn ? '-' : ''}₹{(Number(rowTotal) || 0).toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {/* Quantity Stepper, Price, Warranty Selector & Delete */}
                  <div className="flex flex-wrap items-center justify-between mt-2.5 pt-2 border-t border-slate-100 gap-2">
                    {/* Stepper */}
                    <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-0.5">
                      <button
                        type="button"
                        onClick={() => updateCartQuantity(idx, isReturn ? item.quantity + 1 : item.quantity - 1)}
                        className="w-6 h-6 rounded bg-white text-slate-700 hover:bg-slate-200 flex items-center justify-center transition cursor-pointer shadow-2xs"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-7 text-center font-bold text-xs text-slate-900">
                        {Math.abs(item.quantity)}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateCartQuantity(idx, isReturn ? item.quantity - 1 : item.quantity + 1)}
                        className="w-6 h-6 rounded bg-white text-slate-700 hover:bg-slate-200 flex items-center justify-center transition cursor-pointer shadow-2xs"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Custom Rate Input */}
                    <div className="flex items-center gap-1" title="Billing Rate per Unit">
                      <span className="text-[10px] text-slate-400 font-bold">Rate ₹</span>
                      <input
                        type="number"
                        min="0"
                        value={currentPrice === 0 ? '' : currentPrice}
                        disabled={billingMode === 'GST Fixed'}
                        autoFocus={billingMode !== 'GST Fixed' && idx === cart.length - 1}
                        onChange={(e) => {
                          const val = e.target.value === '' ? 0 : Number(e.target.value);
                          updateCartPrice(idx, val);
                        }}
                        className={`w-14 h-6 text-right font-bold text-xs border rounded px-1 ${billingMode === 'GST Fixed' ? 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed' : 'bg-white border-slate-300 text-slate-900 focus:border-indigo-500'}`}
                        title={billingMode === 'GST Fixed' ? 'Locked in GST Fixed Mode' : 'Edit rate'}
                      />
                    </div>

                    {/* Comprehensive Warranty Dropdown */}
                    <div className="flex items-center gap-1">
                      <ShieldCheck className={`w-3.5 h-3.5 shrink-0 ${item.warranty?.enabled && item.warranty?.duration !== 'No Warranty' ? 'text-indigo-600' : 'text-slate-400'}`} />
                      <select
                        value={
                          !item.warranty?.enabled || item.warranty.duration === 'No Warranty' || !item.warranty.duration
                            ? 'No Warranty'
                            : [
                                '3 Months Warranty',
                                '6 Months Warranty',
                                '1 Year Warranty',
                                '2 Years Warranty',
                                '3 Years Warranty',
                                '5 Years Warranty'
                              ].includes(item.warranty.duration)
                            ? item.warranty.duration
                            : 'Custom Warranty'
                        }
                        onChange={(e) => {
                          const val = e.target.value;
                          if (val === 'No Warranty') {
                            toggleCartWarranty(idx, false, 'No Warranty');
                          } else if (val === 'Custom Warranty') {
                            const custom = window.prompt(
                              'Enter custom warranty period (e.g. 18 Months Warranty, 100 Days):',
                              item.warranty?.duration && item.warranty.duration !== 'No Warranty' ? item.warranty.duration : '18 Months Warranty'
                            );
                            if (custom && custom.trim()) {
                              toggleCartWarranty(idx, true, custom.trim());
                            }
                          } else {
                            toggleCartWarranty(idx, true, val);
                          }
                        }}
                        className={`h-6 text-[10px] font-bold rounded-md px-1.5 border transition cursor-pointer ${
                          item.warranty?.enabled && item.warranty?.duration !== 'No Warranty'
                            ? 'bg-indigo-50 border-indigo-300 text-indigo-800'
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-700'
                        }`}
                        title="Select Warranty Coverage"
                      >
                        <option value="No Warranty">No Warranty</option>
                        <option value="3 Months Warranty">3 Months Warranty</option>
                        <option value="6 Months Warranty">6 Months Warranty</option>
                        <option value="1 Year Warranty">1 Year Warranty</option>
                        <option value="2 Years Warranty">2 Years Warranty</option>
                        <option value="3 Years Warranty">3 Years Warranty</option>
                        <option value="5 Years Warranty">5 Years Warranty</option>
                        <option value="Custom Warranty">
                          {item.warranty?.enabled && item.warranty?.duration && ![
                            'No Warranty',
                            '3 Months Warranty',
                            '6 Months Warranty',
                            '1 Year Warranty',
                            '2 Years Warranty',
                            '3 Years Warranty',
                            '5 Years Warranty'
                          ].includes(item.warranty.duration)
                            ? `Custom: ${item.warranty.duration}`
                            : 'Custom Warranty...'}
                        </option>
                      </select>
                    </div>

                    {/* Delete Row Button */}
                    <button
                      type="button"
                      onClick={() => removeFromCart(idx)}
                      className="p-1 text-slate-300 hover:text-rose-600 transition cursor-pointer"
                      title="Remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Bill Summary & Payment Section */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-3 shrink-0">
          
          {/* Quick Overall Discount Presets */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-[11px] font-bold text-slate-500">Quick Discount:</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => handleApplyGlobalDiscount(5)}
                className="px-2 py-0.5 bg-white hover:bg-emerald-50 text-emerald-700 border border-slate-200 rounded text-xs font-bold transition cursor-pointer"
              >
                5%
              </button>
              <button
                type="button"
                onClick={() => handleApplyGlobalDiscount(10)}
                className="px-2 py-0.5 bg-white hover:bg-emerald-50 text-emerald-700 border border-slate-200 rounded text-xs font-bold transition cursor-pointer"
              >
                10%
              </button>
              <button
                type="button"
                onClick={() => handleApplyGlobalDiscount(0)}
                className="px-2 py-0.5 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded text-xs font-bold transition cursor-pointer"
              >
                0%
              </button>
            </div>
          </div>

          {/* Cashier Profit Box (Toggleable) */}
          {showCashierProfit && cart.length > 0 && (
            <div className="p-2.5 bg-slate-900 text-white rounded-xl text-xs space-y-1">
              <div className="flex items-center justify-between text-[10px] text-amber-400 font-extrabold uppercase">
                <span className="flex items-center gap-1"><Sparkles className="w-3 h-3" /> Profit Breakdown</span>
                <button type="button" onClick={() => setShowCashierProfit(false)} className="text-slate-400 hover:text-white">Hide</button>
              </div>
              <div className="flex justify-between text-slate-300 text-[11px]">
                <span>Purchase Cost: ₹{(totals.totalLandingCost || totals.totalPurchaseCost || 0).toFixed(2)}</span>
                <span>Margin: <strong className="text-indigo-400">{totals.profitMarginPercent || 0}%</strong></span>
              </div>
              <div className="flex justify-between font-bold text-emerald-400 text-xs pt-1 border-t border-slate-800">
                <span>Gross Margin Profit:</span>
                <span>₹{(totals.cashierProfit || 0).toFixed(2)}</span>
              </div>
            </div>
          )}

          {/* Totals Breakdown */}
          <div className="space-y-1.5 text-xs text-slate-600 pt-1">
            <div className="flex justify-between">
              <span>Items / Quantity:</span>
              <span className="font-bold text-slate-900">{totals.totalItemsCount || 0} items ({totalQuantitySum || 0} pcs)</span>
            </div>
            <div className="flex justify-between">
              <span>{isGstInvoiceEnabled && (totals.totalGst || 0) > 0 ? 'Item(s) Subtotal (amount before tax):' : 'Items Subtotal:'}</span>
              <span className="font-bold text-slate-900">₹{(totals.subtotal || 0).toFixed(2)}</span>
            </div>
            {(totals.totalDiscount || 0) > 0 && (
              <div className="flex justify-between text-emerald-700 font-medium">
                <span>Total Savings:</span>
                <span>-₹{(totals.totalDiscount || 0).toFixed(2)}</span>
              </div>
            )}
            {(totals.exchangeCredit || 0) > 0 && (
              <div className="flex justify-between text-amber-700 font-medium">
                <span>Exchange Return Credit:</span>
                <span>-₹{(totals.exchangeCredit || 0).toFixed(2)}</span>
              </div>
            )}
            {isGstInvoiceEnabled && (totals.gstBreakdown?.totalTax || 0) > 0 && (
              <>
                <div className="flex justify-between text-slate-600 text-xs">
                  <span>CGST{totals.gstBreakdown?.slabs.length === 1 ? ` (@${totals.gstBreakdown.slabs[0].cgstRate}%):` : ':'}</span>
                  <span className="font-semibold text-slate-800">₹{(totals.gstBreakdown?.totalCgst || 0).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600 text-xs">
                  <span>SGST{totals.gstBreakdown?.slabs.length === 1 ? ` (@${totals.gstBreakdown.slabs[0].sgstRate}%):` : ':'}</span>
                  <span className="font-semibold text-slate-800">₹{(totals.gstBreakdown?.totalSgst || 0).toFixed(2)}</span>
                </div>
              </>
            )}
            {totals.roundOff !== undefined && Math.abs(Number(totals.roundOff || 0)) >= 0.01 && (
              <div className="flex justify-between text-slate-500 text-xs">
                <span>Round Off:</span>
                <span className="font-medium text-slate-700">{totals.roundOff > 0 ? `+₹${totals.roundOff.toFixed(2)}` : `-₹${Math.abs(totals.roundOff).toFixed(2)}`}</span>
              </div>
            )}
            <div className="flex justify-between items-baseline pt-2 border-t border-slate-200">
              <span className="text-sm font-black text-slate-900 uppercase">
                {totals.grandTotal < 0
                  ? 'Refund Due to Customer:'
                  : totals.grandTotal === 0 && (totals.exchangeCredit || 0) > 0
                  ? 'Net Balance (Even Exchange):'
                  : isGstInvoiceEnabled && (totals.totalGst || 0) > 0
                  ? 'Grand Total (after tax):'
                  : 'Grand Total:'}
              </span>
              <span className={`text-2xl font-black ${totals.grandTotal < 0 ? 'text-amber-600' : totals.grandTotal === 0 && (totals.exchangeCredit || 0) > 0 ? 'text-slate-900' : 'text-emerald-600'}`}>
                {totals.grandTotal < 0 ? `-₹${Math.abs(totals.grandTotal).toFixed(2)} (Refund)` : `₹${totals.grandTotal.toFixed(2)}`}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="grid grid-cols-4 gap-1.5 pt-1">
            {[
              { id: 'cash', label: 'Cash', icon: Banknote },
              { id: 'upi', label: 'UPI / QR', icon: QrCode },
              { id: 'card', label: 'Card', icon: CreditCard },
              { id: 'khata', label: 'Khata', icon: Users }
            ].map((m) => {
              const Icon = m.icon;
              const isSelected = selectedPaymentMethod === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setSelectedPaymentMethod(m.id as PaymentMethod)}
                  className={`h-9 rounded-xl border flex items-center justify-center gap-1 text-xs font-bold transition cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Action CTAs */}
          <div className="space-y-2 pt-1">
            {/* Primary: Save & Print Bill (F2) */}
            <button
              type="button"
              id="btn-pos-save-print"
              onClick={handleSaveAndPrint}
              disabled={cart.length === 0 || isProcessingCheckout}
              className={`w-full h-12 ${
                cart.some(i => i.isExchangeReturn || i.quantity < 0)
                  ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/20'
                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
              } disabled:opacity-40 text-white font-black text-sm rounded-xl shadow-lg transition active:scale-95 cursor-pointer flex items-center justify-center gap-2`}
              title="Complete Sale & Open Invoice Modal (F2)"
            >
              <Printer className="w-4 h-4" />
              <span>{cart.some(i => i.isExchangeReturn || i.quantity < 0) ? 'Save & Print Exchange Bill (F2)' : 'Save & Print Bill (F2)'}</span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              {/* Secondary: Save & WhatsApp */}
              <button
                type="button"
                id="btn-pos-save-whatsapp"
                onClick={handleSaveAndWhatsApp}
                disabled={cart.length === 0 || isProcessingCheckout}
                className="h-10 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 disabled:opacity-40 text-emerald-800 font-bold text-xs rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                title="Save Bill & Share PDF directly on WhatsApp (F4)"
              >
                <Send className="w-3.5 h-3.5 text-emerald-600" />
                <span>Save & WhatsApp (F4)</span>
              </button>

              {/* Secondary: Save Only (F12) */}
              <button
                type="button"
                id="btn-pos-save-only"
                onClick={handleSaveOnly}
                disabled={cart.length === 0 || isProcessingCheckout}
                className="h-10 bg-slate-200 hover:bg-slate-300 disabled:opacity-40 text-slate-800 font-bold text-xs rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                title="Save Bill without opening print modal (F12)"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Save Only (F12)</span>
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
