import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  KeyRound, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  X, 
  Eye, 
  EyeOff,
  Sparkles,
  Key,
  Mail,
  Edit3
} from 'lucide-react';
import { playScanAudioTone } from '../../utils/barcodeImageDecoder';

interface SecuritySettingsSectionProps {
  language: 'en' | 'hi';
  showNotification?: (message: string, type?: 'success' | 'error' | 'info') => void;
}

export const SecuritySettingsSection: React.FC<SecuritySettingsSectionProps> = ({
  language,
  showNotification
}) => {
  const defaultAdminEmail = '007ashu9835@gmail.com';

  const [isLockEnabled, setIsLockEnabled] = useState<boolean>(() => {
    return localStorage.getItem('app_lock_enabled') !== 'false';
  });

  const [hasPinSet, setHasPinSet] = useState<boolean>(() => {
    return !!localStorage.getItem('app_lock_pin');
  });

  const [adminEmail, setAdminEmail] = useState<string>(() => {
    return localStorage.getItem('app_master_email') || defaultAdminEmail;
  });

  // Modals
  const [isChangePinModalOpen, setIsChangePinModalOpen] = useState<boolean>(false);
  const [isUpdateAnswerModalOpen, setIsUpdateAnswerModalOpen] = useState<boolean>(false);
  const [isEditEmailModalOpen, setIsEditEmailModalOpen] = useState<boolean>(false);

  // Change PIN modal state
  const [pinAuthMethod, setPinAuthMethod] = useState<'pin' | 'master'>('pin');
  const [currentPinInput, setCurrentPinInput] = useState<string>('');
  const [masterAnswerInput, setMasterAnswerInput] = useState<string>('');
  const [newPinInput, setNewPinInput] = useState<string>('');
  const [confirmNewPinInput, setConfirmNewPinInput] = useState<string>('');
  const [changePinError, setChangePinError] = useState<string | null>(null);
  const [changePinSuccess, setChangePinSuccess] = useState<string | null>(null);

  // Update Answer modal state
  const [answerAuthPin, setAnswerAuthPin] = useState<string>('');
  const [newAnswerInput, setNewAnswerInput] = useState<string>('');
  const [updateAnswerError, setUpdateAnswerError] = useState<string | null>(null);
  const [updateAnswerSuccess, setUpdateAnswerSuccess] = useState<string | null>(null);

  // Update Admin Email modal state
  const [emailAuthPin, setEmailAuthPin] = useState<string>('');
  const [newEmailInput, setNewEmailInput] = useState<string>('');
  const [editEmailError, setEditEmailError] = useState<string | null>(null);
  const [editEmailSuccess, setEditEmailSuccess] = useState<string | null>(null);

  // Toggle Lock on Start
  const handleToggleLock = () => {
    const nextState = !isLockEnabled;
    setIsLockEnabled(nextState);
    localStorage.setItem('app_lock_enabled', nextState ? 'true' : 'false');
    playScanAudioTone(true);
    const msg = nextState
      ? (language === 'hi' ? 'ऐप स्टार्ट पर पिन लॉक सक्रिय किया गया' : 'PIN Lock on App Start Enabled')
      : (language === 'hi' ? 'ऐप स्टार्ट पर पिन लॉक निष्क्रिय किया गया' : 'PIN Lock on App Start Disabled');
    if (showNotification) showNotification(msg, 'info');
  };

  // Lock Now action
  const handleLockNow = () => {
    window.location.reload();
  };

  // Submit Change PIN
  const handleChangePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setChangePinError(null);

    const savedPin = localStorage.getItem('app_lock_pin') || '';
    const savedRecovery = (localStorage.getItem('app_lock_recovery') || '').trim().toLowerCase();

    // 1. Verify Authorization
    if (pinAuthMethod === 'pin') {
      if (currentPinInput !== savedPin) {
        setChangePinError(language === 'hi' ? 'वर्तमान पिन गलत है।' : 'Current PIN is incorrect.');
        playScanAudioTone(false);
        return;
      }
    } else {
      if (masterAnswerInput.trim().toLowerCase() !== savedRecovery) {
        setChangePinError(language === 'hi' ? 'मास्टर रिकवरी उत्तर गलत है।' : 'Master Security Answer is incorrect.');
        playScanAudioTone(false);
        return;
      }
    }

    // 2. Validate New PIN
    if (newPinInput.length !== 4 || !/^\d{4}$/.test(newPinInput)) {
      setChangePinError(language === 'hi' ? 'नया पिन 4 अंकों (0-9) का होना चाहिए।' : 'New PIN must be exactly 4 digits (0-9).');
      return;
    }

    if (newPinInput !== confirmNewPinInput) {
      setChangePinError(language === 'hi' ? 'नया पिन व पुष्टि मेल नहीं खाते।' : 'New PIN and confirmation do not match.');
      return;
    }

    // Save
    localStorage.setItem('app_lock_pin', newPinInput);
    localStorage.setItem('app_lock_enabled', 'true');
    setIsLockEnabled(true);
    setHasPinSet(true);
    playScanAudioTone(true);

    const successMsg = language === 'hi' ? 'सुरक्षा पिन सफलतापूर्वक अपडेट किया गया!' : 'Security PIN updated successfully!';
    setChangePinSuccess(successMsg);
    if (showNotification) showNotification(successMsg, 'success');

    setTimeout(() => {
      setIsChangePinModalOpen(false);
      setChangePinSuccess(null);
      setCurrentPinInput('');
      setMasterAnswerInput('');
      setNewPinInput('');
      setConfirmNewPinInput('');
    }, 1200);
  };

  // Submit Update Master Security Answer
  const handleUpdateAnswerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUpdateAnswerError(null);

    const savedPin = localStorage.getItem('app_lock_pin') || '';
    if (answerAuthPin !== savedPin) {
      setUpdateAnswerError(language === 'hi' ? 'वर्तमान 4-अंकीय पिन गलत है।' : 'Current 4-digit PIN is incorrect.');
      playScanAudioTone(false);
      return;
    }

    const trimmedNewAnswer = newAnswerInput.trim();
    if (!trimmedNewAnswer || trimmedNewAnswer.length < 2) {
      setUpdateAnswerError(language === 'hi' ? 'कृपया कम से कम 2 अक्षरों का उत्तर दर्ज करें।' : 'Please enter a valid recovery answer (at least 2 characters).');
      return;
    }

    localStorage.setItem('app_lock_recovery', trimmedNewAnswer);
    playScanAudioTone(true);

    const successMsg = language === 'hi' ? 'मास्टर रिकवरी उत्तर सफलतापूर्वक अपडेट किया गया!' : 'Master Security Answer updated successfully!';
    setUpdateAnswerSuccess(successMsg);
    if (showNotification) showNotification(successMsg, 'success');

    setTimeout(() => {
      setIsUpdateAnswerModalOpen(false);
      setUpdateAnswerSuccess(null);
      setAnswerAuthPin('');
      setNewAnswerInput('');
    }, 1200);
  };

  // Submit Update Master Admin Email
  const handleUpdateEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setEditEmailError(null);

    const savedPin = localStorage.getItem('app_lock_pin') || '';
    if (emailAuthPin !== savedPin) {
      setEditEmailError(language === 'hi' ? 'वर्तमान 4-अंकीय पिन गलत है।' : 'Current 4-digit PIN is incorrect.');
      playScanAudioTone(false);
      return;
    }

    const trimmedEmail = newEmailInput.trim();
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setEditEmailError(language === 'hi' ? 'कृपया एक वैध ईमेल पता दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }

    localStorage.setItem('app_master_email', trimmedEmail);
    setAdminEmail(trimmedEmail);
    playScanAudioTone(true);

    const successMsg = language === 'hi' ? 'मास्टर एडमिन ईमेल अपडेट किया गया!' : 'Master Admin Email updated successfully!';
    setEditEmailSuccess(successMsg);
    if (showNotification) showNotification(successMsg, 'success');

    setTimeout(() => {
      setIsEditEmailModalOpen(false);
      setEditEmailSuccess(null);
      setEmailAuthPin('');
      setNewEmailInput('');
    }, 1200);
  };

  return (
    <div className="bg-white border border-slate-200/90 rounded-2xl p-6 space-y-5 shadow-xs">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>{language === 'hi' ? 'सुरक्षा, मास्टर लॉगिन व ऐप पिन लॉक' : 'Security & Master PIN Lock'}</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                isLockEnabled && hasPinSet
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : 'bg-amber-50 text-amber-700 border-amber-200'
              }`}>
                {isLockEnabled && hasPinSet ? '● Protected' : '○ Disabled'}
              </span>
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {language === 'hi'
                ? 'मास्टर एडमिन ईमेल, 4-अंकीय पासकोड गेटकीपर और आपातकालीन रिकवरी की प्रबंधित करें।'
                : 'Manage Master Admin Email, 4-digit PIN lock screen, and master recovery key.'}
            </p>
          </div>
        </div>

        {/* Lock App Now Quick Trigger */}
        {isLockEnabled && hasPinSet && (
          <button
            type="button"
            id="btn-lock-app-now"
            onClick={handleLockNow}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer self-start sm:self-auto shrink-0 active:scale-95"
            title="Immediately lock app to test login screen"
          >
            <Lock className="w-3.5 h-3.5 text-slate-500" />
            <span>{language === 'hi' ? 'अभी लॉक करें' : 'Lock App Now'}</span>
          </button>
        )}
      </div>

      {/* Master Admin Profile Summary Banner */}
      <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <Mail className="w-4 h-4 text-indigo-600 shrink-0" />
          <div className="text-xs">
            <span className="text-slate-500 font-medium">Master Admin Account: </span>
            <strong className="text-slate-900 font-bold">{adminEmail}</strong>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setIsEditEmailModalOpen(true);
            setEditEmailError(null);
            setEditEmailSuccess(null);
            setEmailAuthPin('');
            setNewEmailInput(adminEmail);
          }}
          className="px-3 py-1 bg-white hover:bg-indigo-50 border border-indigo-200 text-indigo-700 rounded-lg text-xs font-bold transition cursor-pointer self-start sm:self-auto flex items-center gap-1.5 shadow-2xs"
        >
          <Edit3 className="w-3 h-3" />
          <span>Edit Email</span>
        </button>
      </div>

      {/* Main Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* 1. Toggle Lock on App Start */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-3">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                {isLockEnabled ? <Lock className="w-3.5 h-3.5 text-indigo-600" /> : <Unlock className="w-3.5 h-3.5 text-slate-400" />}
                <span>{language === 'hi' ? 'ऐप स्टार्ट पर लॉक' : 'Lock on App Start'}</span>
              </span>
              <span className={`text-[10px] font-bold ${isLockEnabled ? 'text-indigo-600' : 'text-slate-400'}`}>
                {isLockEnabled ? 'ENABLED' : 'DISABLED'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
              {language === 'hi'
                ? 'ऐप खुलने पर मास्टर ईमेल/पिन प्रविष्ट करना अनिवार्य रखें।'
                : 'Require Master Admin login or 4-digit PIN verification whenever the app opens.'}
            </p>
          </div>

          <button
            type="button"
            id="btn-toggle-app-lock"
            onClick={handleToggleLock}
            className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-xs active:scale-98 ${
              isLockEnabled
                ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/20'
            }`}
          >
            {isLockEnabled ? (
              <>
                <Unlock className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'लॉक निष्क्रिय करें' : 'Disable PIN Lock'}</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'लॉक सक्रिय करें' : 'Enable PIN Lock'}</span>
              </>
            )}
          </button>
        </div>

        {/* 2. Change Security PIN */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-3">
          <div className="space-y-1">
            <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-indigo-600" />
              <span>{language === 'hi' ? 'सुरक्षा पिन बदलें' : 'Change Security PIN'}</span>
            </span>
            <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
              {language === 'hi'
                ? 'पुराने पिन या मास्टर रिकवरी की से नया 4-अंकीय पासकोड सेट करें।'
                : 'Update your 4-digit numerical PIN using your current PIN or master key.'}
            </p>
          </div>

          <button
            type="button"
            id="btn-open-change-pin-modal"
            onClick={() => {
              setIsChangePinModalOpen(true);
              setChangePinError(null);
              setChangePinSuccess(null);
              setCurrentPinInput('');
              setMasterAnswerInput('');
              setNewPinInput('');
              setConfirmNewPinInput('');
            }}
            className="w-full py-2.5 px-3 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-2xs active:scale-98"
          >
            <Key className="w-3.5 h-3.5 text-indigo-600" />
            <span>{language === 'hi' ? 'पिन बदलें' : 'Change PIN'}</span>
          </button>
        </div>

        {/* 3. Update Master Security Answer */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-3">
          <div className="space-y-1">
            <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'hi' ? 'मास्टर रिकवरी की अपडेट करें' : 'Update Master Key'}</span>
            </span>
            <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
              {language === 'hi'
                ? 'आपातकालीन रिकवरी के लिए गुप्त सुरक्षा प्रश्न/उत्तर अपडेट करें।'
                : 'Update your secret recovery phrase used when PIN is forgotten.'}
            </p>
          </div>

          <button
            type="button"
            id="btn-open-update-answer-modal"
            onClick={() => {
              setIsUpdateAnswerModalOpen(true);
              setUpdateAnswerError(null);
              setUpdateAnswerSuccess(null);
              setAnswerAuthPin('');
              setNewAnswerInput('');
            }}
            className="w-full py-2.5 px-3 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-2xs active:scale-98"
          >
            <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'hi' ? 'रिकवरी उत्तर बदलें' : 'Update Recovery Key'}</span>
          </button>
        </div>

      </div>

      {/* MODAL 1: Change Security PIN */}
      {isChangePinModalOpen && (
        <div className="fixed inset-0 z-9999 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div 
            id="modal-change-security-pin"
            className="bg-white rounded-3xl border border-slate-200 max-w-md w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Change Security PIN</h3>
                  <p className="text-[11px] text-slate-500">Set a new 4-digit numeric passcode</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsChangePinModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {changePinError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{changePinError}</span>
              </div>
            )}

            {changePinSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{changePinSuccess}</span>
              </div>
            )}

            <form onSubmit={handleChangePinSubmit} className="space-y-4">
              
              {/* Auth Selector */}
              <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl">
                <button
                  type="button"
                  onClick={() => setPinAuthMethod('pin')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    pinAuthMethod === 'pin' 
                      ? 'bg-white text-indigo-600 shadow-2xs' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Verify Old PIN
                </button>
                <button
                  type="button"
                  onClick={() => setPinAuthMethod('master')}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    pinAuthMethod === 'master' 
                      ? 'bg-white text-indigo-600 shadow-2xs' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Verify Recovery Key
                </button>
              </div>

              {pinAuthMethod === 'pin' ? (
                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700 block">Current 4-Digit PIN:</label>
                  <input
                    type="password"
                    maxLength={4}
                    autoFocus
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={currentPinInput}
                    onChange={(e) => setCurrentPinInput(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                    placeholder="••••"
                    className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-4 font-mono text-center text-lg tracking-widest font-black text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>
              ) : (
                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700 block">Master Security Recovery Answer:</label>
                  <input
                    type="text"
                    autoFocus
                    value={masterAnswerInput}
                    onChange={(e) => setMasterAnswerInput(e.target.value)}
                    placeholder="Enter your secret recovery answer"
                    className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-3.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>
              )}

              <div className="pt-2 border-t border-slate-100 space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700 block">New 4-Digit PIN:</label>
                  <input
                    type="password"
                    maxLength={4}
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={newPinInput}
                    onChange={(e) => setNewPinInput(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                    placeholder="e.g. 1234"
                    className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-4 font-mono text-center text-lg tracking-widest font-black text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700 block">Confirm New PIN:</label>
                  <input
                    type="password"
                    maxLength={4}
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={confirmNewPinInput}
                    onChange={(e) => setConfirmNewPinInput(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                    placeholder="Re-enter new PIN"
                    className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-4 font-mono text-center text-lg tracking-widest font-black text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsChangePinModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-save-changed-pin"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer"
                >
                  Save New PIN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Update Master Security Answer */}
      {isUpdateAnswerModalOpen && (
        <div className="fixed inset-0 z-9999 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div 
            id="modal-update-master-answer"
            className="bg-white rounded-3xl border border-slate-200 max-w-md w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Update Master Recovery Answer</h3>
                  <p className="text-[11px] text-slate-500">Secret phrase for emergency PIN recovery</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUpdateAnswerModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {updateAnswerError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{updateAnswerError}</span>
              </div>
            )}

            {updateAnswerSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{updateAnswerSuccess}</span>
              </div>
            )}

            <form onSubmit={handleUpdateAnswerSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 block">Confirm Current 4-Digit PIN:</label>
                <input
                  type="password"
                  maxLength={4}
                  autoFocus
                  pattern="[0-9]*"
                  inputMode="numeric"
                  value={answerAuthPin}
                  onChange={(e) => setAnswerAuthPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-4 font-mono text-center text-lg tracking-widest font-black text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                />
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-100">
                <label className="text-xs font-black text-slate-700 block">New Master Security Answer / Recovery Word:</label>
                <input
                  type="text"
                  value={newAnswerInput}
                  onChange={(e) => setNewAnswerInput(e.target.value)}
                  placeholder="e.g. Favorite City / Pet Name / Secret Word"
                  className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-3.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                />
                <p className="text-[11px] text-slate-400 font-medium">
                  This secret answer can be used if you ever forget your 4-digit PIN.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsUpdateAnswerModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-save-new-master-answer"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer"
                >
                  Save Recovery Answer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Edit Master Admin Email */}
      {isEditEmailModalOpen && (
        <div className="fixed inset-0 z-9999 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div 
            id="modal-edit-master-email"
            className="bg-white rounded-3xl border border-slate-200 max-w-md w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Update Master Admin Email</h3>
                  <p className="text-[11px] text-slate-500">Change the primary administrator email address</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEditEmailModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {editEmailError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{editEmailError}</span>
              </div>
            )}

            {editEmailSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                <span>{editEmailSuccess}</span>
              </div>
            )}

            <form onSubmit={handleUpdateEmailSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 block">Confirm Current 4-Digit PIN:</label>
                <input
                  type="password"
                  maxLength={4}
                  autoFocus
                  pattern="[0-9]*"
                  inputMode="numeric"
                  value={emailAuthPin}
                  onChange={(e) => setEmailAuthPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-4 font-mono text-center text-lg tracking-widest font-black text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                />
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-100">
                <label className="text-xs font-black text-slate-700 block">New Master Admin Email:</label>
                <input
                  type="email"
                  required
                  value={newEmailInput}
                  onChange={(e) => setNewEmailInput(e.target.value)}
                  placeholder="admin@example.com"
                  className="w-full h-11 bg-slate-50 border border-slate-300 rounded-xl px-3.5 text-xs font-bold text-slate-900 focus:bg-white focus:border-indigo-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditEmailModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-save-new-admin-email"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer"
                >
                  Save Admin Email
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
