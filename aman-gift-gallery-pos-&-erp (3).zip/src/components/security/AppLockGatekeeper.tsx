import React, { useState, useEffect, useCallback } from 'react';
import { 
  Lock, 
  Unlock, 
  KeyRound, 
  Eye, 
  EyeOff, 
  Delete, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Mail, 
  Key, 
  Cloud, 
  RefreshCw, 
  LogIn, 
  UserPlus, 
  ChevronLeft, 
  UserCheck,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { playScanAudioTone } from '../../utils/barcodeImageDecoder';
import { 
  loginWithEmailCloud, 
  registerWithEmailCloud, 
  sendCloudPasswordReset,
  subscribeToCloudAuthState,
  logoutCloudUser,
  CloudAccountProfile,
  auth
} from '../../lib/firebase';
import { useApp } from '../../context/AppContext';

interface AppLockGatekeeperProps {
  children: React.ReactNode;
}

// Request media and notification permissions smoothly without blocking UI
const triggerSmoothBrowserPermissions = async () => {
  try {
    if (navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach((track) => track.stop());
    }
  } catch (err) {
    console.debug('Media permission handled:', err);
  }

  try {
    if ('Notification' in window && Notification.permission === 'default') {
      await Notification.requestPermission();
    }
  } catch (err) {
    console.debug('Notification permission handled:', err);
  }
};

export const AppLockGatekeeper: React.FC<AppLockGatekeeperProps> = ({ children }) => {
  const defaultAdminEmail = '007ashu9835@gmail.com';
  
  // App context (if available)
  let appContext: ReturnType<typeof useApp> | null = null;
  try {
    appContext = useApp();
  } catch {
    appContext = null;
  }

  // Check stored PIN (default to 1234 if not yet set)
  const [configuredPin, setConfiguredPin] = useState<string>(() => {
    const saved = localStorage.getItem('app_lock_pin');
    if (!saved) {
      localStorage.setItem('app_lock_pin', '1234');
      localStorage.setItem('app_lock_recovery', 'aman');
      localStorage.setItem('app_lock_enabled', 'true');
      return '1234';
    }
    return saved;
  });

  // Strict 2-Step Sequential Authentication:
  // Step 1: 4-Digit PIN Keypad
  // Step 2: Mandatory Firebase Cloud Login (Email & Password)
  const [currentStep, setCurrentStep] = useState<1 | 2>(1);
  const [isPinVerified, setIsPinVerified] = useState<boolean>(false);
  const [isFullyUnlocked, setIsFullyUnlocked] = useState<boolean>(false);

  // Step 1: PIN State
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [showPinText, setShowPinText] = useState<boolean>(false);
  const [pinErrorMessage, setPinErrorMessage] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState<boolean>(false);

  // Step 2: Firebase Auth State
  const [cloudAuthMode, setCloudAuthMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [cloudEmail, setCloudEmail] = useState<string>(() => {
    return localStorage.getItem('app_master_email') || defaultAdminEmail;
  });
  const [cloudPassword, setCloudPassword] = useState<string>('');
  const [cloudDisplayName, setCloudDisplayName] = useState<string>('Aman Gift Gallery Admin');
  const [showCloudPassword, setShowCloudPassword] = useState<boolean>(false);
  const [cloudAuthLoading, setCloudAuthLoading] = useState<boolean>(false);
  const [cloudAuthError, setCloudAuthError] = useState<string | null>(null);
  const [cloudAuthSuccessMsg, setCloudAuthSuccessMsg] = useState<string | null>(null);

  // Active Firebase User
  const [activeUser, setActiveUser] = useState<CloudAccountProfile | null>(() => {
    if (auth.currentUser && !auth.currentUser.isAnonymous) {
      return {
        uid: auth.currentUser.uid,
        email: auth.currentUser.email,
        displayName: auth.currentUser.displayName,
        photoURL: auth.currentUser.photoURL,
        isAnonymous: false
      };
    }
    return null;
  });

  // Check if Master Firebase Account session is active (Khatabook/Vyapar model)
  const isMasterSessionActive = useCallback((): boolean => {
    const forceRelogin = localStorage.getItem('app_force_relogin') === 'true';
    if (forceRelogin) return false;

    if (auth.currentUser && !auth.currentUser.isAnonymous) {
      return true;
    }

    const savedCloudAuth = localStorage.getItem('firebase_cloud_authenticated') === 'true';
    const savedAccount = localStorage.getItem('cloud_user_account');
    const savedUid = localStorage.getItem('app_master_uid');
    if (savedCloudAuth || savedAccount || savedUid) {
      return true;
    }
    return false;
  }, []);

  useEffect(() => {
    const handleImmediateLock = () => {
      setCurrentStep(1);
      setIsPinVerified(false);
      setIsFullyUnlocked(false);
      setActiveUser(null);
      setEnteredPin('');
      setCloudPassword('');
      setPinErrorMessage(null);
      setCloudAuthError(null);
      setCloudAuthSuccessMsg(null);
    };

    window.addEventListener('app_lock_required', handleImmediateLock);
    if (localStorage.getItem('app_force_relogin') === 'true') {
      handleImmediateLock();
    }
    return () => {
      window.removeEventListener('app_lock_required', handleImmediateLock);
    };
  }, []);

  // Forgot PIN / Recovery Modal State
  const [isForgotModalOpen, setIsForgotModalOpen] = useState<boolean>(false);
  const [recoveryAnswerInput, setRecoveryAnswerInput] = useState<string>('');
  const [recoveryStep, setRecoveryStep] = useState<'verify' | 'reset'>('verify');
  const [newResetPin, setNewResetPin] = useState<string>('');
  const [confirmResetPin, setConfirmResetPin] = useState<string>('');
  const [recoveryError, setRecoveryError] = useState<string | null>(null);

  // Subscribe to Firebase auth state changes
  useEffect(() => {
    const unsub = subscribeToCloudAuthState((user) => {
      if (user && !user.isAnonymous) {
        const prof: CloudAccountProfile = {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName || user.email?.split('@')[0] || 'Store Admin',
          photoURL: user.photoURL,
          isAnonymous: false
        };
        setActiveUser(prof);
        if (user.email) {
          setCloudEmail(user.email);
          localStorage.setItem('app_master_email', user.email);
        }
        localStorage.setItem('app_master_uid', user.uid);
      } else {
        setActiveUser(null);
      }
    });
    return () => unsub();
  }, []);

  // Hardware Keyboard support for Step 1 (PIN Keypad)
  useEffect(() => {
    if (isFullyUnlocked || isForgotModalOpen || currentStep !== 1) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        handleDigitPress(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        handleClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullyUnlocked, isForgotModalOpen, currentStep, enteredPin]);

  // Handle keypad digit input (Step 1)
  const handleDigitPress = (digit: string) => {
    setPinErrorMessage(null);
    if (enteredPin.length < 4) {
      const nextPin = enteredPin + digit;
      setEnteredPin(nextPin);

      if (nextPin.length === 4) {
        verifyStep1Pin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPinErrorMessage(null);
    setEnteredPin((prev) => prev.slice(0, -1));
  };

  const handleClear = () => {
    setPinErrorMessage(null);
    setEnteredPin('');
  };

  // STEP 1: Verify 4-Digit PIN -> Check active session or transition to Step 2
  const verifyStep1Pin = (pinToTest: string) => {
    const savedPin = localStorage.getItem('app_lock_pin') || configuredPin || '1234';
    if (pinToTest === savedPin) {
      playScanAudioTone(true);
      setPinErrorMessage(null);
      setIsPinVerified(true);
      setEnteredPin('');
      
      // Exact Khatabook / Vyapar Lifecycle:
      // If user has an active Master Account session in storage and was not explicitly logged out,
      // directly unlock the POS & ERP dashboard immediately upon entering the 4-digit PIN!
      if (isMasterSessionActive()) {
        completeFullDashboardUnlock();
      } else {
        // First login or explicitly logged out: proceed to Step 2 for Master Account verification
        setCurrentStep(2);
      }
    } else {
      triggerPinFailure('Incorrect 4-Digit PIN. Please enter your valid PIN.');
      setTimeout(() => {
        setEnteredPin('');
      }, 600);
    }
  };

  const triggerPinFailure = (msg: string) => {
    playScanAudioTone(false);
    setIsShaking(true);
    setPinErrorMessage(msg);
    setTimeout(() => {
      setIsShaking(false);
    }, 500);
  };

  // STEP 2: Handle Firebase Email & Password Sign In
  const handleFirebaseEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setCloudAuthError(null);
    setCloudAuthSuccessMsg(null);
    setCloudAuthLoading(true);

    const trimmedEmail = cloudEmail.trim().toLowerCase();
    const trimmedPass = cloudPassword.trim();

    if (!trimmedEmail) {
      setCloudAuthError('Please enter your Master Email address.');
      setCloudAuthLoading(false);
      return;
    }

    if (!trimmedPass) {
      setCloudAuthError('Please enter your Master Account Password.');
      setCloudAuthLoading(false);
      return;
    }

    try {
      localStorage.setItem('app_master_email', trimmedEmail);
      let userObj;
      if (appContext?.loginWithEmailAccount) {
        userObj = await appContext.loginWithEmailAccount(trimmedEmail, trimmedPass);
      } else {
        userObj = await loginWithEmailCloud(trimmedEmail, trimmedPass);
      }
      
      if (userObj?.uid) {
        localStorage.setItem('app_master_uid', userObj.uid);
      }

      playScanAudioTone(true);
      setCloudAuthSuccessMsg('Firebase Master Account Authenticated! Unlocking POS...');
      
      // Screen 3: Successfully authenticated -> Unlock Dashboard
      setTimeout(() => {
        completeFullDashboardUnlock();
      }, 400);
    } catch (err: any) {
      console.warn('Firebase Email login error:', err);
      const code = err?.code || '';
      let msg = err?.message || 'Authentication failed. Please check email and password.';
      if (code === 'auth/wrong-password' || code === 'auth/invalid-credential') {
        msg = 'Incorrect Master Account Password. Please check your password or use "Forgot Password?".';
      } else if (code === 'auth/invalid-email') {
        msg = 'Invalid email format. Please enter a valid address.';
      } else if (code === 'auth/network-request-failed') {
        msg = 'Firebase Network error. Please check your internet connection.';
      } else if (code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      }
      setCloudAuthError(msg);
      playScanAudioTone(false);
    } finally {
      setCloudAuthLoading(false);
    }
  };

  // STEP 2: Handle Firebase Email Registration
  const handleFirebaseRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setCloudAuthError(null);
    setCloudAuthSuccessMsg(null);
    setCloudAuthLoading(true);

    const trimmedEmail = cloudEmail.trim().toLowerCase();
    const trimmedPass = cloudPassword.trim();

    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setCloudAuthError('Please enter a valid email address.');
      setCloudAuthLoading(false);
      return;
    }

    if (trimmedPass.length < 6) {
      setCloudAuthError('Password must be at least 6 characters.');
      setCloudAuthLoading(false);
      return;
    }

    try {
      localStorage.setItem('app_master_email', trimmedEmail);
      let userObj;
      if (appContext?.registerWithEmailAccount) {
        userObj = await appContext.registerWithEmailAccount(trimmedEmail, trimmedPass, cloudDisplayName);
      } else {
        userObj = await registerWithEmailCloud(trimmedEmail, trimmedPass, cloudDisplayName);
      }

      if (userObj?.uid) {
        localStorage.setItem('app_master_uid', userObj.uid);
      }

      playScanAudioTone(true);
      setCloudAuthSuccessMsg('Master Cloud Account created & authenticated! Unlocking...');
      
      // Unlock Dashboard
      setTimeout(() => {
        completeFullDashboardUnlock();
      }, 400);
    } catch (err: any) {
      console.warn('Firebase Registration error:', err);
      const code = err?.code || '';
      let msg = err?.message || 'Registration failed.';
      if (code === 'auth/email-already-in-use') {
        msg = 'Account already exists for this email. Please switch to Sign In.';
        setCloudAuthMode('signin');
      }
      setCloudAuthError(msg);
      playScanAudioTone(false);
    } finally {
      setCloudAuthLoading(false);
    }
  };

  // STEP 2: Handle Password Reset Email
  const handleFirebasePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setCloudAuthError(null);
    setCloudAuthSuccessMsg(null);

    const trimmedEmail = cloudEmail.trim().toLowerCase();
    if (!trimmedEmail) {
      setCloudAuthError('Please enter your email to send password reset instructions.');
      return;
    }

    try {
      if (appContext?.sendPasswordResetLink) {
        await appContext.sendPasswordResetLink(trimmedEmail);
      } else {
        await sendCloudPasswordReset(trimmedEmail);
      }
      setCloudAuthSuccessMsg(`Password reset email sent to ${trimmedEmail}. Please check your inbox.`);
      playScanAudioTone(true);
    } catch (err: any) {
      setCloudAuthError(err?.message || 'Failed to send reset email.');
      playScanAudioTone(false);
    }
  };

  // STEP 2: If User is already authenticated with Firebase, allow confirming unlock
  const handleConfirmActiveUserUnlock = () => {
    if (!activeUser?.email) {
      setCloudAuthError('No active Firebase user found. Please enter your email and password.');
      return;
    }
    playScanAudioTone(true);
    setCloudAuthSuccessMsg(`Authenticated as ${activeUser.email}! Unlocking POS...`);
    setTimeout(() => {
      completeFullDashboardUnlock();
    }, 300);
  };

  // SCREEN 3: Final Unlock - Open POS & ERP Dashboard
  const completeFullDashboardUnlock = () => {
    playScanAudioTone(true);
    setIsFullyUnlocked(true);
    localStorage.setItem('firebase_cloud_authenticated', 'true');
    localStorage.removeItem('app_force_relogin');
    setPinErrorMessage(null);
    setCloudAuthError(null);
    triggerSmoothBrowserPermissions();
  };

  // Recovery Modal: Verify Security Answer
  const handleVerifyRecovery = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    const savedAnswer = (localStorage.getItem('app_lock_recovery') || 'aman').trim().toLowerCase();
    const inputAnswer = recoveryAnswerInput.trim().toLowerCase();

    if (!inputAnswer) {
      setRecoveryError('Please enter your Master Security Recovery Answer.');
      return;
    }

    if (inputAnswer === savedAnswer) {
      setRecoveryStep('reset');
      setRecoveryError(null);
    } else {
      setRecoveryError('Security Answer does not match. Please try again.');
    }
  };

  // Recovery Modal: Reset New 4-Digit PIN
  const handleSaveResetPin = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    if (newResetPin.length !== 4 || !/^\d{4}$/.test(newResetPin)) {
      setRecoveryError('New PIN must be exactly 4 numeric digits.');
      return;
    }

    if (newResetPin !== confirmResetPin) {
      setRecoveryError('New PIN and confirmation do not match.');
      return;
    }

    localStorage.setItem('app_lock_pin', newResetPin);
    setConfiguredPin(newResetPin);

    setIsForgotModalOpen(false);
    setRecoveryStep('verify');
    setRecoveryAnswerInput('');
    setNewResetPin('');
    setConfirmResetPin('');
    playScanAudioTone(true);
    
    // Once reset, mark PIN as verified and unlock dashboard if session is active
    setIsPinVerified(true);
    if (isMasterSessionActive()) {
      completeFullDashboardUnlock();
    } else {
      setCurrentStep(2);
    }
  };

  // ----------------------------------------------------
  // IF FULLY UNLOCKED -> RENDER POS & ERP DASHBOARD
  // ----------------------------------------------------
  if (isFullyUnlocked) {
    return <>{children}</>;
  }

  const isSessionLinked = isMasterSessionActive();

  // ----------------------------------------------------
  // MANDATORY SECURITY & AUTHENTICATION SCREENS
  // ----------------------------------------------------
  return (
    <div className="fixed inset-0 z-9999 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 flex flex-col items-center justify-center p-4 select-none">
      
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-sm w-full space-y-4 relative z-10 flex flex-col items-center">
        
        {/* Brand Header */}
        <div className="text-center space-y-1 flex flex-col items-center">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center shadow-lg shadow-indigo-900/50 mb-0.5">
            {currentStep === 1 ? <Lock className="w-7 h-7 text-indigo-400" /> : <Cloud className="w-7 h-7 text-indigo-400" />}
          </div>
          
          <h1 className="text-xl font-black text-white tracking-tight">
            Aman Gift Gallery
          </h1>
          
          <p className="text-xs text-slate-400 font-medium">
            {currentStep === 1 
              ? (isSessionLinked ? 'Enter 4-Digit PIN to Unlock Dashboard' : 'STEP 1: 4-Digit Security PIN Verification')
              : 'STEP 2: Master Account Email & Password Login'}
          </p>
        </div>

        {/* Status Indicator Bar */}
        <div className="w-full bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl flex items-center justify-between text-xs shadow-inner">
          {/* Step 1 Pill */}
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition ${
            currentStep === 1
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-emerald-950/70 text-emerald-400 border border-emerald-800/60'
          }`}>
            {currentStep > 1 || isPinVerified ? <CheckCircle2 className="w-3.5 h-3.5" /> : <span>1</span>}
            <span>{isSessionLinked ? 'Quick PIN Unlock' : 'Step 1: PIN Keypad'}</span>
          </div>

          <div className="w-6 h-0.5 bg-slate-800" />

          {/* Step 2 Pill / Active Session Badge */}
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition ${
            currentStep === 2
              ? 'bg-indigo-600 text-white shadow-xs'
              : isSessionLinked
                ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-800/40 text-[11px]'
                : 'text-slate-500'
          }`}>
            {isSessionLinked ? (
              <>
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="truncate max-w-[110px]">{activeUser?.email || cloudEmail || 'Master Linked'}</span>
              </>
            ) : (
              <>
                <span>2</span>
                <span>Step 2: Cloud Login</span>
              </>
            )}
          </div>
        </div>

        {/* ==================================================== */}
        {/* SCREEN 1: DEDICATED 4-DIGIT PIN KEYPAD SCREEN */}
        {/* ==================================================== */}
        {currentStep === 1 && (
          <div className="w-full space-y-4 flex flex-col items-center animate-in fade-in zoom-in-95 duration-200">
            
            {/* Error Banner */}
            {pinErrorMessage && (
              <div className="text-center text-xs font-bold text-rose-300 bg-rose-950/80 border border-rose-800/90 rounded-xl py-2 px-3.5 w-full animate-in fade-in duration-150 flex items-center justify-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{pinErrorMessage}</span>
              </div>
            )}

            {/* 4-Digit Display Indicator Boxes */}
            <div className={`flex items-center justify-center gap-3 py-1 ${isShaking ? 'animate-bounce' : ''}`}>
              {[0, 1, 2, 3].map((idx) => {
                const isFilled = enteredPin.length > idx;
                const digitChar = enteredPin[idx];
                return (
                  <div
                    key={idx}
                    className={`w-13 h-14 rounded-2xl border-2 flex items-center justify-center font-mono text-2xl font-black transition-all duration-150 ${
                      isFilled
                        ? 'border-indigo-500 bg-indigo-950/70 text-white shadow-md shadow-indigo-500/20 scale-105'
                        : 'border-slate-800 bg-slate-900/60 text-transparent'
                    }`}
                  >
                    {isFilled ? (showPinText ? digitChar : '•') : ''}
                  </div>
                );
              })}
            </div>

            {/* Show / Hide Toggle & Clear */}
            <div className="flex items-center justify-between w-full px-2 text-xs">
              <button
                type="button"
                onClick={() => setShowPinText(!showPinText)}
                className="text-slate-400 hover:text-slate-200 flex items-center gap-1.5 transition py-0.5 cursor-pointer"
              >
                {showPinText ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showPinText ? 'Hide PIN' : 'Show PIN'}</span>
              </button>

              {enteredPin.length > 0 && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="text-slate-400 hover:text-rose-400 font-bold transition py-0.5 cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>

            {/* 3x4 Tactile Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2.5 w-full">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  type="button"
                  id={`btn-keypad-digit-${num}`}
                  onClick={() => handleDigitPress(num.toString())}
                  className="h-13 bg-slate-800/80 hover:bg-slate-700 active:bg-indigo-600 border border-slate-700/60 hover:border-slate-600 text-white text-xl font-bold rounded-2xl flex items-center justify-center transition shadow-xs cursor-pointer active:scale-95 select-none"
                >
                  {num}
                </button>
              ))}

              <button
                type="button"
                id="btn-keypad-action-clear"
                onClick={handleClear}
                className="h-13 bg-slate-900/90 hover:bg-slate-800 active:bg-slate-700 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs font-black rounded-2xl flex items-center justify-center transition cursor-pointer active:scale-95 select-none"
              >
                CLEAR
              </button>

              <button
                type="button"
                id="btn-keypad-digit-0"
                onClick={() => handleDigitPress('0')}
                className="h-13 bg-slate-800/80 hover:bg-slate-700 active:bg-indigo-600 border border-slate-700/60 hover:border-slate-600 text-white text-xl font-bold rounded-2xl flex items-center justify-center transition shadow-xs cursor-pointer active:scale-95 select-none"
              >
                0
              </button>

              <button
                type="button"
                id="btn-keypad-action-backspace"
                onClick={handleBackspace}
                className="h-13 bg-slate-900/90 hover:bg-slate-800 active:bg-slate-700 border border-slate-800 text-slate-400 hover:text-rose-300 text-sm font-bold rounded-2xl flex items-center justify-center transition cursor-pointer active:scale-95 select-none"
                title="Delete last digit"
              >
                <Delete className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Helper Text & Recovery Trigger */}
            <div className="flex flex-col items-center gap-1.5 pt-1">
              <span className="text-[11px] text-slate-500">Default PIN: <strong className="text-slate-400 font-mono">1234</strong></span>
              <button
                type="button"
                id="btn-forgot-pin-trigger"
                onClick={() => {
                  setIsForgotModalOpen(true);
                  setRecoveryStep('verify');
                  setRecoveryError(null);
                  setRecoveryAnswerInput('');
                }}
                className="text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 py-1 px-3 rounded-xl hover:bg-indigo-950/40 transition cursor-pointer"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Forgot PIN? Recover & Reset</span>
              </button>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* SCREEN 2: MANDATORY FIREBASE CLOUD LOGIN SCREEN */}
        {/* ==================================================== */}
        {currentStep === 2 && (
          <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95 duration-200 text-white">
            
            {/* Top Navigation & Status */}
            <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setCurrentStep(1);
                  setEnteredPin('');
                }}
                className="text-slate-400 hover:text-white flex items-center gap-1 font-bold cursor-pointer transition"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>← Step 1 (PIN)</span>
              </button>

              <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-800/60">
                <CheckCircle2 className="w-3.5 h-3.5" />
                PIN Verified
              </span>
            </div>

            {/* Title description */}
            <div className="text-center">
              <h2 className="text-base font-black text-white">
                {cloudAuthMode === 'signin' && 'Firebase Master Account Login'}
                {cloudAuthMode === 'signup' && 'Register New Master Account'}
                {cloudAuthMode === 'forgot' && 'Reset Master Password'}
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Authentication is required to unlock POS and synchronize real-time Firestore database.
              </p>
            </div>

            {/* Error Message */}
            {cloudAuthError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800/90 text-rose-300 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{cloudAuthError}</span>
              </div>
            )}

            {/* Success Message */}
            {cloudAuthSuccessMsg && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-800/90 text-emerald-300 text-xs font-bold rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{cloudAuthSuccessMsg}</span>
              </div>
            )}

            {/* CASE 1: User already has an active authenticated session */}
            {activeUser && (
              <div className="p-3.5 bg-emerald-950/40 border border-emerald-800/60 rounded-2xl space-y-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] uppercase tracking-wider text-emerald-400 font-bold">Firebase Active Session</div>
                    <div className="text-xs font-black text-white truncate">{activeUser.email}</div>
                  </div>
                </div>

                <button
                  type="button"
                  id="btn-confirm-active-firebase-unlock"
                  onClick={handleConfirmActiveUserUnlock}
                  className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-black text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Unlock className="w-4 h-4" />
                  <span>Authenticate & Unlock POS Dashboard</span>
                </button>
              </div>
            )}

            {/* CASE 2: Firebase Sign-In Form (MANDATORY EMAIL & PASSWORD) */}
            {cloudAuthMode === 'signin' && (
              <form onSubmit={handleFirebaseEmailSignIn} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">
                    Master Email Address:
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="email"
                      required
                      id="input-cloud-login-email"
                      value={cloudEmail}
                      onChange={(e) => setCloudEmail(e.target.value)}
                      placeholder="007ashu9835@gmail.com"
                      className="w-full h-11 bg-slate-950/80 border border-slate-700/80 rounded-xl pl-10 pr-3 text-xs font-bold text-white placeholder:text-slate-600 focus:border-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-300 block">
                      Account Password:
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowCloudPassword(!showCloudPassword)}
                      className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                    >
                      {showCloudPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      <span>{showCloudPassword ? 'Hide' : 'Show'}</span>
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type={showCloudPassword ? 'text' : 'password'}
                      required
                      autoFocus
                      id="input-cloud-login-password"
                      value={cloudPassword}
                      onChange={(e) => setCloudPassword(e.target.value)}
                      placeholder="Enter Firebase password"
                      className="w-full h-11 bg-slate-950/80 border border-slate-700/80 rounded-xl pl-10 pr-3 text-xs font-bold text-white placeholder:text-slate-600 focus:border-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  id="btn-cloud-signin-submit"
                  disabled={cloudAuthLoading}
                  className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-black text-sm rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  {cloudAuthLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
                  <span>Verify Password & Unlock Dashboard</span>
                </button>
              </form>
            )}

            {/* CASE 3: Firebase Sign-Up Form */}
            {cloudAuthMode === 'signup' && (
              <form onSubmit={handleFirebaseRegister} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">Store Name / Admin Name:</label>
                  <input
                    type="text"
                    required
                    value={cloudDisplayName}
                    onChange={(e) => setCloudDisplayName(e.target.value)}
                    placeholder="Aman Gift Gallery Admin"
                    className="w-full h-11 bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 text-xs font-bold text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">Email Address:</label>
                  <input
                    type="email"
                    required
                    value={cloudEmail}
                    onChange={(e) => setCloudEmail(e.target.value)}
                    placeholder="007ashu9835@gmail.com"
                    className="w-full h-11 bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 text-xs font-bold text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">Create Password (min 6 chars):</label>
                  <input
                    type="password"
                    required
                    value={cloudPassword}
                    onChange={(e) => setCloudPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-11 bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 text-xs font-bold text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <button
                  type="submit"
                  disabled={cloudAuthLoading}
                  className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-black text-sm rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  {cloudAuthLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
                  <span>Register Account & Unlock</span>
                </button>
              </form>
            )}

            {/* CASE 4: Forgot Password Mode */}
            {cloudAuthMode === 'forgot' && (
              <form onSubmit={handleFirebasePasswordReset} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">Master Email Address:</label>
                  <input
                    type="email"
                    required
                    value={cloudEmail}
                    onChange={(e) => setCloudEmail(e.target.value)}
                    placeholder="007ashu9835@gmail.com"
                    className="w-full h-11 bg-slate-950/80 border border-slate-700/80 rounded-xl px-3 text-xs font-bold text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full h-11 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
                >
                  Send Password Reset Link
                </button>
              </form>
            )}

            {/* Mode toggles (Direct Email & Password Login / Create Account / Forgot Password) */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              {cloudAuthMode === 'signin' ? (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setCloudAuthMode('signup');
                      setCloudAuthError(null);
                    }}
                    className="text-indigo-400 hover:text-indigo-300 font-bold cursor-pointer transition"
                  >
                    + Create Master Account
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCloudAuthMode('forgot');
                      setCloudAuthError(null);
                    }}
                    className="text-slate-400 hover:text-slate-300 cursor-pointer transition"
                  >
                    Forgot Password?
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setCloudAuthMode('signin');
                    setCloudAuthError(null);
                  }}
                  className="text-indigo-400 hover:text-indigo-300 font-bold cursor-pointer mx-auto transition"
                >
                  ← Back to Email Sign In
                </button>
              )}
            </div>

          </div>
        )}

      </div>

      {/* ==================================================== */}
      {/* FORGOT PIN / RECOVERY MODAL */}
      {/* ==================================================== */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-10000 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-sm w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 text-white shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                <h3 className="font-black text-sm">Recover 4-Digit PIN</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsForgotModalOpen(false)}
                className="text-slate-500 hover:text-white text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {recoveryError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{recoveryError}</span>
              </div>
            )}

            {recoveryStep === 'verify' ? (
              <form onSubmit={handleVerifyRecovery} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">
                    Security Recovery Answer / Word:
                  </label>
                  <p className="text-[11px] text-slate-400">
                    Enter the master secret word configured for this device (default: <strong className="text-slate-300 font-mono">aman</strong>).
                  </p>
                  <input
                    type="text"
                    required
                    autoFocus
                    value={recoveryAnswerInput}
                    onChange={(e) => setRecoveryAnswerInput(e.target.value)}
                    placeholder="Enter answer / secret word"
                    className="w-full h-11 bg-slate-950 border border-slate-700 rounded-xl px-3.5 text-xs font-bold text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full h-11 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition"
                >
                  Verify Answer
                </button>
              </form>
            ) : (
              <form onSubmit={handleSaveResetPin} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">
                    Enter New 4-Digit PIN:
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    autoFocus
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={newResetPin}
                    onChange={(e) => setNewResetPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                    placeholder="e.g. 1234"
                    className="w-full h-11 bg-slate-950 border border-slate-700 rounded-xl px-3 text-center font-mono text-lg font-black text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 block">
                    Confirm New PIN:
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    pattern="[0-9]*"
                    inputMode="numeric"
                    value={confirmResetPin}
                    onChange={(e) => setConfirmResetPin(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))}
                    placeholder="Re-enter PIN"
                    className="w-full h-11 bg-slate-950 border border-slate-700 rounded-xl px-3 text-center font-mono text-lg font-black text-white focus:border-indigo-500 focus:outline-hidden"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full h-11 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md cursor-pointer transition"
                >
                  Save New PIN & Continue to Step 2
                </button>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
