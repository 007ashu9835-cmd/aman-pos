import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SettingsModule } from '../settings/SettingsModule';
import { 
  Settings, 
  Trash2, 
  AlertTriangle, 
  X, 
  RefreshCw 
} from 'lucide-react';

interface SettingsModalProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen = true, 
  onClose 
}) => {
  const { wipeAllData, playBeep } = useApp();
  const [isWipeConfirmOpen, setIsWipeConfirmOpen] = useState(false);
  const [isWiping, setIsWiping] = useState(false);
  const [wipeSuccess, setWipeSuccess] = useState(false);

  const handleWipeAllData = async () => {
    try {
      setIsWiping(true);
      await wipeAllData();
      setIsWiping(false);
      setIsWipeConfirmOpen(false);
      setWipeSuccess(true);
      setTimeout(() => setWipeSuccess(false), 5000);
    } catch (err) {
      console.error('Failed to wipe data:', err);
      setIsWiping(false);
      setIsWipeConfirmOpen(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="w-full h-full relative">
      {/* Primary Settings Workspace */}
      <SettingsModule />

      {/* Standalone Quick-Action Floating Bar if needed */}
      {isWipeConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            id="settings-modal-wipe-dialog"
            className="bg-white rounded-3xl border border-rose-200 max-w-md w-full p-6 shadow-2xl space-y-5 animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-200 flex items-center justify-center text-rose-600 shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <button
                type="button"
                onClick={() => setIsWipeConfirmOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Wipe All Store Data / Fresh Start?
              </h3>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                This will clear localStorage and IndexedDB records (<code>products=[]</code>, <code>sales=[]</code>, <code>expenses=[]</code>) and immediately reset state to 0 items.
              </p>

              <ul className="text-xs text-rose-800 bg-rose-50 border border-rose-100 rounded-2xl p-3.5 space-y-1.5 font-semibold">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Products Inventory</strong> → products = []</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Sales Invoices</strong> → sales = []</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Purchases / Expenses</strong> → expenses = []</span>
                </li>
              </ul>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsWipeConfirmOpen(false)}
                disabled={isWiping}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                id="btn-settings-modal-confirm-wipe"
                onClick={handleWipeAllData}
                disabled={isWiping}
                className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition cursor-pointer active:scale-95 disabled:opacity-50"
              >
                {isWiping ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Wiping Data...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Wipe All Data / Fresh Start</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsModal;
