import React, { useRef, useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { InvoiceTemplateType } from '../../types';
import { formatCurrency, formatNumber, numberToWordsIndian, calculateGstTaxBreakdown } from '../../utils/calculations';
import { 
  generateInvoiceTextSummary, 
  downloadInvoicePdf, 
  printInvoiceElement, 
  generateWhatsAppLink
} from '../../utils/invoiceGenerator';
import { 
  X, 
  Printer, 
  Download, 
  Share2, 
  Check, 
  ShieldCheck, 
  QrCode, 
  FileText,
  Layers,
  Send,
  Copy,
  Sparkles,
  CreditCard
} from 'lucide-react';

export const InvoiceModal: React.FC = () => {
  const { 
    activeInvoicePreview, 
    setActiveInvoicePreview, 
    shopProfile, 
    selectedTemplate, 
    language 
  } = useApp();

  const [activeTabTemplate, setActiveTabTemplate] = useState<InvoiceTemplateType>(selectedTemplate || 'navy');
  const [isCopied, setIsCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isSendingWhatsApp, setIsSendingWhatsApp] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  // Sync selected template from profile / settings when modal opens
  useEffect(() => {
    if (selectedTemplate) {
      setActiveTabTemplate(selectedTemplate);
    }
  }, [selectedTemplate]);

  const handleDirectPrint = React.useCallback(() => {
    const invoiceElement = document.getElementById('invoice-render-container') || document.getElementById('printable-invoice') || document.querySelector('.invoice-receipt-container');
    
    if (!invoiceElement) {
      window.print();
      return;
    }

    // Grab all active stylesheets, styles, and fonts from the parent application
    const stylesAndLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
      .map(el => el.outerHTML)
      .join('\n');

    const printWindow = window.open('', '_blank', 'width=850,height=1000');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>Invoice - Aman Gift Gallery</title>
            ${stylesAndLinks}
            <style>
              @page {
                size: auto;
                margin: 10mm;
              }
              body {
                background: #ffffff !important;
                color: #000000 !important;
                padding: 10px;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
              .no-print, button, nav, header, aside {
                display: none !important;
              }
            </style>
          </head>
          <body class="bg-white">
            <div class="print-wrapper">
              ${invoiceElement.innerHTML}
            </div>
            <script>
              window.onload = function() {
                setTimeout(() => {
                  window.focus();
                  window.print();
                  setTimeout(() => { window.close(); }, 700);
                }, 300);
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    } else {
      window.print();
    }
  }, []);

  // Keyboard shortcut Ctrl+P / Cmd+P to directly print invoice receipt
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        handleDirectPrint();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDirectPrint]);

  if (!activeInvoicePreview) return null;

  const invoice = activeInvoicePreview;
  const isTaxInvoice = !!invoice.isGstInvoice;
  const gstBreakdown = calculateGstTaxBreakdown(invoice.items, isTaxInvoice);
  const cgstLabel = gstBreakdown.slabs.length === 1 
    ? `CGST (@${gstBreakdown.slabs[0].cgstRate}%):` 
    : 'CGST:';
  const sgstLabel = gstBreakdown.slabs.length === 1 
    ? `SGST (@${gstBreakdown.slabs[0].sgstRate}%):` 
    : 'SGST:';

  const roundOffDiff = invoice.roundOff !== undefined 
    ? Number(invoice.roundOff) 
    : 0;
  const hasRoundOff = Math.abs(roundOffDiff) >= 0.01;
  const roundOffText = roundOffDiff > 0 ? `+₹${roundOffDiff.toFixed(2)}` : `-₹${Math.abs(roundOffDiff).toFixed(2)}`;

  const handleSendBillOnWhatsApp = () => {
    try {
      const waUrl = generateWhatsAppLink(invoice, shopProfile);
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch (err: any) {
      console.error('Send bill on WhatsApp failed:', err);
      alert(err.message || 'Failed to send bill on WhatsApp. Please check customer phone number.');
    }
  };

  const handleDownloadPdf = async () => {
    setIsDownloading(true);
    try {
      await downloadInvoicePdf(invoice, shopProfile, 'invoice-render-container');
    } catch (err) {
      console.error('PDF download error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyWhatsAppText = () => {
    const minItems = (invoice.items || []).map((i: any) => [
      i.name || i.productName || i.product?.name || 'Item',
      Number(i.quantity || i.qty || 1),
      Number(i.customPrice !== undefined ? i.customPrice : (i.product?.sellingPrice ?? i.price ?? i.rate ?? 0)),
      Number(i.product?.mrp || i.mrp || i.originalPrice || i.product?.sellingPrice || i.price || 0)
    ]);
    const compactPayload = {
      inv: invoice.invoiceNumber || invoice.id || `INV-${Date.now()}`,
      dt: invoice.date || new Date().toLocaleDateString('en-IN'),
      c: invoice.customerName?.trim() || 'Customer',
      it: minItems,
      tot: Number((invoice as any).grandTotal || (invoice as any).totalAmount || 0),
      gst: Number((invoice as any).taxAmount || invoice.totalGst || 0)
    };
    const encoded = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(compactPayload)))));
    const PUBLIC_BASE_URL = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-xukte2sfikvqyt5mtmrxur-180193938958.asia-southeast1.run.app';
    const receiptLink = `${PUBLIC_BASE_URL}/#/receipt?data=${encoded}`;

    const rawText = generateInvoiceTextSummary(receiptLink);
    navigator.clipboard.writeText(rawText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const paymentMethodDisplay = (invoice.paymentMethod || 'cash').toUpperCase();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto print:absolute print:inset-auto print:left-0 print:top-0 print:w-full print:h-auto print:overflow-visible print:bg-transparent print:p-0 print:block">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[96vh] flex flex-col text-slate-900 shadow-2xl overflow-hidden my-auto print:border-none print:shadow-none print:max-w-none print:max-h-none print:my-0 print:rounded-none print:block">
        {/* Top Header & Template Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 sm:px-6 py-3.5 border-b border-slate-200 bg-slate-50 print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-100 text-red-600 rounded-xl border border-red-200 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-base sm:text-lg text-slate-900">
                  {invoice.isGstInvoice 
                    ? (language === 'hi' ? 'टैक्स इनवॉइस व रसीद' : 'Tax Invoice & Receipt') 
                    : (language === 'hi' ? 'रिटेल इनवॉइस / कैश मेमो' : 'Retail Invoice / Cash Memo')}
                </h2>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full border border-emerald-200">
                  Paid ({paymentMethodDisplay})
                </span>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${
                  invoice.isGstInvoice
                    ? 'bg-indigo-100 text-indigo-800 border-indigo-200'
                    : 'bg-slate-100 text-slate-700 border-slate-200'
                }`}>
                  {invoice.isGstInvoice ? 'GST Tax Invoice' : 'Non-GST Retail Bill'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                #{invoice.invoiceNumber} • {invoice.date} {invoice.time}
              </p>
            </div>
          </div>

          {/* Template Switcher Buttons */}
          <div className="flex items-center bg-slate-200/70 p-1 rounded-xl gap-0.5">
            <button
              type="button"
              onClick={() => setActiveTabTemplate('navy')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                activeTabTemplate === 'navy'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Classic Navy
            </button>
            <button
              type="button"
              onClick={() => setActiveTabTemplate('minimal')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                activeTabTemplate === 'minimal'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Minimal Slate
            </button>
            <button
              type="button"
              onClick={() => setActiveTabTemplate('bold')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                activeTabTemplate === 'bold'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Retail Promo
            </button>
            <button
              type="button"
              onClick={() => setActiveTabTemplate('thermal')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                activeTabTemplate === 'thermal'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Thermal 3"
            </button>
          </div>

          <button
            type="button"
            onClick={() => setActiveInvoicePreview(null)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 transition cursor-pointer"
            title="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar (Print / WhatsApp / PDF / 1-Click Direct Share) */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 sm:px-6 py-3.5 bg-white border-b border-slate-200 shadow-xs print:hidden">
          {/* WhatsApp Direct Share Actions */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Prominent 1-Click WhatsApp Button */}
            <button
              type="button"
              id="btn-send-bill-whatsapp-modal"
              onClick={handleSendBillOnWhatsApp}
              disabled={isSendingWhatsApp}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] disabled:opacity-50 text-white text-xs sm:text-sm font-black rounded-xl shadow-md shadow-emerald-600/25 transition cursor-pointer"
              title="Generate PDF, upload to Firebase Storage & open WhatsApp (wa.me)"
            >
              <Send className="w-4 h-4 text-white" />
              <span>{isSendingWhatsApp ? 'Uploading & Opening WhatsApp...' : '📲 Send Bill on WhatsApp'}</span>
            </button>

            {/* Copy Text Summary */}
            <button
              type="button"
              id="btn-copy-whatsapp-text"
              onClick={handleCopyWhatsAppText}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
              title="Copy formatted text bill to clipboard"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
              <span>{isCopied ? (language === 'hi' ? 'कॉपी हो गया' : 'Copied!') : (language === 'hi' ? 'टेक्स्ट कॉपी' : 'Copy Text')}</span>
            </button>
          </div>

          {/* Download & Print Actions */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-save-pdf-modal"
              onClick={handleDownloadPdf}
              disabled={isDownloading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer shadow-xs"
            >
              <Download className="w-3.5 h-3.5 text-indigo-600" />
              <span>{isDownloading ? 'Generating PDF...' : 'Download PDF'}</span>
            </button>

            <button
              type="button"
              id="btn-print-receipt-modal"
              onClick={handleDirectPrint}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-black active:scale-[0.98] text-white text-xs font-black rounded-xl shadow-md shadow-slate-900/20 transition cursor-pointer"
            >
              <span>🖨️ {language === 'hi' ? 'प्रिंट रसीद (Ctrl+P)' : 'Print Invoice (Ctrl+P)'}</span>
            </button>
          </div>
        </div>

        {/* Scrollable Printable Invoice Content Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-100 flex justify-center print:overflow-visible print:bg-white print:p-0 print:block">
          <div 
            id="invoice-render-container" 
            ref={printRef}
            className={`w-full bg-white text-slate-900 shadow-xl print:shadow-none print:m-0 print:border-none print:max-w-none ${
              activeTabTemplate === 'thermal' 
                ? 'max-w-[80mm] p-4 text-[11px] font-mono leading-tight border border-slate-200 rounded-md' 
                : 'max-w-3xl p-6 sm:p-8 rounded-xl border border-slate-200'
            }`}
          >
            {/* 1. THERMAL 3-INCH RECEIPT TEMPLATE (80MM ROLL) */}
            {activeTabTemplate === 'thermal' && (
              <div className="space-y-2.5 text-center">
                <div className="border-b border-dashed border-slate-400 pb-2">
                  {shopProfile.logoUrl && (
                    <img 
                      src={shopProfile.logoUrl} 
                      alt={shopProfile.name} 
                      className="h-10 w-auto max-w-[120px] mx-auto object-contain mb-1.5 grayscale contrast-125"
                    />
                  )}
                  <h1 className="font-extrabold text-base uppercase tracking-tight">{shopProfile.name}</h1>
                  {shopProfile.tagline && <p className="text-[10px] text-slate-600">{shopProfile.tagline}</p>}
                  <p className="text-[9px] text-slate-600">{shopProfile.address}, {shopProfile.city}</p>
                  <p className="text-[9px] text-slate-600">Ph: {shopProfile.phone} {shopProfile.altPhone ? `| ${shopProfile.altPhone}` : ''}</p>
                  {invoice.isGstInvoice && shopProfile.gstin && <p className="text-[9px] font-bold text-slate-800">GSTIN: {shopProfile.gstin}</p>}
                </div>

                <div className="font-bold text-[10px] uppercase border-b border-dashed border-slate-400 py-0.5 text-slate-800">
                  {invoice.isGstInvoice ? 'TAX INVOICE' : 'RETAIL INVOICE / CASH MEMO'}
                </div>

                <div className="text-left text-[9px] border-b border-dashed border-slate-400 py-1.5 space-y-0.5">
                  <div className="flex justify-between font-bold">
                    <span>Bill No: {invoice.invoiceNumber}</span>
                    <span>{invoice.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cust: {invoice.customerName || 'Cash Customer'}</span>
                    <span>{invoice.time}</span>
                  </div>
                  {invoice.customerPhone && <p>Ph: {invoice.customerPhone}</p>}
                  {invoice.isGstInvoice && invoice.customerGstin && <p className="font-bold">Cust GSTIN: {invoice.customerGstin}</p>}
                  <div className="flex justify-between text-slate-700">
                    <span>Payment: <b className="uppercase">{invoice.paymentMethod || 'CASH'}</b></span>
                    {invoice.isExchangeBill && <span className="font-bold text-red-600">[EXCHANGE]</span>}
                  </div>
                </div>

                {/* Items List */}
                <table className="w-full text-left text-[9px] border-b border-dashed border-slate-400 my-1">
                  <thead>
                    <tr className="border-b border-slate-300">
                      <th className="py-1">Item</th>
                      <th className="py-1 text-center">Qty</th>
                      <th className="py-1 text-right">Rate</th>
                      <th className="py-1 text-right">Amt</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoice.items.map((it, idx) => {
                      const isReturn = it.quantity < 0 || it.isExchangeReturn;
                      const price = it.customPrice !== undefined ? it.customPrice : it.product.sellingPrice;
                      const netAmt = price * it.quantity;
                      return (
                        <tr key={idx} className="border-b border-slate-100">
                          <td className="py-1 pr-1 font-medium">
                            {isReturn && <span className="font-bold text-red-600">[RET] </span>}
                            {it.product.name}
                            {it.warranty?.enabled && it.warranty.duration && it.warranty.duration !== 'No Warranty' && (
                              <div className="text-[8px] text-blue-700 font-bold">🛡️ Warranty: {it.warranty.duration}</div>
                            )}
                          </td>
                          <td className="py-1 text-center font-bold">{Math.abs(it.quantity)}</td>
                          <td className="py-1 text-right">
                            <div className="font-bold text-slate-900">₹{price.toFixed(0)}</div>
                            {invoice.showDiscount !== false && it.product.mrp && it.product.mrp > price && (
                              <div className="text-[7.5px] font-bold text-slate-600">MRP ₹{it.product.mrp}</div>
                            )}
                          </td>
                          <td className={`py-1 text-right font-bold ${isReturn ? 'text-red-600' : ''}`}>
                            {isReturn ? '-' : ''}₹{Math.abs(netAmt).toFixed(0)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Totals */}
                <div className="text-right text-[10px] space-y-0.5 pt-1">
                  <div className="flex justify-between text-slate-700">
                    <span>{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Item(s) Subtotal (amount before tax):' : 'Items Subtotal:'}</span>
                    <span className="font-semibold">₹{(invoice.isGstInvoice && invoice.totalGst > 0 ? (invoice.grandTotal - invoice.totalGst) : invoice.subtotal).toFixed(2)}</span>
                  </div>
                  {invoice.showDiscount !== false && invoice.totalDiscount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span>Total Savings:</span>
                      <span>-₹{invoice.totalDiscount.toFixed(2)}</span>
                    </div>
                  )}
                  {invoice.isGstInvoice && gstBreakdown.totalTax > 0 && (
                    <>
                      <div className="flex justify-between text-slate-600 text-[9px]">
                        <span>{cgstLabel}</span>
                        <span>₹{gstBreakdown.totalCgst.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600 text-[9px]">
                        <span>{sgstLabel}</span>
                        <span>₹{gstBreakdown.totalSgst.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                  {hasRoundOff && (
                    <div className="flex justify-between text-slate-500 text-[9px]">
                      <span>Round Off:</span>
                      <span>{roundOffText}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-extrabold text-xs border-t border-b border-slate-900 py-1 mt-1">
                    <span>{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Grand Total (after tax):' : 'Grand Total:'}</span>
                    <span>₹{invoice.grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                <div className="text-[8px] text-slate-500 pt-2 border-t border-dashed border-slate-400 space-y-1">
                  {shopProfile.signatureUrl && (
                    <div className="pt-1 pb-0.5">
                      <img 
                        src={shopProfile.signatureUrl} 
                        alt="Signature" 
                        className="h-7 w-auto max-w-[90px] mx-auto object-contain"
                      />
                      <p className="text-[7px] text-slate-600 font-bold">Authorized Signatory</p>
                    </div>
                  )}
                  <p>{shopProfile.footerDisclaimer || 'Thank you for shopping with us!'}</p>
                  <p className="font-bold uppercase tracking-wider text-[9px]">*** Thank You, Visit Again! ***</p>
                </div>
              </div>
            )}

            {/* 2. A4 / A5 TEMPLATE 1: MODERN ENTERPRISE (HIGH CONTRAST) */}
            {activeTabTemplate === 'navy' && (
              <div className="space-y-5 font-sans">
                {/* Top Accent Line */}
                <div className="h-1 bg-slate-800 rounded-full w-full" />

                {/* Store Header & Tax Invoice Badge */}
                <div className="flex flex-col sm:flex-row justify-between items-start border-b border-slate-200 pb-4 gap-4">
                  <div className="flex items-start gap-3.5">
                    {shopProfile.logoUrl && (
                      <div className="w-14 h-14 rounded-xl bg-white border border-slate-200 p-1 flex items-center justify-center shadow-2xs shrink-0 mt-0.5">
                        <img 
                          src={shopProfile.logoUrl} 
                          alt={shopProfile.name} 
                          className="w-full h-full object-contain"
                        />
                      </div>
                    )}
                    <div className="space-y-0.5">
                      <h1 className="text-2xl font-black text-slate-900 tracking-tight uppercase">{shopProfile.name}</h1>
                      {shopProfile.tagline && <p className="text-xs font-semibold text-slate-600">{shopProfile.tagline}</p>}
                      <p className="text-xs text-slate-600 max-w-md">{shopProfile.address}, {shopProfile.city}, {shopProfile.state} - {shopProfile.pincode}</p>
                      <p className="text-xs text-slate-600">
                        Ph: <span className="font-bold text-slate-800">{shopProfile.phone}</span> {shopProfile.altPhone ? `/ ${shopProfile.altPhone}` : ''}
                        {invoice.isGstInvoice && shopProfile.gstin && (
                          <span className="ml-2 font-bold text-slate-900">|  GSTIN: {shopProfile.gstin}</span>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Clean Tax / Retail Invoice Badge */}
                  <div className="border border-slate-300 rounded-xl overflow-hidden shadow-2xs shrink-0 min-w-[170px] text-center bg-slate-50">
                    <div className="bg-slate-800 text-white font-extrabold text-[11px] uppercase tracking-wider py-1 px-3">
                      {invoice.isGstInvoice ? 'TAX INVOICE' : 'RETAIL INVOICE'}
                    </div>
                    <div className="p-2">
                      <p className="font-mono font-black text-slate-900 text-xs sm:text-sm">#{invoice.invoiceNumber}</p>
                    </div>
                  </div>
                </div>

                {/* Customer Details & Invoice Metadata Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Left: Customer Details */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-1">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">BILLED TO (CUSTOMER)</p>
                    <p className="font-bold text-slate-900 text-sm">{invoice.customerName || 'Walk-in Retail Customer'}</p>
                    <p className="text-slate-600 font-medium">
                      Phone: <span className="font-mono font-bold text-slate-800">{invoice.customerPhone || 'Not Provided'}</span>
                    </p>
                    {invoice.isGstInvoice && invoice.customerGstin && (
                      <p className="text-slate-700 font-bold">
                        Customer GSTIN: <span className="font-mono text-indigo-700">{invoice.customerGstin}</span>
                      </p>
                    )}
                    <p className="text-slate-500 text-[11px]">
                      Customer Type: {invoice.isGstInvoice ? 'Tax Invoice B2B/B2C' : 'Retail / Cash Memo'}
                    </p>
                  </div>

                  {/* Right: Invoice & Receipt Details */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs space-y-1.5">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">INVOICE & RECEIPT DETAILS</p>
                    <div className="flex justify-between items-center text-slate-600">
                      <span className="font-medium">Date & Time:</span>
                      <span className="font-bold text-slate-900">{invoice.date} {invoice.time}</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-600">
                      <span className="font-medium">Payment Mode:</span>
                      <span className="font-extrabold uppercase text-slate-900">{paymentMethodDisplay}</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-600">
                      <span className="font-medium">Status:</span>
                      <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
                        PAID ({paymentMethodDisplay.toUpperCase()})
                      </span>
                    </div>
                  </div>
                </div>

                {/* Items Table */}
                <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-300 text-slate-800 uppercase text-[10px] font-extrabold tracking-wider">
                          <th className="py-2.5 px-3">#</th>
                          <th className="py-2.5 px-3">Item Description</th>
                          {invoice.isGstInvoice && <th className="py-2.5 px-3">HSN</th>}
                          <th className="py-2.5 px-3 text-center">Qty</th>
                          {invoice.showDiscount !== false && (
                            <>
                              <th className="py-2.5 px-3 text-right">MRP</th>
                              <th className="py-2.5 px-3 text-right">Disc.</th>
                            </>
                          )}
                          <th className="py-2.5 px-3 text-right">Rate</th>
                          {invoice.isGstInvoice && <th className="py-2.5 px-3 text-right">GST%</th>}
                          <th className="py-2.5 px-3 text-right">Total (₹)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-slate-800 bg-white">
                        {invoice.items.map((it, idx) => {
                          const isReturn = it.quantity < 0 || it.isExchangeReturn;
                          const price = it.customPrice !== undefined ? it.customPrice : it.product.sellingPrice;
                          const total = price * it.quantity;
                          const isEven = idx % 2 === 0;

                          return (
                            <tr key={idx} className={`hover:bg-slate-50 transition ${!isEven ? 'bg-slate-50/50' : ''} ${isReturn ? 'bg-rose-50/80 text-rose-900 font-medium' : ''}`}>
                              <td className="py-2.5 px-3 font-mono text-slate-500 font-bold">{idx + 1}</td>
                              <td className="py-2.5 px-3">
                                <div className="font-bold text-slate-900">
                                  {isReturn && <span className="text-xs font-extrabold text-rose-600 mr-1">🔄 [RETURN]</span>}
                                  {it.product.name}
                                </div>
                                <div className="text-[10px] text-slate-500">
                                  Brand: <span className="font-semibold text-slate-700">{it.product.brand}</span> • Cat: {it.product.category}
                                </div>
                                {it.warranty?.enabled && it.warranty.duration && it.warranty.duration !== 'No Warranty' && (
                                  <div className="inline-flex items-center gap-1 mt-0.5 px-2 py-0.5 bg-blue-50 border border-blue-200 text-blue-800 text-[10px] font-bold rounded-md">
                                    <ShieldCheck className="w-3 h-3 text-blue-600" />
                                    Warranty: {it.warranty.duration}
                                  </div>
                                )}
                              </td>
                              {invoice.isGstInvoice && <td className="py-2.5 px-3 text-slate-500 font-mono">{it.product.hsn || '-'}</td>}
                              <td className="py-2.5 px-3 text-center font-bold text-slate-900">{Math.abs(it.quantity)}</td>
                              {invoice.showDiscount !== false && (
                                <>
                                  <td className="py-2.5 px-3 text-right font-bold text-slate-700">₹{it.product.mrp || price}</td>
                                  <td className="py-2.5 px-3 text-right font-bold text-emerald-600">
                                    {it.product.mrp && it.product.mrp > price ? Math.round(((it.product.mrp - price) / it.product.mrp) * 100) + '%' : '-'}
                                  </td>
                                </>
                              )}
                              <td className="py-2.5 px-3 text-right font-black text-slate-900">₹{price}</td>
                              {invoice.isGstInvoice && <td className="py-2.5 px-3 text-right text-slate-600">{it.product.gstPercent}%</td>}
                              <td className={`py-2.5 px-3 text-right font-black ${isReturn ? 'text-rose-600' : 'text-slate-900'}`}>
                                {isReturn ? '-' : ''}₹{Math.abs(total).toFixed(2)}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Calculation & Signatures */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div className="space-y-3">
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1">
                      <p className="font-bold text-slate-800 uppercase text-[10px] tracking-wider">Amount in Words:</p>
                      <p className="text-slate-700 italic font-semibold">{numberToWordsIndian(invoice.grandTotal)}</p>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-[11px] text-slate-600 space-y-1">
                      <p className="font-bold text-slate-800">Terms & Conditions:</p>
                      <p className="leading-relaxed">{shopProfile.footerDisclaimer || 'Subject to Ranchi Jurisdiction. Goods once sold cannot be returned without original invoice.'}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="bg-slate-50/80 border border-slate-200 rounded-xl p-3.5 text-xs space-y-1.5">
                      <div className="flex justify-between text-slate-600">
                        <span className="font-medium">{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Item(s) Subtotal (amount before tax):' : 'Items Subtotal:'}</span>
                        <span className="font-bold text-slate-900">₹{(invoice.isGstInvoice && invoice.totalGst > 0 ? (invoice.grandTotal - invoice.totalGst) : invoice.subtotal).toFixed(2)}</span>
                      </div>
                      {invoice.showDiscount !== false && invoice.totalDiscount > 0 && (
                        <div className="flex justify-between text-emerald-700 font-medium">
                          <span>Special Savings / Discount:</span>
                          <span>-₹{invoice.totalDiscount.toFixed(2)}</span>
                        </div>
                      )}
                      {invoice.isGstInvoice && gstBreakdown.totalTax > 0 && (
                        <>
                          <div className="flex justify-between text-slate-600">
                            <span className="font-medium">{cgstLabel}</span>
                            <span className="font-semibold text-slate-800">₹{gstBreakdown.totalCgst.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-slate-600">
                            <span className="font-medium">{sgstLabel}</span>
                            <span className="font-semibold text-slate-800">₹{gstBreakdown.totalSgst.toFixed(2)}</span>
                          </div>
                        </>
                      )}
                      {hasRoundOff && (
                        <div className="flex justify-between text-slate-500 text-xs">
                          <span>Round Off:</span>
                          <span className="font-medium text-slate-700">{roundOffText}</span>
                        </div>
                      )}
                      
                      {/* Clean Light Grand Total Row */}
                      <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
                        <span className="font-bold text-sm text-slate-900 uppercase tracking-tight">{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Grand Total (after tax):' : 'Grand Total:'}</span>
                        <span className="text-xl font-black text-slate-950">₹{invoice.grandTotal.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Stamp & Authorized Signature */}
                    <div className="border border-slate-200 rounded-xl p-3 flex justify-between items-end bg-white">
                      <div className="text-center text-[10px] text-slate-500">
                        <div className="w-12 h-12 border border-slate-200 rounded-lg flex items-center justify-center bg-slate-50 mb-1 mx-auto">
                          <QrCode className="w-7 h-7 text-slate-700" />
                        </div>
                        <span className="font-medium">Scan & Pay UPI</span>
                      </div>

                      <div className="text-right">
                        {shopProfile.signatureUrl ? (
                          <img 
                            src={shopProfile.signatureUrl} 
                            alt="Signature" 
                            className="h-10 w-auto max-w-[130px] ml-auto object-contain"
                          />
                        ) : (
                          <div className="h-8 flex items-center justify-end text-xs italic text-slate-400">
                            (Digital Stamp Registered)
                          </div>
                        )}
                        <p className="font-bold text-xs text-slate-900 mt-1">For {shopProfile.name}</p>
                        <p className="text-[10px] text-slate-500">Authorized Signatory</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. A4 TEMPLATE 2: MINIMAL GRAY CORPORATE */}
            {activeTabTemplate === 'minimal' && (
              <div className="space-y-6 font-sans">
                <div className="flex justify-between items-start border-b border-slate-300 pb-4 gap-4">
                  <div className="flex items-start gap-3">
                    {shopProfile.logoUrl && (
                      <div className="w-14 h-14 bg-white border border-slate-200 rounded-lg p-1 shrink-0 flex items-center justify-center">
                        <img 
                          src={shopProfile.logoUrl} 
                          alt={shopProfile.name} 
                          className="w-full h-full object-contain"
                        />
                      </div>
                    )}
                    <div>
                      <h1 className="text-xl font-bold text-slate-900 uppercase tracking-wider">{shopProfile.name}</h1>
                      {shopProfile.tagline && <p className="text-xs text-slate-500">{shopProfile.tagline}</p>}
                      <p className="text-xs text-slate-600 mt-1">{shopProfile.address}, {shopProfile.city}</p>
                      <p className="text-xs text-slate-600">
                        Ph: {shopProfile.phone} {invoice.isGstInvoice && shopProfile.gstin ? `| GSTIN: ${shopProfile.gstin}` : ''}
                      </p>
                    </div>
                  </div>
                  <div className="text-right text-xs space-y-0.5">
                    <p className="font-mono text-sm font-bold text-slate-900">
                      {invoice.isGstInvoice ? 'TAX INVOICE' : 'RETAIL INVOICE'}
                    </p>
                    <p className="text-slate-600 font-mono">#{invoice.invoiceNumber}</p>
                    <p className="text-slate-500">{invoice.date} {invoice.time}</p>
                    <p className="font-bold uppercase text-slate-800">Mode: {paymentMethodDisplay}</p>
                  </div>
                </div>

                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs flex justify-between">
                  <span>Customer: <b>{invoice.customerName || 'Walk-in Customer'}</b></span>
                  <div className="flex items-center gap-3">
                    {invoice.isGstInvoice && invoice.customerGstin && <span>GSTIN: <b className="font-mono">{invoice.customerGstin}</b></span>}
                    {invoice.customerPhone && <span>Phone: <b>{invoice.customerPhone}</b></span>}
                  </div>
                </div>

                <table className="w-full text-xs text-left border-t border-b border-slate-200">
                  <thead>
                    <tr className="border-b border-slate-300 text-slate-600 uppercase text-[10px]">
                      <th className="py-2 px-2">Description</th>
                      {invoice.isGstInvoice && <th className="py-2 px-2">HSN</th>}
                      <th className="py-2 px-2 text-center">Qty</th>
                      <th className="py-2 px-2 text-right">Unit Price</th>
                      {invoice.isGstInvoice && <th className="py-2 px-2 text-right">GST%</th>}
                      <th className="py-2 px-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {invoice.items.map((it, idx) => {
                      const price = it.customPrice !== undefined ? it.customPrice : it.product.sellingPrice;
                      return (
                        <tr key={idx}>
                          <td className="py-2 px-2">
                            <div className="font-semibold text-slate-900">{it.product.name}</div>
                            {it.warranty?.enabled && it.warranty.duration && it.warranty.duration !== 'No Warranty' && (
                              <div className="text-[10px] text-blue-700 font-semibold">🛡️ Warranty: {it.warranty.duration}</div>
                            )}
                          </td>
                          {invoice.isGstInvoice && <td className="py-2 px-2 font-mono text-slate-500">{it.product.hsn || '-'}</td>}
                          <td className="py-2 px-2 text-center font-bold">{Math.abs(it.quantity)}</td>
                          <td className="py-2 px-2 text-right">
                            <div className="font-bold text-slate-900">₹{price.toFixed(2)}</div>
                            {invoice.showDiscount !== false && it.product.mrp && it.product.mrp > price && (
                              <div className="text-[10px] font-bold text-slate-600">MRP: ₹{it.product.mrp}</div>
                            )}
                          </td>
                          {invoice.isGstInvoice && <td className="py-2 px-2 text-right text-slate-600">{it.product.gstPercent}%</td>}
                          <td className="py-2 px-2 text-right font-bold text-slate-900">₹{(price * it.quantity).toFixed(2)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                <div className="flex flex-col sm:flex-row justify-between items-start pt-2 gap-6">
                  <div className="max-w-xs text-[11px] text-slate-500 space-y-3">
                    <div>
                      <p className="font-bold text-slate-700">Notes & Disclaimer:</p>
                      <p>{shopProfile.footerDisclaimer || 'Thank you for your business!'}</p>
                    </div>
                  </div>

                  <div className="w-full sm:w-72 text-xs space-y-3">
                    <div className="space-y-1 bg-slate-50/60 p-3 rounded-lg border border-slate-200/70">
                      <div className="flex justify-between text-slate-600">
                        <span>{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Item(s) Subtotal (amount before tax):' : 'Items Subtotal:'}</span>
                        <span className="font-semibold text-slate-900">₹{(invoice.isGstInvoice && invoice.totalGst > 0 ? (invoice.grandTotal - invoice.totalGst) : invoice.subtotal).toFixed(2)}</span>
                      </div>
                      {invoice.showDiscount !== false && invoice.totalDiscount > 0 && (
                        <div className="flex justify-between text-slate-600">
                          <span>Discount:</span>
                          <span>-₹{invoice.totalDiscount.toFixed(2)}</span>
                        </div>
                      )}
                      {invoice.isGstInvoice && gstBreakdown.totalTax > 0 && (
                        <>
                          <div className="flex justify-between text-slate-600">
                            <span>{cgstLabel}</span>
                            <span className="font-semibold text-slate-800">₹{gstBreakdown.totalCgst.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-slate-600">
                            <span>{sgstLabel}</span>
                            <span className="font-semibold text-slate-800">₹{gstBreakdown.totalSgst.toFixed(2)}</span>
                          </div>
                        </>
                      )}
                      {hasRoundOff && (
                        <div className="flex justify-between text-slate-500 text-xs">
                          <span>Round Off:</span>
                          <span className="font-medium text-slate-700">{roundOffText}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-black text-sm text-slate-900 border-t border-slate-300 pt-1.5 mt-1.5">
                        <span>{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Grand Total (after tax):' : 'Grand Total:'}</span>
                        <span>₹{invoice.grandTotal.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Signature block */}
                    <div className="pt-2 border-t border-slate-200 text-right">
                      {shopProfile.signatureUrl ? (
                        <img 
                          src={shopProfile.signatureUrl} 
                          alt="Signature" 
                          className="h-10 w-auto max-w-[120px] ml-auto object-contain"
                        />
                      ) : (
                        <div className="h-8 flex items-center justify-end text-[10px] italic text-slate-400">
                          (Authorized Signatory)
                        </div>
                      )}
                      <p className="font-bold text-[11px] text-slate-800 mt-1">For {shopProfile.name}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. A4 TEMPLATE 3: RETAIL BOLD PROMO */}
            {activeTabTemplate === 'bold' && (
              <div className="space-y-6">
                <div className="bg-emerald-700 text-white p-5 rounded-xl flex justify-between items-center gap-4">
                  <div className="flex items-center gap-3.5">
                    {shopProfile.logoUrl && (
                      <div className="w-14 h-14 bg-white rounded-xl p-1 shrink-0 flex items-center justify-center">
                        <img 
                          src={shopProfile.logoUrl} 
                          alt={shopProfile.name} 
                          className="w-full h-full object-contain"
                        />
                      </div>
                    )}
                    <div>
                      <h1 className="text-2xl font-black tracking-tight">{shopProfile.name}</h1>
                      {shopProfile.tagline && <p className="text-xs text-emerald-100">{shopProfile.tagline}</p>}
                      <p className="text-[11px] text-emerald-200">{shopProfile.address}, {shopProfile.city} • Ph: {shopProfile.phone}</p>
                    </div>
                  </div>
                  <div className="bg-white text-emerald-950 p-3 rounded-lg text-right text-xs shadow-md shrink-0">
                    <p className="font-black text-sm">₹{invoice.grandTotal.toFixed(2)}</p>
                    <p className="font-mono text-[10px] text-slate-600">#{invoice.invoiceNumber}</p>
                    <span className="text-[9px] font-bold uppercase bg-emerald-100 text-emerald-900 px-1.5 py-0.5 rounded-sm">
                      {paymentMethodDisplay}
                    </span>
                  </div>
                </div>

                {invoice.showDiscount !== false && invoice.totalDiscount > 0 && (
                  <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 font-bold text-xs p-3 rounded-xl flex items-center justify-between">
                    <span>🎉 TOTAL SAVINGS ON THIS BILL:</span>
                    <span className="text-base text-emerald-700 font-black">₹{invoice.totalDiscount.toFixed(2)}</span>
                  </div>
                )}

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs flex justify-between items-center">
                  <span>Customer: <b className="text-slate-900">{invoice.customerName || 'Valued Customer'}</b></span>
                  {invoice.customerPhone && <span className="font-mono">Phone: <b>{invoice.customerPhone}</b></span>}
                </div>

                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 uppercase font-bold text-[10px]">
                      <th className="py-2.5 px-3">Item Details</th>
                      {invoice.isGstInvoice && <th className="py-2.5 px-3">HSN</th>}
                      <th className="py-2.5 px-3 text-center">Qty</th>
                      {invoice.showDiscount !== false && (
                        <th className="py-2.5 px-3 text-right">MRP</th>
                      )}
                      <th className="py-2.5 px-3 text-right">Offer Price</th>
                      {invoice.isGstInvoice && <th className="py-2.5 px-3 text-right">GST%</th>}
                      <th className="py-2.5 px-3 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {invoice.items.map((it, idx) => {
                      const price = it.customPrice !== undefined ? it.customPrice : it.product.sellingPrice;
                      return (
                        <tr key={idx}>
                          <td className="py-2.5 px-3 font-bold text-slate-900">
                            {it.product.name}
                            {it.warranty?.enabled && it.warranty.duration && it.warranty.duration !== 'No Warranty' && (
                              <div className="text-[10px] text-emerald-700 font-semibold">★ {it.warranty.duration} Warranty Covered</div>
                            )}
                          </td>
                          {invoice.isGstInvoice && <td className="py-2.5 px-3 font-mono text-slate-500">{it.product.hsn || '-'}</td>}
                          <td className="py-2.5 px-3 text-center font-bold">{Math.abs(it.quantity)}</td>
                          {invoice.showDiscount !== false && (
                            <td className="py-2.5 px-3 text-right font-bold text-slate-700">₹{it.product.mrp || price}</td>
                          )}
                          <td className="py-2.5 px-3 text-right font-black text-emerald-700">₹{price}</td>
                          {invoice.isGstInvoice && <td className="py-2.5 px-3 text-right text-slate-600">{it.product.gstPercent}%</td>}
                          <td className="py-2.5 px-3 text-right font-black text-slate-900">₹{(price * it.quantity).toFixed(2)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                <div className="flex flex-col sm:flex-row justify-between items-end border-t border-slate-200 pt-4 gap-4">
                  <div className="text-[10px] text-slate-500 max-w-sm">
                    <p className="font-bold text-slate-700">Store Policy:</p>
                    <p>{shopProfile.footerDisclaimer || 'Quality Assured. Visit Again!'}</p>
                  </div>
                  <div className="text-right space-y-2 min-w-[220px]">
                    <div className="space-y-1.5 text-xs bg-slate-50/80 p-3 rounded-xl border border-slate-200/80">
                      <div className="flex justify-between text-slate-600">
                        <span>{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Item(s) Subtotal (amount before tax):' : 'Items Subtotal:'}</span>
                        <span className="font-semibold text-slate-900">₹{(invoice.isGstInvoice && invoice.totalGst > 0 ? (invoice.grandTotal - invoice.totalGst) : invoice.subtotal).toFixed(2)}</span>
                      </div>
                      {invoice.showDiscount !== false && invoice.totalDiscount > 0 && (
                        <div className="flex justify-between text-emerald-700 font-semibold">
                          <span>Savings:</span>
                          <span>-₹{invoice.totalDiscount.toFixed(2)}</span>
                        </div>
                      )}
                      {invoice.isGstInvoice && gstBreakdown.totalTax > 0 && (
                        <>
                          <div className="flex justify-between text-slate-600">
                            <span>{cgstLabel}</span>
                            <span className="font-semibold text-slate-800">₹{gstBreakdown.totalCgst.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-slate-600">
                            <span>{sgstLabel}</span>
                            <span className="font-semibold text-slate-800">₹{gstBreakdown.totalSgst.toFixed(2)}</span>
                          </div>
                        </>
                      )}
                      {hasRoundOff && (
                        <div className="flex justify-between text-slate-500 text-xs">
                          <span>Round Off:</span>
                          <span className="font-medium text-slate-700">{roundOffText}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-baseline pt-2 border-t border-slate-200">
                        <span className="font-bold text-xs text-slate-800 uppercase">{invoice.isGstInvoice && gstBreakdown.totalTax > 0 ? 'Grand Total (after tax):' : 'Grand Total:'}</span>
                        <span className="text-lg font-black text-slate-950">₹{invoice.grandTotal.toFixed(2)}</span>
                      </div>
                    </div>
                    {shopProfile.signatureUrl && (
                      <div className="pt-1">
                        <img 
                          src={shopProfile.signatureUrl} 
                          alt="Signature" 
                          className="h-10 w-auto max-w-[120px] ml-auto object-contain"
                        />
                        <p className="text-[10px] text-slate-600 font-bold">For {shopProfile.name}</p>
                        <p className="text-[9px] text-slate-400">Authorized Signatory</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
