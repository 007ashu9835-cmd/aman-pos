import React, { useState } from 'react';
import { 
  Award, 
  X, 
  Package, 
  TrendingUp, 
  IndianRupee, 
  Layers, 
  ShoppingBag, 
  Flame, 
  Snowflake, 
  Tag, 
  AlertTriangle,
  Clock,
  ArrowDownRight,
  CheckCircle2,
  Percent,
  FileText,
  Share2,
  Download,
  Loader2,
  Truck
} from 'lucide-react';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { Language, Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { generateBrandPurchaseOrderPdf, sharePurchaseOrderPdf, POItem } from '../../utils/purchaseOrderPdf';

export interface BrandModelItem {
  id?: number;
  name: string;
  barcode?: string;
  stock: number;
  price: number;
  mrp?: number;
  costPrice?: number;
  soldQty: number;
  revenue: number;
  profit: number;
  daysSinceInward?: number;
  lastSoldDate?: string;
}

export interface BrandPerformanceData {
  brand: string;
  totalProducts: number;
  totalStockUnits: number;
  inventoryValuation: number;
  estimatedRevenue: number;
  totalUnitsSold: number;
  totalSalesValue: number;
  totalProfitContribution: number;
  topModels: BrandModelItem[];
}

interface BrandDrilldownModalProps {
  brandData: BrandPerformanceData | null;
  onClose: () => void;
  language: Language;
}

export const BrandDrilldownModal: React.FC<BrandDrilldownModalProps> = ({
  brandData,
  onClose,
  language
}) => {
  const { updateProduct, playBeep, shopProfile } = useApp();
  const [activeTab, setActiveTab] = useState<'top' | 'dead' | 'reorder'>('top');
  const [discountModalItem, setDiscountModalItem] = useState<BrandModelItem | null>(null);
  const [discountPercent, setDiscountPercent] = useState<number>(15);
  const [discountSuccessMsg, setDiscountSuccessMsg] = useState<string | null>(null);

  // Brand PO state
  const [reorderQtyMap, setReorderQtyMap] = useState<Record<number, number>>({});
  const [isSharingPo, setIsSharingPo] = useState(false);
  const [isDownloadingPo, setIsDownloadingPo] = useState(false);
  const [poNotice, setPoNotice] = useState<string | null>(null);

  if (!brandData) return null;

  // 1. Top Selling Models (sorted by highest units sold, then revenue, then profit)
  const topSellingModels = [...brandData.topModels].sort((a, b) => {
    if (b.soldQty !== a.soldQty) {
      return b.soldQty - a.soldQty;
    }
    return b.revenue - a.revenue;
  });

  // 2. Zero Sales / Non-Moving (Dead SKUs)
  const deadStockModels = [...brandData.topModels]
    .filter(m => m.soldQty === 0 && m.stock > 0)
    .sort((a, b) => {
      const blockedA = (a.costPrice || a.price) * a.stock;
      const blockedB = (b.costPrice || b.price) * b.stock;
      return blockedB - blockedA;
    });

  // 3. Low stock / Reorder items for this brand (stock <= 3 or zero)
  const lowStockBrandModels = brandData.topModels.filter(m => m.stock <= 3);
  const reorderModelsList = lowStockBrandModels.length > 0 ? lowStockBrandModels : brandData.topModels;

  const getItemReorderQty = (model: BrandModelItem): number => {
    if (model.id && reorderQtyMap[model.id] !== undefined) {
      return reorderQtyMap[model.id];
    }
    return 12; // Standard default 1 dozen
  };

  const updateItemReorderQty = (id: number, qty: number) => {
    setReorderQtyMap(prev => ({
      ...prev,
      [id]: Math.max(1, qty)
    }));
  };

  const getPoItems = (): POItem[] => {
    return reorderModelsList.map(m => {
      const prodStub: Product = {
        id: m.id || 0,
        name: m.name,
        barcode: m.barcode || '',
        category: 'Kitchenware',
        brand: brandData.brand,
        hsn: '3924',
        gstPercent: 18,
        basicPurchaseRate: m.costPrice || Math.round(m.price * 0.7),
        landingCost: m.costPrice || Math.round(m.price * 0.7),
        mrp: m.mrp || m.price,
        sellingPrice: m.price,
        stockQty: m.stock,
        minThreshold: 3,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      return {
        product: prodStub,
        reorderQty: getItemReorderQty(m)
      };
    });
  };

  const handleShareBrandPoPdf = async () => {
    try {
      setIsSharingPo(true);
      const items = getPoItems();
      const result = await sharePurchaseOrderPdf({
        brandName: brandData.brand,
        items,
        shopProfile
      });

      playBeep('success');
      setPoNotice(
        language === 'hi'
          ? `${brandData.brand} का पर्चेस आर्डर PDF (${result.poNumber}) तैयार है!`
          : `Purchase Order PDF (${result.poNumber}) generated for ${brandData.brand} supplier!`
      );
      setTimeout(() => setPoNotice(null), 3500);
    } catch (err) {
      console.error('Failed to share brand PO:', err);
    } finally {
      setIsSharingPo(false);
    }
  };

  const handleDownloadBrandPoPdf = () => {
    try {
      setIsDownloadingPo(true);
      const items = getPoItems();
      const { doc, fileName, poNumber } = generateBrandPurchaseOrderPdf({
        brandName: brandData.brand,
        items,
        shopProfile
      });

      doc.save(fileName);
      playBeep('success');
      setPoNotice(
        language === 'hi'
          ? `${brandData.brand} का PO PDF (${poNumber}) डाउनलोड हो गया!`
          : `Downloaded ${fileName} (${poNumber}) successfully!`
      );
      setTimeout(() => setPoNotice(null), 3500);
    } catch (err) {
      console.error('Failed to download brand PO:', err);
    } finally {
      setIsDownloadingPo(false);
    }
  };

  // Total blocked capital in dead inventory for this brand
  const totalDeadStockCapital = deadStockModels.reduce(
    (sum, m) => sum + ((m.costPrice || m.price) * m.stock), 
    0
  );
  const totalDeadStockUnits = deadStockModels.reduce((sum, m) => sum + m.stock, 0);

  const profitMarginPercent = brandData.totalSalesValue > 0
    ? ((brandData.totalProfitContribution / brandData.totalSalesValue) * 100).toFixed(1)
    : '0.0';

  const handleApplyClearanceDiscount = async () => {
    if (!discountModalItem) return;

    const currentPrice = discountModalItem.price;
    const discountedPrice = Math.max(
      Math.round(currentPrice * (1 - discountPercent / 100)),
      1
    );

    try {
      if (discountModalItem.id) {
        await updateProduct(discountModalItem.id, {
          sellingPrice: discountedPrice
        });
      }
      playBeep('success');
      setDiscountSuccessMsg(
        language === 'hi'
          ? `${discountModalItem.name} का दाम ₹${currentPrice} से घटाकर ₹${discountedPrice} (${discountPercent}% Clearance Off) कर दिया गया है!`
          : `Clearance price updated for ${discountModalItem.name}: ₹${currentPrice} ➔ ₹${discountedPrice} (${discountPercent}% OFF)`
      );
      setTimeout(() => {
        setDiscountSuccessMsg(null);
        setDiscountModalItem(null);
      }, 2200);
    } catch (err) {
      console.error('Failed to apply clearance discount:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col text-slate-900 shadow-2xl overflow-hidden animate-fade-in my-auto">
        {/* Modal Header */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-red-100 text-red-700 rounded-xl border border-red-200">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg sm:text-xl text-slate-900">
                  {brandData.brand}
                </h3>
                <span className="text-[10px] font-extrabold uppercase bg-red-50 text-red-700 border border-red-200 px-2 py-0.5 rounded-md">
                  {language === 'hi' ? 'ब्रांड विश्लेषण' : 'Brand Performance Drill-Down'}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {brandData.totalProducts} {language === 'hi' ? 'रजिस्टर्ड मॉडल्स' : 'Catalog SKU Models'} • {brandData.totalStockUnits} {language === 'hi' ? 'यूनिट्स दुकान में उपलब्ध' : 'Units In Stock'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {/* Key Metric Highlights (4 Cards) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Metric 1: Total Units Sold */}
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {language === 'hi' ? 'कुल बिक्री (यूनिट्स)' : 'Units Sold'}
              </span>
              <p className="text-xl font-black text-slate-900 mt-1 flex items-baseline gap-1">
                {formatNumber(brandData.totalUnitsSold)}
                <span className="text-xs font-semibold text-slate-500">Pcs</span>
              </p>
              <span className="text-[10px] text-slate-400 font-medium">Billed to retail clients</span>
            </div>

            {/* Metric 2: Total Revenue */}
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {language === 'hi' ? 'कुल राजस्व (Sales)' : 'Total Revenue'}
              </span>
              <p className="text-xl font-black text-slate-900 mt-1">
                {formatCurrency(brandData.totalSalesValue)}
              </p>
              <span className="text-[10px] text-slate-400 font-medium">Gross Billed Value</span>
            </div>

            {/* Metric 3: Total Net Profit */}
            <div className="bg-emerald-50/70 border border-emerald-200 p-3.5 rounded-xl">
              <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider block">
                {language === 'hi' ? 'कुल शुद्ध लाभ (Profit)' : 'Net Profit'}
              </span>
              <p className="text-xl font-black text-emerald-700 mt-1">
                {formatCurrency(brandData.totalProfitContribution)}
              </p>
              <span className="text-[10px] text-emerald-800 font-semibold">{profitMarginPercent}% Net Margin</span>
            </div>

            {/* Metric 4: Current In-Stock Units */}
            <div className="bg-blue-50/70 border border-blue-200 p-3.5 rounded-xl">
              <span className="text-[11px] font-bold text-blue-800 uppercase tracking-wider block">
                {language === 'hi' ? 'उपलब्ध स्टॉक' : 'Current In-Stock'}
              </span>
              <p className="text-xl font-black text-blue-900 mt-1 flex items-baseline gap-1">
                {formatNumber(brandData.totalStockUnits)}
                <span className="text-xs font-semibold text-blue-700">Pcs</span>
              </p>
              <span className="text-[10px] text-blue-800 font-medium">Val: {formatCurrency(brandData.inventoryValuation)}</span>
            </div>
          </div>

          {/* Success Banner when Clearance applied */}
          {discountSuccessMsg && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 rounded-xl flex items-center gap-2.5 text-xs font-bold animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{discountSuccessMsg}</span>
            </div>
          )}

          {/* Filter Sub-Tabs */}
          <div className="flex border-b border-slate-200 space-x-3 text-xs font-bold overflow-x-auto">
            <button
              onClick={() => setActiveTab('top')}
              className={`pb-2.5 px-3 flex items-center gap-2 border-b-2 transition cursor-pointer shrink-0 ${
                activeTab === 'top'
                  ? 'border-red-600 text-red-600'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Flame className="w-4 h-4" />
              <span>{language === 'hi' ? '🔥 टॉप सेलिंग प्रोडक्ट्स' : '🔥 Top Selling Products'}</span>
              <span className="bg-red-100 text-red-700 text-[10px] px-1.5 py-0.2 rounded-full font-extrabold">
                {topSellingModels.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('dead')}
              className={`pb-2.5 px-3 flex items-center gap-2 border-b-2 transition cursor-pointer shrink-0 ${
                activeTab === 'dead'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <Snowflake className="w-4 h-4" />
              <span>{language === 'hi' ? '🧊 शून्य बिक्री / डेड स्टॉक' : '🧊 Zero Sales / Non-Moving (Dead SKUs)'}</span>
              {deadStockModels.length > 0 && (
                <span className="bg-blue-100 text-blue-800 text-[10px] px-1.5 py-0.2 rounded-full font-extrabold">
                  {deadStockModels.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('reorder')}
              className={`pb-2.5 px-3 flex items-center gap-2 border-b-2 transition cursor-pointer shrink-0 ${
                activeTab === 'reorder'
                  ? 'border-emerald-600 text-emerald-600'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>{language === 'hi' ? '📦 री-ऑर्डर व पर्चेस आर्डर (PO)' : '📦 Reorder & PO (PDF)'}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
                lowStockBrandModels.length > 0 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
              }`}>
                {lowStockBrandModels.length > 0 ? `${lowStockBrandModels.length} Low` : `${reorderModelsList.length} SKUs`}
              </span>
            </button>
          </div>

          {/* TAB 1: TOP SELLING PRODUCTS */}
          {activeTab === 'top' && (
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-red-600" />
                  <h4 className="font-extrabold text-slate-900">
                    {language === 'hi' ? `${brandData.brand} के सभी मॉडल्स व बिक्री परफॉर्मेंस` : `Active Models under ${brandData.brand}`}
                  </h4>
                </div>
                <span className="text-slate-500 font-semibold">
                  Sorted by highest units sold
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="overflow-x-auto max-h-[340px] overflow-y-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="sticky top-0 bg-slate-100 border-b border-slate-200 text-slate-600 uppercase text-[10px] tracking-wider font-bold z-10">
                      <tr>
                        <th className="py-2.5 px-3">#</th>
                        <th className="py-2.5 px-3">{language === 'hi' ? 'प्रोडक्ट मॉडल / SKU' : 'Product Model / SKU'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'मूल्य (Rate)' : 'Selling Price'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'बिक्री यूनिट्स' : 'Units Sold'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'कुल रेवेन्यू' : 'Total Revenue'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'शुद्ध प्रॉफिट' : 'Net Profit'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'स्टॉक बचा' : 'Stock Left'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {topSellingModels.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="text-center py-8 text-slate-400 font-medium">
                            No products registered under this brand.
                          </td>
                        </tr>
                      ) : (
                        topSellingModels.map((model, idx) => {
                          const isLowStock = model.stock <= 3;
                          return (
                            <tr key={idx} className="hover:bg-slate-50 transition">
                              <td className="py-2.5 px-3 font-bold text-slate-400">
                                {idx + 1}
                              </td>
                              <td className="py-2.5 px-3">
                                <p className="font-bold text-slate-900">{model.name}</p>
                                {model.barcode && (
                                  <p className="text-[10px] font-mono text-slate-400">{model.barcode}</p>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                                ₹{model.price.toFixed(0)}
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <span className={`font-black ${model.soldQty > 0 ? 'text-emerald-700' : 'text-slate-400'}`}>
                                  {model.soldQty} pcs
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                                ₹{model.revenue.toFixed(0)}
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <span className={`font-extrabold ${model.profit > 0 ? 'text-emerald-700' : 'text-slate-400'}`}>
                                  ₹{model.profit.toFixed(0)}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                  isLowStock
                                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                    : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                }`}>
                                  {model.stock} Pcs
                                </span>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ZERO SALES / DEAD SKUS */}
          {activeTab === 'dead' && (
            <div className="space-y-4">
              {/* Dead Stock Summary Alert Box */}
              <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-amber-100 text-amber-800 rounded-lg shrink-0 mt-0.5">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-amber-950 uppercase tracking-wider">
                      {language === 'hi' ? 'ब्लॉक्ड कैपिटल व डेड इन्वेंट्री चेतावनी' : 'Blocked Working Capital in Slow Inventory'}
                    </h4>
                    <p className="text-xs text-amber-900 mt-0.5 font-medium">
                      {deadStockModels.length} {language === 'hi' ? 'मॉडल्स में कोई बिक्री नहीं हुई है। कुल ब्लॉक्ड लागत:' : 'SKU models have 0 sales in this period. Total Blocked Cost:'}
                    </p>
                  </div>
                </div>

                <div className="text-right bg-white px-3.5 py-2 rounded-xl border border-amber-300 shadow-2xs shrink-0">
                  <span className="text-[10px] font-extrabold uppercase text-slate-500 block">Total Blocked Funds</span>
                  <span className="text-base font-black text-red-600">{formatCurrency(totalDeadStockCapital)}</span>
                  <span className="text-[10px] text-slate-500 block">({totalDeadStockUnits} units in store)</span>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="overflow-x-auto max-h-[340px] overflow-y-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="sticky top-0 bg-slate-100 border-b border-slate-200 text-slate-600 uppercase text-[10px] tracking-wider font-bold z-10">
                      <tr>
                        <th className="py-2.5 px-3">#</th>
                        <th className="py-2.5 px-3">{language === 'hi' ? 'प्रोडक्ट नाम व SKU' : 'Product Name & SKU'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'उपलब्ध स्टॉक' : 'In-Stock Qty'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'खरीद लागत (Landing Cost)' : 'Landing Cost'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'hi' ? 'ब्लॉक्ड पूँजी (Blocked Capital)' : 'Blocked Capital Value'}</th>
                        <th className="py-2.5 px-3 text-center">{language === 'hi' ? 'इनवर्ड/अंतिम बिक्री' : 'Days in Store'}</th>
                        <th className="py-2.5 px-3 text-center">{language === 'hi' ? 'एक्शन' : 'Clearance Action'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {deadStockModels.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="text-center py-8 text-slate-400 font-medium">
                            🎉 Excellent! All products under this brand have active sales and zero dead inventory.
                          </td>
                        </tr>
                      ) : (
                        deadStockModels.map((model, idx) => {
                          const unitCost = model.costPrice || model.price;
                          const totalBlocked = unitCost * model.stock;
                          const daysSitting = model.daysSinceInward !== undefined ? model.daysSinceInward : 15;

                          return (
                            <tr key={idx} className="hover:bg-slate-50 transition">
                              <td className="py-2.5 px-3 font-bold text-slate-400">
                                {idx + 1}
                              </td>
                              <td className="py-2.5 px-3">
                                <p className="font-bold text-slate-900">{model.name}</p>
                                {model.barcode && (
                                  <p className="text-[10px] font-mono text-slate-400">{model.barcode}</p>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <span className="font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded-md">
                                  {model.stock} Pcs
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-right font-medium text-slate-700">
                                ₹{unitCost.toFixed(0)}
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <span className="font-black text-red-600">
                                  ₹{totalBlocked.toFixed(0)}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md">
                                  <Clock className="w-3 h-3 text-slate-400" />
                                  {daysSitting} days
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDiscountModalItem(model);
                                    setDiscountPercent(15);
                                  }}
                                  className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-lg text-[11px] flex items-center gap-1 mx-auto transition cursor-pointer shadow-2xs active:scale-95 whitespace-nowrap"
                                  title="Add clearance discount to liquidate item"
                                >
                                  <Tag className="w-3 h-3" />
                                  <span>{language === 'hi' ? '🏷️ डिस्काउंट लगाएं' : '🏷️ Clearance Off'}</span>
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: REORDER & BRAND PURCHASE ORDER (PO) GENERATOR */}
          {activeTab === 'reorder' && (
            <div className="space-y-4">
              {/* Top Action Banner */}
              <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100/50 border border-emerald-200 p-4 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <h4 className="font-extrabold text-sm sm:text-base text-emerald-950 flex items-center gap-2">
                    <Truck className="w-4 h-4 text-emerald-700" />
                    <span>{language === 'hi' ? `${brandData.brand} आधिकारिक पर्चेस आर्डर (PO) जेनरेटर` : `${brandData.brand} Official Purchase Order (PO)`}</span>
                  </h4>
                  <p className="text-xs text-emerald-800 font-medium mt-0.5">
                    {lowStockBrandModels.length > 0 
                      ? `${lowStockBrandModels.length} models have low stock (≤ 3 pcs). Adjust quantities below and share official PDF.` 
                      : `All models under ${brandData.brand} are listed. Set restock quantities to generate PO.`}
                  </p>
                </div>

                {/* Primary Action Buttons */}
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={handleShareBrandPoPdf}
                    disabled={isSharingPo}
                    className="h-10 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-2 transition cursor-pointer active:scale-95"
                    title="Generate and Share PO PDF via WhatsApp / Web Share"
                  >
                    {isSharingPo ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Share2 className="w-4 h-4" />
                    )}
                    <span>{language === 'hi' ? 'सप्लायर को PO PDF भेजें' : 'Share PO PDF to Supplier'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadBrandPoPdf}
                    disabled={isDownloadingPo}
                    className="h-10 px-3.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer"
                    title="Direct Download PO PDF"
                  >
                    {isDownloadingPo ? (
                      <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    <span>Download PDF</span>
                  </button>
                </div>
              </div>

              {/* Feedback toast */}
              {poNotice && (
                <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 p-3.5 rounded-xl flex items-center gap-2.5 text-xs font-bold shadow-2xs animate-fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{poNotice}</span>
                </div>
              )}

              {/* Items Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="overflow-x-auto max-h-[380px]">
                  <table className="w-full text-left text-xs text-slate-700">
                    <thead className="bg-slate-50 text-slate-600 uppercase text-[10px] tracking-wider border-b border-slate-200 font-extrabold sticky top-0 z-10">
                      <tr>
                        <th className="py-2.5 px-3">#</th>
                        <th className="py-2.5 px-3">Model / Barcode</th>
                        <th className="py-2.5 px-3 text-center">In-Stock</th>
                        <th className="py-2.5 px-3 text-center">Reorder Qty</th>
                        <th className="py-2.5 px-3 text-right">Est. Unit Rate</th>
                        <th className="py-2.5 px-3 text-right">Total Est.</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {reorderModelsList.map((model, idx) => {
                        const reqQty = getItemReorderQty(model);
                        const unitRate = model.costPrice || Math.round(model.price * 0.7);
                        const lineTotal = unitRate * reqQty;
                        const isLowStock = model.stock <= 3;

                        return (
                          <tr key={idx} className="hover:bg-slate-50 transition">
                            <td className="py-2.5 px-3 font-bold text-slate-400">
                              {idx + 1}
                            </td>
                            <td className="py-2.5 px-3">
                              <p className="font-bold text-slate-900 text-xs sm:text-sm">{model.name}</p>
                              {model.barcode && (
                                <p className="text-[10px] font-mono text-slate-400">{model.barcode}</p>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-black ${
                                isLowStock 
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200' 
                                  : 'bg-slate-100 text-slate-700'
                              }`}>
                                {model.stock} Pcs
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center">
                              <div className="inline-flex items-center gap-1.5 bg-slate-50 border border-slate-200 p-1 rounded-xl">
                                <button
                                  type="button"
                                  onClick={() => model.id && updateItemReorderQty(model.id, reqQty - 1)}
                                  className="w-6 h-6 bg-white hover:bg-slate-200 text-slate-700 rounded-md font-bold text-xs flex items-center justify-center shadow-2xs cursor-pointer"
                                >
                                  -
                                </button>
                                <input
                                  type="number"
                                  min="1"
                                  max="9999"
                                  value={reqQty}
                                  onChange={(e) => model.id && updateItemReorderQty(model.id, parseInt(e.target.value, 10) || 1)}
                                  className="w-10 text-center font-black text-slate-900 text-xs bg-transparent focus:outline-hidden"
                                />
                                <button
                                  type="button"
                                  onClick={() => model.id && updateItemReorderQty(model.id, reqQty + 1)}
                                  className="w-6 h-6 bg-white hover:bg-slate-200 text-slate-700 rounded-md font-bold text-xs flex items-center justify-center shadow-2xs cursor-pointer"
                                >
                                  +
                                </button>
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-right font-medium text-slate-600">
                              ₹{unitRate}
                            </td>
                            <td className="py-2.5 px-3 text-right font-black text-emerald-800">
                              {formatCurrency(lineTotal)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* PO Table Summary footer */}
                <div className="bg-slate-50 border-t border-slate-200 p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                  <div className="flex items-center gap-2 text-slate-500 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Includes official store header, GSTIN & authorized signature box in PDF</span>
                  </div>
                  <div className="flex items-center gap-3 font-bold text-slate-700">
                    <span>Total Models: <b className="text-slate-900">{reorderModelsList.length}</b></span>
                    <span>•</span>
                    <span>Total Order: <b className="text-slate-900">{reorderModelsList.reduce((sum, m) => sum + getItemReorderQty(m), 0)} Units</b></span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs">
          <span className="text-slate-500 font-medium">
            {language === 'hi' 
              ? 'यह डेटा सभी इनवॉइस व इन्वेंटरी स्टॉक के साथ रियल-टाइम सिंक रहता है।' 
              : 'Dynamic brand analytics calculated from real-time sales & inventory.'}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition cursor-pointer shadow-xs"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>

      {/* QUICK DISCOUNT / CLEARANCE MODAL */}
      {discountModalItem && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 text-slate-900 shadow-2xl animate-fade-in">
            <div className="flex justify-between items-start border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                  <Tag className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-slate-900">
                    {language === 'hi' ? 'क्लियरेंस डिस्काउंट सेट करें' : 'Apply Clearance Discount'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">{discountModalItem.name}</p>
                </div>
              </div>
              <button
                onClick={() => setDiscountModalItem(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Current Selling Price:</span>
                <span className="font-bold text-slate-900 line-through">₹{discountModalItem.price}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">Inward Landing Cost:</span>
                <span className="font-bold text-slate-700">₹{(discountModalItem.costPrice || 0).toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-medium">In-Stock Quantity:</span>
                <span className="font-bold text-slate-900">{discountModalItem.stock} Units</span>
              </div>
            </div>

            {/* Quick Discount Percent Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 block">
                {language === 'hi' ? 'डिस्काउंट प्रतिशत चुनें:' : 'Select Discount %:'}
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[10, 15, 20, 30].map(pct => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setDiscountPercent(pct)}
                    className={`py-2 text-xs font-black rounded-xl border transition cursor-pointer ${
                      discountPercent === pct
                        ? 'bg-red-600 text-white border-red-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {pct}% OFF
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Input */}
            <div>
              <label className="text-xs font-medium text-slate-600 block mb-1">
                {language === 'hi' ? 'या कस्टम प्रतिशत लिखें (%):' : 'Or enter custom discount percentage:'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="1"
                  max="90"
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(Math.max(1, Math.min(90, Number(e.target.value))))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm font-bold text-slate-900 focus:outline-hidden focus:border-red-600"
                />
                <Percent className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              </div>
            </div>

            {/* New Price Calculation Box */}
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex justify-between items-center text-xs">
              <div>
                <span className="text-emerald-800 font-bold block">
                  {language === 'hi' ? 'नया रियायती बिक्री मूल्य:' : 'New Discounted Selling Price:'}
                </span>
                <span className="text-[11px] text-emerald-700">Will be billed on POS instantly</span>
              </div>
              <span className="text-xl font-black text-emerald-800">
                ₹{Math.max(1, Math.round(discountModalItem.price * (1 - discountPercent / 100)))}
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDiscountModalItem(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                {language === 'hi' ? 'रद्द करें' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleApplyClearanceDiscount}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs shadow-red-600/20"
              >
                {language === 'hi' ? 'कीमत अपडेट करें' : 'Update & Liquidate'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
