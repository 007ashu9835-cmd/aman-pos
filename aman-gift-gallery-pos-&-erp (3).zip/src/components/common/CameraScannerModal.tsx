import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  MultiFormatReader, 
  BarcodeFormat, 
  DecodeHintType, 
  RGBLuminanceSource, 
  HybridBinarizer, 
  BinaryBitmap 
} from '@zxing/library';
import { 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Barcode, 
  Zap, 
  ArrowRight, 
  Upload, 
  RefreshCw, 
  SwitchCamera,
  Keyboard,
  Focus,
  ZoomIn,
  ZoomOut,
  Camera,
  Image as ImageIcon,
  Loader2
} from 'lucide-react';
import { decodeBarcodeFromImage, playScanAudioTone } from '../../utils/barcodeImageDecoder';

// Setup ZXing MultiFormatReader configured for retail barcode formats
const createZXingReader = () => {
  const reader = new MultiFormatReader();
  const hints = new Map<DecodeHintType, any>();
  hints.set(DecodeHintType.POSSIBLE_FORMATS, [
    BarcodeFormat.EAN_13,
    BarcodeFormat.CODE_128,
    BarcodeFormat.UPC_A,
    BarcodeFormat.UPC_E,
    BarcodeFormat.CODE_39,
    BarcodeFormat.CODE_93,
    BarcodeFormat.EAN_8,
    BarcodeFormat.ITF,
    BarcodeFormat.QR_CODE,
    BarcodeFormat.DATA_MATRIX
  ]);
  hints.set(DecodeHintType.TRY_HARDER, true);
  reader.setHints(hints);
  return reader;
};

// Native BarcodeDetector API typings
declare global {
  interface Window {
    BarcodeDetector?: any;
  }
}

export const CameraScannerModal: React.FC = () => {
  const { 
    isCameraScannerOpen, 
    setIsCameraScannerOpen, 
    cameraScannerMode, 
    cameraScanCallback, 
    setCameraScanCallback, 
    products, 
    addToCart, 
    isExchangeMode, 
    playBeep, 
    language 
  } = useApp();
  
  // Element references
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const directCameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Hardware Stream & Scanner Engines
  const streamRef = useRef<MediaStream | null>(null);
  const activeTrackRef = useRef<MediaStreamTrack | null>(null);
  const scanIntervalRef = useRef<any>(null);
  const zxingReaderRef = useRef<MultiFormatReader | null>(null);
  const nativeDetectorRef = useRef<any>(null);
  
  // State refs to prevent re-renders inside high-frequency scan loop
  const isScanningActiveRef = useRef<boolean>(false);
  const isDecodingFrameRef = useRef<boolean>(false);
  const hasTriggeredResultRef = useRef<boolean>(false);

  // Context references to avoid stale closures
  const productsRef = useRef(products);
  productsRef.current = products;

  const cameraScannerModeRef = useRef(cameraScannerMode);
  cameraScannerModeRef.current = cameraScannerMode;

  const cameraScanCallbackRef = useRef(cameraScanCallback);
  cameraScanCallbackRef.current = cameraScanCallback;

  const isExchangeModeRef = useRef(isExchangeMode);
  isExchangeModeRef.current = isExchangeMode;

  const playBeepRef = useRef(playBeep);
  playBeepRef.current = playBeep;

  const addToCartRef = useRef(addToCart);
  addToCartRef.current = addToCart;

  // Local UI states
  const [manualCode, setManualCode] = useState('');
  const [scannedResult, setScannedResult] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [hasMultipleCameras, setHasMultipleCameras] = useState(false);
  const [currentFacingMode, setCurrentFacingMode] = useState<'environment' | 'user'>('environment');
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const [focusAnimation, setFocusAnimation] = useState(false);
  const [hasZoomSupport, setHasZoomSupport] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  // Play audio beep & haptic feedback
  const triggerBeep = useCallback((isSuccess = true) => {
    try {
      playBeepRef.current(isSuccess ? (isExchangeModeRef.current ? 'exchange' : 'scan') : 'alert');
    } catch {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(isSuccess ? 1800 : 400, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } catch {}
    }

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(isSuccess ? [40, 30, 80] : 120);
      } catch {}
    }
  }, []);

  // Safe Stream & Engine Teardown
  const stopCameraStream = useCallback(() => {
    isScanningActiveRef.current = false;

    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        try {
          track.stop();
        } catch {}
      });
      streamRef.current = null;
    }

    activeTrackRef.current = null;

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    isDecodingFrameRef.current = false;
    setIsCameraActive(false);
    setHasZoomSupport(false);
    setIsZoomed(false);
  }, []);

  // Non-breaking Zoom Toggle handler
  const handleToggleZoom = useCallback(async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const track = activeTrackRef.current;
    if (!track) return;

    const nextZoomState = !isZoomed;
    try {
      const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};
      const maxZoom = capabilities?.zoom?.max ?? 2;
      const minZoom = capabilities?.zoom?.min ?? 1;
      const targetZoom = nextZoomState ? Math.min(2, maxZoom) : minZoom;

      await track.applyConstraints({
        advanced: [{ zoom: targetZoom } as any]
      });
      setIsZoomed(nextZoomState);
    } catch (err) {
      console.warn('Non-breaking zoom constraint failed:', err);
    }
  }, [isZoomed]);

  // Handle a successfully scanned barcode string
  const handleBarcodeParsed = useCallback((code: string) => {
    const trimmed = code.trim();
    if (!trimmed || hasTriggeredResultRef.current) return;
    
    hasTriggeredResultRef.current = true;
    isScanningActiveRef.current = false;
    triggerBeep(true);
    setScannedResult(trimmed);

    // 1. If invoked with an onScan callback (e.g. Inventory SKU modal)
    if (cameraScanCallbackRef.current) {
      const cb = cameraScanCallbackRef.current;
      stopCameraStream();
      cb(trimmed);
      setTimeout(() => {
        setIsCameraScannerOpen(false);
        setCameraScanCallback(null);
      }, 150);
      return;
    }

    // 2. If in POS / Billing mode
    const matchedProduct = productsRef.current.find(
      p => p.barcode.toLowerCase() === trimmed.toLowerCase() || p.name.toLowerCase().includes(trimmed.toLowerCase())
    );

    if (matchedProduct) {
      if (cameraScannerModeRef.current === 'pos') {
        addToCartRef.current(matchedProduct, isExchangeModeRef.current);
      }
      stopCameraStream();
      setTimeout(() => {
        setIsCameraScannerOpen(false);
      }, 200);
    } else {
      setErrorMessage(
        language === 'hi'
          ? `बारकोड "${trimmed}" स्टॉक में नहीं मिला।`
          : `Barcode "${trimmed}" not found in stock.`
      );
      // Allow retry after 1.8s
      setTimeout(() => {
        hasTriggeredResultRef.current = false;
        setErrorMessage(null);
        setScannedResult(null);
        isScanningActiveRef.current = true;
      }, 1800);
    }
  }, [triggerBeep, stopCameraStream, setIsCameraScannerOpen, setCameraScanCallback, language]);

  // High-Efficiency Continuous Multi-Format Frame Sampler with Center-Box High-Res Crop (~100ms interval)
  const sampleVideoFrame = useCallback(async () => {
    if (!isScanningActiveRef.current || hasTriggeredResultRef.current || isDecodingFrameRef.current) {
      return;
    }

    const video = videoRef.current;
    if (!video || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || video.videoWidth === 0) {
      return;
    }

    isDecodingFrameRef.current = true;

    try {
      // Tier 1: Hardware GPU Native BarcodeDetector (Zero-copy, <4ms)
      if (nativeDetectorRef.current) {
        try {
          const barcodes = await nativeDetectorRef.current.detect(video);
          if (barcodes && barcodes.length > 0 && barcodes[0]?.rawValue) {
            handleBarcodeParsed(barcodes[0].rawValue);
            isDecodingFrameRef.current = false;
            return;
          }
        } catch {
          // Fall through to Tier 2 ZXing canvas decoding
        }
      }

      // Tier 2: ZXing Canvas Decoding with In-Memory Central 50% ROI Auto-Crop
      const canvas = canvasRef.current;
      if (canvas && zxingReaderRef.current) {
        const vw = video.videoWidth;
        const vh = video.videoHeight;

        // In-Memory Auto-Crop for Tiny Barcodes: Central 50% region (Center ROI Crop)
        const cropW = Math.floor(vw * 0.50);
        const cropH = Math.floor(vh * 0.50);
        const cropX = Math.floor((vw - cropW) / 2);
        const cropY = Math.floor((vh - cropH) / 2);

        // Scaled to full canvas dimensions for magnified high-res decoding
        const targetW = cropW;
        const targetH = cropH;

        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });

        if (ctx) {
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(video, cropX, cropY, cropW, cropH, 0, 0, targetW, targetH);
          const imgData = ctx.getImageData(0, 0, targetW, targetH);
          const data = imgData.data;

          // Convert to grayscale for fast luminance processing
          const lumSource = new RGBLuminanceSource(
            new Uint8ClampedArray(data.buffer),
            targetW,
            targetH
          );

          try {
            const binarizer = new HybridBinarizer(lumSource);
            const binaryBitmap = new BinaryBitmap(binarizer);
            const result = zxingReaderRef.current.decodeWithState(binaryBitmap);
            if (result && result.getText()) {
              handleBarcodeParsed(result.getText());
              zxingReaderRef.current.reset();
            }
          } catch {
            zxingReaderRef.current.reset();
          }
        }
      }
    } catch {
      // Continue next tick
    } finally {
      isDecodingFrameRef.current = false;
    }
  }, [handleBarcodeParsed]);

  // Tap to Focus trigger
  const handleTapToFocus = useCallback(async () => {
    setFocusAnimation(true);
    setTimeout(() => setFocusAnimation(false), 900);

    const track = activeTrackRef.current;
    if (track && track.applyConstraints) {
      try {
        track.applyConstraints({
          advanced: [
            { focusMode: "continuous" },
            { focusDistance: { ideal: 0.1 } },
            { exposureMode: "continuous" }
          ] as any
        }).catch(() => {});
      } catch {}
    }
  }, []);

  // Start Standalone / PWA Webview Compatible Camera Stream
  const startCameraStream = useCallback(async (facing: 'environment' | 'user' = 'environment') => {
    stopCameraStream();
    setCameraError(null);
    hasTriggeredResultRef.current = false;

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError(
        language === 'hi'
          ? 'कैमरा सपोर्ट नहीं करता। कृपया नीचे बारकोड नंबर टाइप करें।'
          : 'Camera is not supported in this browser. Please type the barcode manually below.'
      );
      return;
    }

    try {
      if (navigator.mediaDevices.enumerateDevices) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoInputs = devices.filter(d => d.kind === 'videoinput');
        if (devices.length > 0 && videoInputs.length === 0) {
          setCameraError(
            language === 'hi'
              ? 'इस डिवाइस पर कोई कैमरा नहीं मिला। नीचे बारकोड टाइप करें या फोटो चुनें।'
              : 'No camera hardware found on this device. You can type the barcode below or upload a photo.'
          );
          return;
        }
        setHasMultipleCameras(videoInputs.length > 1);
      }
    } catch {
      // ignore enumeration errors
    }

    let stream: MediaStream | null = null;

    try {
      // Step 1: Request soft ideal 1080p high-resolution stream
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facing },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      });
    } catch (highResErr) {
      try {
        // Step 2: Fallback to standard facingMode
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing },
          audio: false
        });
      } catch (primaryErr) {
        try {
          // Step 3: Fallback to any basic video stream
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false
          });
        } catch (fallbackErr: any) {
          console.warn('Camera stream could not be started (no camera or access restricted):', fallbackErr?.message || fallbackErr);
          const errName = fallbackErr?.name || '';
          const errMsg = fallbackErr?.message || '';

          if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError') {
            setCameraError(
              language === 'hi'
                ? 'कैमरा अनुमति अस्वीकृत है। ब्राउज़र सेटिंग्स में कैमरा एक्सेस ऑन करें।'
                : 'Camera permission denied. Please allow camera access in browser settings.'
            );
          } else if (
            errName === 'NotFoundError' || 
            errName === 'DevicesNotFoundError' || 
            errMsg.toLowerCase().includes('device not found') ||
            errMsg.toLowerCase().includes('not found')
          ) {
            setCameraError(
              language === 'hi'
                ? 'कोई कैमरा नहीं मिला। आप नीचे बारकोड टाइप कर सकते हैं या फोटो खींच सकते हैं।'
                : 'No camera device found on this system. You can type the barcode below or upload a photo.'
            );
          } else if (errName === 'NotReadableError' || errName === 'TrackStartError') {
            setCameraError(
              language === 'hi'
                ? 'कैमरा किसी अन्य ऐप द्वारा उपयोग में है।'
                : 'Camera is currently in use by another application.'
            );
          } else {
            setCameraError(
              language === 'hi'
                ? 'कैमरा कनेक्ट नहीं हो सका। कृपया नीचे बारकोड टाइप करें।'
                : 'Could not connect to camera. Please type the barcode manually below.'
            );
          }
          return;
        }
      }
    }

    if (!stream) return;

    streamRef.current = stream;
    const track = stream.getVideoTracks()[0] || null;
    activeTrackRef.current = track;

    setCurrentFacingMode(facing);
    setIsCameraActive(true);
    isScanningActiveRef.current = true;

    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      try {
        await videoRef.current.play();
      } catch (e) {
        console.warn('Video playback warning:', e);
      }
    }

    // Inspect capabilities & apply continuous hardware macro autofocus & dynamic exposure
    if (track) {
      try {
        track.applyConstraints({
          advanced: [
            { focusMode: "continuous" },
            { focusDistance: { ideal: 0.1 } },
            { exposureMode: "continuous" }
          ] as any
        }).catch(() => {});

        const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};
        if (capabilities.zoom && capabilities.zoom.max > 1) {
          setHasZoomSupport(true);
        } else {
          setHasZoomSupport(false);
        }
      } catch {
        setHasZoomSupport(false);
      }
    }

    // Launch efficient 100ms frame sampling loop
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    scanIntervalRef.current = setInterval(sampleVideoFrame, 100);
  }, [language, stopCameraStream, sampleVideoFrame]);

  // Modal Lifecycle: Initialize reader & start stream
  useEffect(() => {
    try {
      zxingReaderRef.current = createZXingReader();
      if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
        try {
          nativeDetectorRef.current = new window.BarcodeDetector({
            formats: ['ean_13', 'code_128', 'upc_a', 'upc_e', 'code_39', 'code_93', 'ean_8', 'itf', 'qr_code', 'data_matrix']
          });
        } catch {
          nativeDetectorRef.current = null;
        }
      }
    } catch {}

    if (isCameraScannerOpen) {
      startCameraStream('environment');
    }

    return () => {
      stopCameraStream();
    };
  }, [isCameraScannerOpen, startCameraStream, stopCameraStream]);

  // Flip Camera Sensor
  const handleFlipCamera = () => {
    const nextFacing = currentFacingMode === 'environment' ? 'user' : 'environment';
    startCameraStream(nextFacing);
  };

  // Decode barcode from image file (Direct camera snap or Gallery photo)
  const handleBarcodeImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    setErrorMessage(null);

    try {
      const detectedCode = await decodeBarcodeFromImage(file);

      if (detectedCode) {
        handleBarcodeParsed(detectedCode);
      } else {
        playScanAudioTone(false);
        setErrorMessage(
          language === 'hi'
            ? 'फोटो में बारकोड नहीं मिला। कृपया साफ और सीधी फोटो लें।'
            : 'No barcode found in captured photo. Please snap a clear, steady picture.'
        );
      }
    } catch (err) {
      console.error('Barcode photo decode error:', err);
      playScanAudioTone(false);
      setErrorMessage(
        language === 'hi'
          ? 'फोटो में बारकोड नहीं पढ़ा जा सका।'
          : 'Could not decode barcode from photo.'
      );
    } finally {
      setIsProcessingFile(false);
      if (directCameraInputRef.current) directCameraInputRef.current.value = '';
      if (galleryInputRef.current) galleryInputRef.current.value = '';
    }
  };

  if (!isCameraScannerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md overflow-hidden text-slate-900 shadow-2xl my-auto flex flex-col">
        
        {/* Hidden Processing Canvas */}
        <canvas ref={canvasRef} className="hidden" />

        {/* 1. Direct Camera Capture Input (Bypasses gallery, opens native rear camera) */}
        <input 
          ref={directCameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          id="direct-camera-barcode-input-modal"
          className="hidden"
          onChange={handleBarcodeImageFile}
        />

        {/* 2. Gallery / File Upload Input */}
        <input 
          ref={galleryInputRef}
          type="file"
          accept="image/*"
          id="gallery-file-barcode-input-modal"
          className="hidden"
          onChange={handleBarcodeImageFile}
        />

        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-red-600 text-white rounded-xl shadow-xs">
              <Barcode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base text-slate-900 leading-tight flex items-center gap-1.5">
                <span>{language === 'hi' ? 'बारकोड स्कैनर' : 'Barcode Scanner'}</span>
                <span className="text-[9px] font-extrabold uppercase tracking-wider px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded-md flex items-center gap-0.5">
                  <Zap className="w-2.5 h-2.5 fill-emerald-600" />
                  Live
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                {cameraScannerMode === 'pos' 
                  ? (language === 'hi' ? 'बिलिंग: बारकोड स्कैन होते ही कार्ट में ऐड होगा' : 'POS: Scan barcode to add to cart') 
                  : (language === 'hi' ? 'इन्वेंट्री: SKU कोड ऑटो-डिटेक्ट' : 'Inventory: Scan SKU code')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Flip Camera */}
            {hasMultipleCameras && isCameraActive && (
              <button
                type="button"
                onClick={handleFlipCamera}
                className="p-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition cursor-pointer"
                title="Switch Camera (Front / Rear)"
              >
                <SwitchCamera className="w-4 h-4" />
              </button>
            )}

            {/* Direct Camera Photo Snap */}
            <button
              type="button"
              onClick={() => directCameraInputRef.current?.click()}
              disabled={isProcessingFile}
              className="p-2 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 transition cursor-pointer"
              title="Take Barcode Photo (Direct Camera)"
            >
              <Camera className="w-4 h-4" />
            </button>

            {/* Upload photo from gallery fallback */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              disabled={isProcessingFile}
              className="p-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              title="Choose from Gallery / Files"
            >
              <ImageIcon className="w-4 h-4" />
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={() => {
                stopCameraStream();
                setIsCameraScannerOpen(false);
                setCameraScanCallback(null);
              }}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Live Camera Viewport Area (Tap to Focus Enabled) */}
        <div 
          onClick={handleTapToFocus}
          className="relative bg-slate-950 flex flex-col items-center justify-center overflow-hidden min-h-[260px] max-h-[320px] cursor-pointer select-none"
          title="Tap anywhere to trigger camera focus"
        >
          {/* Explicit Standalone App / PWA Webview Compatible HTML5 Video Element */}
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className={`w-full h-full object-cover ${isCameraActive ? 'block' : 'hidden'}`}
          />

          {/* Processing Photo Loader */}
          {isProcessingFile && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center gap-2 z-40 text-white">
              <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
              <p className="text-xs font-bold">{language === 'hi' ? 'बारकोड प्रोसेस हो रहा है...' : 'Decoding barcode photo...'}</p>
            </div>
          )}

          {/* Top-Right Floating Controls (Zoom 1x / 2x Toggle) */}
          {isCameraActive && hasZoomSupport && (
            <div className="absolute top-3 right-3 z-20">
              <button
                type="button"
                onClick={handleToggleZoom}
                className={`px-2.5 py-1 rounded-full text-xs font-black transition flex items-center gap-1 shadow-lg backdrop-blur-md cursor-pointer border ${
                  isZoomed
                    ? 'bg-amber-500 text-white border-amber-300 ring-2 ring-amber-400/50'
                    : 'bg-black/60 text-white border-white/20 hover:bg-black/80'
                }`}
                title={isZoomed ? 'Reset to 1x zoom' : 'Switch to 2x zoom'}
              >
                {isZoomed ? <ZoomOut className="w-3.5 h-3.5" /> : <ZoomIn className="w-3.5 h-3.5" />}
                <span>{isZoomed ? '2x' : '1x'}</span>
              </button>
            </div>
          )}

          {/* Scanning Reticle Overlay */}
          {isCameraActive && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center p-4 z-10">
              <div className="w-full max-w-[280px] h-[140px] border-2 border-emerald-400 rounded-2xl relative shadow-[0_0_0_9999px_rgba(0,0,0,0.55)]">
                
                {/* 4 Corner Markers */}
                <div className="absolute -top-1 -left-1 w-6 h-6 border-t-3 border-l-3 border-emerald-400 rounded-tl-xl"></div>
                <div className="absolute -top-1 -right-1 w-6 h-6 border-t-3 border-r-3 border-emerald-400 rounded-tr-xl"></div>
                <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-3 border-l-3 border-emerald-400 rounded-bl-xl"></div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-3 border-r-3 border-emerald-400 rounded-br-xl"></div>

                {/* Animated Laser Line */}
                <div className="w-full h-0.5 bg-red-500 absolute top-1/2 -translate-y-1/2 animate-pulse shadow-[0_0_10px_rgba(239,68,68,1),0_0_3px_rgba(255,255,255,0.9)]"></div>
                
                {/* Instructions Badge */}
                <div className="absolute -bottom-7 inset-x-0 text-center flex items-center justify-center gap-1">
                  <span className="text-[10px] font-bold text-white bg-black/80 px-3 py-0.5 rounded-full border border-white/20 shadow-md flex items-center gap-1">
                    <Focus className="w-3 h-3 text-emerald-400" />
                    <span>{language === 'hi' ? 'बारकोड बीच में रखें (टैप = फोकस)' : 'Align barcode (Tap to focus)'}</span>
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Tap to Focus Ripple Animation */}
          {focusAnimation && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
              <div className="w-16 h-16 border-2 border-amber-400 rounded-full animate-ping opacity-75"></div>
            </div>
          )}

          {/* Error / Standby Screen with Direct Photo Buttons */}
          {cameraError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center text-slate-300 space-y-3 z-20 bg-slate-950/95">
              <AlertCircle className="w-10 h-10 text-amber-500" />
              <p className="text-xs font-semibold max-w-xs text-slate-200">{cameraError}</p>
              
              <div className="flex flex-wrap justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    startCameraStream(currentFacingMode);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 border border-slate-700"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    directCameraInputRef.current?.click();
                  }}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-md"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>📸 Snap Photo</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    galleryInputRef.current?.click();
                  }}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Gallery</span>
                </button>
              </div>
            </div>
          )}

          {/* Success Banner */}
          {scannedResult && (
            <div className="absolute top-4 inset-x-4 bg-emerald-600 text-white text-xs font-black py-2.5 px-4 rounded-xl flex items-center gap-2 shadow-xl z-30 border border-emerald-400">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span className="truncate">Scanned: {scannedResult}</span>
            </div>
          )}

          {/* Error Banner */}
          {errorMessage && (
            <div className="absolute top-4 inset-x-4 bg-red-600 text-white text-xs font-bold py-2.5 px-4 rounded-xl flex items-center gap-2 shadow-xl z-30 border border-red-400">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span className="truncate">{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Quick Camera Snapshot & Gallery Action Bar */}
        <div className="px-4 py-2 bg-slate-100 border-t border-slate-200 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => directCameraInputRef.current?.click()}
            disabled={isProcessingFile}
            className="flex-1 py-2 px-3 bg-white hover:bg-indigo-50 border border-indigo-200 text-indigo-700 hover:text-indigo-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-2xs active:scale-98"
          >
            <Camera className="w-4 h-4 text-indigo-600" />
            <span>{language === 'hi' ? '📸 बारकोड फोटो खींचें' : '📸 Take Barcode Photo'}</span>
          </button>
          
          <button
            type="button"
            onClick={() => galleryInputRef.current?.click()}
            disabled={isProcessingFile}
            className="py-2 px-3 bg-white hover:bg-slate-200 border border-slate-200 text-slate-600 hover:text-slate-900 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-2xs active:scale-98"
            title="Choose from Gallery / Files"
          >
            <ImageIcon className="w-3.5 h-3.5 text-slate-500" />
            <span>{language === 'hi' ? '📁 गैलरी / फ़ाइल' : '📁 Gallery'}</span>
          </button>
        </div>

        {/* Fallback Manual Input (Prominent & Always Available) */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-2 shrink-0">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700">
            <span className="flex items-center gap-1.5">
              <Keyboard className="w-3.5 h-3.5 text-slate-500" />
              <span>{language === 'hi' ? 'मैन्युअल बारकोड / SKU कोड दर्ज करें:' : 'Manual Barcode / SKU Code Entry:'}</span>
            </span>
            <span className="text-[10px] text-slate-400 font-normal">Press Enter</span>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (manualCode.trim()) {
                handleBarcodeParsed(manualCode.trim());
              }
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="e.g. 890123456001 or Milton"
              className="flex-1 bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-red-500 focus:border-red-500 transition shadow-xs"
              autoFocus
            />
            <button
              type="submit"
              disabled={!manualCode.trim()}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black text-xs rounded-xl transition cursor-pointer shadow-md shadow-red-600/30 shrink-0 flex items-center gap-1.5"
            >
              <span>{language === 'hi' ? 'लागू करें' : 'Apply'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
