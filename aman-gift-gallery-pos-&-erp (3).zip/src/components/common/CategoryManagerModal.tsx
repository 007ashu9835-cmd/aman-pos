import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  Plus, 
  Edit2, 
  Trash2, 
  Check, 
  FolderTree, 
  Tag, 
  AlertCircle,
  Package
} from 'lucide-react';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCategory?: (category: string) => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  onSelectCategory
}) => {
  const { 
    masterCategories, 
    addCategory, 
    updateCategory, 
    deleteCategory, 
    products 
  } = useApp();

  const [newCatName, setNewCatName] = useState('');
  const [editingCatName, setEditingCatName] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const trimmed = newCatName.trim();
    if (!trimmed) return;

    if (masterCategories.some(c => c.toLowerCase() === trimmed.toLowerCase())) {
      setErrorMessage(`Category "${trimmed}" already exists.`);
      return;
    }

    await addCategory(trimmed);
    setNewCatName('');
    if (onSelectCategory) {
      onSelectCategory(trimmed);
    }
  };

  const handleStartEdit = (cat: string) => {
    setEditingCatName(cat);
    setEditingValue(cat);
    setErrorMessage(null);
  };

  const handleSaveEdit = async (oldName: string) => {
    const trimmed = editingValue.trim();
    if (!trimmed) {
      setEditingCatName(null);
      return;
    }
    if (trimmed.toLowerCase() !== oldName.toLowerCase() && masterCategories.some(c => c.toLowerCase() === trimmed.toLowerCase())) {
      setErrorMessage(`Category "${trimmed}" already exists.`);
      return;
    }

    await updateCategory(oldName, trimmed);
    setEditingCatName(null);
  };

  const handleDelete = async (cat: string) => {
    const count = products.filter(p => p.category?.toLowerCase() === cat.toLowerCase()).length;
    const confirmMsg = count > 0 
      ? `Are you sure you want to delete "${cat}"? ${count} product(s) in this category will be reassigned to "General".`
      : `Are you sure you want to delete "${cat}"?`;

    if (window.confirm(confirmMsg)) {
      await deleteCategory(cat);
    }
  };

  return (
    <div 
      id="category-manager-modal"
      className="fixed inset-0 z-60 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in"
    >
      <div className="bg-white border border-slate-100 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden my-auto max-h-[85vh] flex flex-col text-slate-900 animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 border border-indigo-200/80 flex items-center justify-center text-indigo-600">
              <FolderTree className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-base text-slate-900 tracking-tight">
                Manage Master Categories
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">
                {masterCategories.length} categories active across inventory & POS
              </p>
            </div>
          </div>

          <button
            id="btn-close-category-manager"
            type="button"
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          
          {/* Add Category Input */}
          <form onSubmit={handleAdd} className="space-y-1.5">
            <label className="text-slate-700 font-bold text-xs flex items-center justify-between">
              <span>Create New Category</span>
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  id="input-new-category-name"
                  type="text"
                  value={newCatName}
                  onChange={(e) => {
                    setNewCatName(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="e.g. Kitchenware, Glassware, Stationery..."
                  className="w-full h-11 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl px-3.5 text-xs text-slate-900 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition"
                />
              </div>
              <button
                id="btn-submit-new-category"
                type="submit"
                disabled={!newCatName.trim()}
                className="h-11 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </div>
            {errorMessage && (
              <p className="text-[11px] text-rose-600 font-medium flex items-center gap-1 mt-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{errorMessage}</span>
              </p>
            )}
          </form>

          {/* List of Categories */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
              <span>Category Name</span>
              <span>Stock Items / Actions</span>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200/80 rounded-2xl overflow-hidden bg-slate-50/40">
              {masterCategories.map((category) => {
                const productCount = products.filter(
                  p => p.category?.toLowerCase() === category.toLowerCase()
                ).length;
                const isEditing = editingCatName === category;

                return (
                  <div 
                    key={category}
                    className="p-2.5 sm:px-3.5 flex items-center justify-between gap-2 hover:bg-white transition bg-white/60"
                  >
                    {isEditing ? (
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          type="text"
                          value={editingValue}
                          onChange={(e) => setEditingValue(e.target.value)}
                          className="flex-1 h-9 bg-white border border-indigo-300 rounded-lg px-2.5 text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSaveEdit(category);
                            if (e.key === 'Escape') setEditingCatName(null);
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(category)}
                          className="h-9 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCatName(null)}
                          className="h-9 px-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          <Tag className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                          <span 
                            onClick={() => {
                              if (onSelectCategory) {
                                onSelectCategory(category);
                                onClose();
                              }
                            }}
                            className="font-bold text-xs text-slate-800 truncate cursor-pointer hover:text-indigo-600 transition"
                          >
                            {category}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200/80 flex items-center gap-1">
                            <Package className="w-2.5 h-2.5" />
                            {productCount}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleStartEdit(category)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                            title="Rename Category"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {category !== 'General' && (
                            <button
                              type="button"
                              onClick={() => handleDelete(category)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                              title="Delete Category"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-5 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-xs"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
