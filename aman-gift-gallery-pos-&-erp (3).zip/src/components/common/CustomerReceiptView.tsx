import React, { useEffect, useState } from 'react';
import { Printer, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { fetchInvoiceByNumber } from '../../lib/firebase';
import { db } from '../../db';

export const CustomerReceiptView: React.FC = () => {
  const [bill, setBill] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadBill = async () => {
      try {
        const hash = window.location.hash || '';
        let urlParams = new URLSearchParams(window.location.search);
        let hashParams = new URLSearchParams();
        
        // Handle hash-based routing properly
        if (hash.includes('?')) {
          hashParams = new URLSearchParams(hash.slice(hash.indexOf('?')));
        }
        
        let dataParam = urlParams.get('data') || hashParams.get('data');
        if (!dataParam && hash.includes('?data=')) {
          dataParam = hash.split('?data=')[1].split('&')[0];
        }

        if (dataParam) {
          try {
             // Handle if dataParam is already partially decoded or not
             let base64String = dataParam;
             try {
                base64String = decodeURIComponent(dataParam);
             } catch (e) {}
             
             const decodedStr = decodeURIComponent(escape(atob(base64String)));
             const decoded = JSON.parse(decodedStr);
             const mappedBill = {
               invoiceNumber: decoded.inv,
               date: decoded.dt,
               customerName: decoded.c,
               totalAmount: decoded.tot,
               taxAmount: decoded.gst,
               items: (decoded.it || []).map((arr: any) => ({
                 name: arr[0],
                 quantity: arr[1],
                 price: arr[2],
                 total: arr[1] * arr[2]
               }))
             };
             setBill(mappedBill);
             return;
          } catch(err) {
             console.error("Failed to decode inline data", err);
             setError("Unable to load invoice. Please verify the receipt link.");
             return;
          }
        }
        
        // Fallback to fetch from DB
        let invoiceId = '';
        if (hash.startsWith('#/receipt/')) {
          invoiceId = decodeURIComponent(hash.replace('#/receipt/', '').split('?')[0]);
        } else if (hash.startsWith('#/invoice/')) {
          invoiceId = decodeURIComponent(hash.replace('#/invoice/', '').split('?')[0]);
        }
        
        if (invoiceId) {
          let found = await fetchInvoiceByNumber(invoiceId);
          if (!found) {
             found = await db.invoices.where('invoiceNumber').equals(invoiceId).first() as any;
          }
          if (found) {
            setBill(found);
            return;
          }
        }
        
        setError("Unable to load invoice. Please verify the receipt link.");
      } catch (e) {
        console.error('Error parsing bill:', e);
        setError("Unable to load invoice. Please verify the receipt link.");
      }
    };
    loadBill();
  }, []);

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200 text-center max-w-sm w-full">
          <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <p className="text-slate-800 font-semibold mb-2">Error</p>
          <p className="text-slate-600 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  if (!bill) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 text-center">
          <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600 font-medium tracking-wide text-sm uppercase">Loading Bill...</p>
        </div>
      </div>
    );
  }

  const items = bill.items || [];
  const grandTotal = Number(bill.totalAmount || bill.grandTotal || 0);
  
  

  return (
    <div className="min-h-screen bg-slate-100 py-6 px-4 flex flex-col items-center font-sans print:bg-white print:py-0 print:px-0 bg-security-pattern relative">
      
      {/* Prominent Top Action Button */}
      <div className="w-full max-w-2xl mb-4 print:hidden flex justify-end">
        <button
          onClick={() => window.print()}
          className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm transition-all shadow-md active:scale-95"
        >
          <Printer className="w-4 h-4" />
          <span>Print / Save PDF</span>
        </button>
      </div>

      <div className="w-full max-w-2xl bg-white p-6 md:p-10 rounded-2xl shadow-2xl border border-slate-200 text-slate-800 relative overflow-hidden print:shadow-none print:border-none print:p-0 print:rounded-none z-10 mb-20 print:mb-0">
        
        {/* Subtle Watermark */}
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none select-none z-0 overflow-hidden">
          <span className="text-8xl md:text-9xl font-black -rotate-45 whitespace-nowrap tracking-tighter">AMAN GIFT</span>
        </div>

        <div className="relative z-10">
          {/* Header */}
          <div className="text-center pb-6">
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-wider">AMAN GIFT GALLERY</h1>
            <div className="flex items-center justify-center gap-1.5 mt-1 text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <p className="text-[11px] uppercase tracking-widest font-semibold">Verified Digital Tax Invoice</p>
            </div>
          </div>

          {/* Meta Details Grid */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 md:p-5 rounded-xl border border-slate-100 mb-6">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-0.5">Invoice No</p>
              <p className="font-bold text-slate-800 text-sm">{bill.invoiceNumber || 'INV-000'}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-0.5">Date</p>
              <p className="font-bold text-slate-800 text-sm">{bill.date || new Date().toLocaleDateString('en-IN')}</p>
            </div>
            <div className="col-span-1 pt-2 border-t border-slate-200">
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-0.5">Billed To</p>
              <p className="font-bold text-slate-800 text-sm">{bill.customerName || 'Walk-in Customer'}</p>
              {bill.customerPhone && <p className="text-xs text-slate-500 font-medium mt-0.5">{bill.customerPhone}</p>}
            </div>
            <div className="col-span-1 pt-2 border-t border-slate-200 text-right flex flex-col justify-end items-end">
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold mb-1.5">Payment Status</p>
              <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-widest shadow-sm border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" /> PAID
              </span>
            </div>
          </div>

          {/* Mobile-First Itemized List (Hidden on sm+ and print) */}
          <div className="block sm:hidden print:hidden space-y-4 mb-6">
            {items.map((itm: any, i: number) => {
              const qty = Number(itm.quantity || 1);
              const price = Number(itm.price || 0);
              const total = Number(itm.total || (qty * price));

              return (
                <div key={i} className="flex justify-between items-start bg-slate-50 border border-slate-100 p-3.5 rounded-xl">
                  <div className="flex-1 pr-3">
                    <p className="font-bold text-slate-900 text-sm leading-tight mb-1">{itm.name || 'Product'}</p>
                    <p className="text-xs text-slate-500 font-medium">Qty: {qty} &times; ₹{price.toFixed(2)}</p>
                  </div>
                  <div className="text-right flex flex-col justify-between h-full">
                    <p className="font-black text-slate-900 text-sm">₹{total.toFixed(2)}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Desktop & Print Tabular Format */}
          <div className="hidden sm:block print:block mb-6 print:break-inside-avoid">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-y-2 border-slate-200 text-slate-500 text-[10px] uppercase tracking-widest font-bold">
                  <th className="py-3 px-2 w-[55%]">Item</th>
                  <th className="py-3 px-2 text-center w-[15%]">Qty</th>
                  <th className="py-3 px-2 text-right w-[15%]">Rate</th>
                  <th className="py-3 px-2 text-right w-[15%]">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((itm: any, i: number) => {
                  const qty = Number(itm.quantity || 1);
                  const price = Number(itm.price || 0);
                  const total = Number(itm.total || (qty * price));
                  return (
                    <tr key={i} className="group">
                      <td className="py-3 px-2 text-slate-900 font-bold">{itm.name || 'Product'}</td>
                      <td className="py-3 px-2 text-center text-slate-600 font-medium">{qty}</td>
                      <td className="py-3 px-2 text-right text-slate-700 font-medium">₹{price.toFixed(2)}</td>
                      <td className="py-3 px-2 text-right font-black text-slate-900">₹{total.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Summary Breakdown */}
          <div className="flex flex-col items-end space-y-2 text-sm w-full md:w-[60%] ml-auto print:break-inside-avoid">
            <div className="flex justify-between w-full text-slate-500 font-medium">
              <span>{Number(bill.taxAmount) > 0 ? 'Item(s) Subtotal (amount before tax)' : 'Subtotal'}</span>
              <span className="text-slate-800">
                ₹{Number(bill.taxAmount) > 0 
                    ? (grandTotal - Number(bill.taxAmount)).toFixed(2) 
                    : (Number(bill.subTotal) || items.reduce((acc: number, item: any) => acc + (Number(item.total) || (Number(item.quantity) * Number(item.price))), 0)).toFixed(2)}
              </span>
            </div>
            
            {Number(bill.discountAmount) > 0 && (
              <div className="flex justify-between w-full text-emerald-600 font-medium">
                <span>Discount Deductions</span>
                <span>-₹{Number(bill.discountAmount).toFixed(2)}</span>
              </div>
            )}
            
            {Number(bill.taxAmount) > 0 && (
              <>
                <div className="flex justify-between w-full text-slate-500 font-medium">
                  <span>CGST</span>
                  <span className="text-slate-800">₹{(Number(bill.taxAmount) / 2).toFixed(2)}</span>
                </div>
                <div className="flex justify-between w-full text-slate-500 font-medium">
                  <span>SGST</span>
                  <span className="text-slate-800">₹{(Number(bill.taxAmount) / 2).toFixed(2)}</span>
                </div>
              </>
            )}

            <div className="flex justify-between w-full items-center text-xl font-extrabold text-slate-900 border-t-4 border-double border-slate-300 pt-3 mt-3">
              <span className="uppercase tracking-widest text-sm font-black text-slate-800">
                {Number(bill.taxAmount) > 0 ? 'Grand Total (after tax)' : 'Grand Total'}
              </span>
              <span>₹{grandTotal.toFixed(2)}</span>
            </div>
          </div>

          {/* Footer Note */}
          <div className="text-center mt-12 pt-6 border-t border-dashed border-slate-300 print:break-inside-avoid">
            <p className="text-xs font-medium text-slate-600 tracking-wide uppercase">Thank you for shopping with Aman Gift Gallery!</p>
            <p className="text-[10px] text-slate-400 mt-1 font-medium">For queries, contact the store counter.</p>
            <p className="text-[9px] text-slate-300 mt-3 font-mono">This is a system-generated digital invoice.</p>
          </div>

        </div>
      </div>

      {/* Global Print & Utility CSS */}
      <style>{`
        .bg-security-pattern {
          background-image: radial-gradient(#cbd5e1 1px, transparent 1px);
          background-size: 24px 24px;
        }
        @media print {
          @page { margin: 0.5cm; }
          body { 
            background: #fff !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .no-print { display: none !important; }
        }
      `}</style>
    </div>
  );
};
