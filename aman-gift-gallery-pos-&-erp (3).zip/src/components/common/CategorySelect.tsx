import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { CategoryManagerModal } from './CategoryManagerModal';
import { 
  ChevronDown, 
  Plus, 
  SlidersHorizontal, 
  Search, 
  Check, 
  Tag, 
  X,
  Sparkles
} from 'lucide-react';

interface CategorySelectProps {
  value: string;
  onChange: (category: string) => void;
  label?: string;
  required?: boolean;
  className?: string;
  idPrefix?: string;
}

export const CategorySelect: React.FC<CategorySelectProps> = ({
  value,
  onChange,
  label = 'Category *',
  required = false,
  className = '',
  idPrefix = 'category-select'
}) => {
  const { masterCategories, addCategory } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [isManagerOpen, setIsManagerOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingInline, setIsAddingInline] = useState(false);
  const [inlineNewCategory, setInlineNewCategory] = useState('');
  
  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setIsAddingInline(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter categories based on search term
  const filteredCategories = masterCategories.filter(cat => 
    cat.toLowerCase().includes(searchTerm.toLowerCase().trim())
  );

  const handleSelect = (cat: string) => {
    onChange(cat);
    setIsOpen(false);
    setSearchTerm('');
    setIsAddingInline(false);
  };

  const handleCreateInline = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inlineNewCategory.trim();
    if (!trimmed) return;
    
    await addCategory(trimmed);
    onChange(trimmed);
    setInlineNewCategory('');
    setIsAddingInline(false);
    setIsOpen(false);
  };

  return (
    <div className={`relative ${className}`} ref={containerRef}>
      {/* Label and Actions Bar */}
      <div className="flex justify-between items-center mb-1.5">
        <label className="text-slate-700 font-bold text-xs">
          {label}
        </label>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => {
              setIsOpen(true);
              setIsAddingInline(true);
            }}
            className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 hover:underline flex items-center gap-0.5 cursor-pointer"
          >
            <Plus className="w-3 h-3" />
            <span>Add Category</span>
          </button>
          <span className="text-slate-300">|</span>
          <button
            type="button"
            onClick={() => setIsManagerOpen(true)}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition cursor-pointer"
            title="Manage / Rename / Delete Categories"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Select Button */}
      <button
        id={`${idPrefix}-trigger`}
        type="button"
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen) {
            setTimeout(() => searchInputRef.current?.focus(), 100);
          }
        }}
        className="w-full h-12 bg-slate-50 hover:bg-slate-100/80 focus:bg-white border border-slate-200/90 rounded-2xl px-4 text-slate-900 text-xs sm:text-sm font-bold flex items-center justify-between gap-2 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition cursor-pointer"
      >
        <div className="flex items-center gap-2 min-w-0">
          <Tag className="w-4 h-4 text-indigo-500 shrink-0" />
          <span className="truncate">
            {value || <span className="text-slate-400 font-normal">Select Category</span>}
          </span>
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown Popover */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden text-xs animate-in fade-in zoom-in-95">
          {/* Search Box */}
          <div className="p-2.5 border-b border-slate-100 bg-slate-50/70 flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search or type category..."
              className="w-full bg-transparent text-xs text-slate-800 font-medium placeholder-slate-400 focus:outline-hidden"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && filteredCategories.length === 1) {
                  e.preventDefault();
                  handleSelect(filteredCategories[0]);
                }
              }}
            />
            {searchTerm && (
              <button 
                type="button"
                onClick={() => setSearchTerm('')}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Inline Add Form (if opened via Add or if search has no exact match) */}
          {isAddingInline ? (
            <form onSubmit={handleCreateInline} className="p-2.5 border-b border-indigo-100 bg-indigo-50/60 flex gap-2">
              <input
                type="text"
                value={inlineNewCategory}
                onChange={(e) => setInlineNewCategory(e.target.value)}
                placeholder="New Category Name..."
                className="flex-1 h-8 bg-white border border-indigo-300 rounded-lg px-2.5 text-xs text-slate-900 font-bold focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                autoFocus
              />
              <button
                type="submit"
                disabled={!inlineNewCategory.trim()}
                className="h-8 px-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-bold rounded-lg text-xs flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Save</span>
              </button>
              <button
                type="button"
                onClick={() => setIsAddingInline(false)}
                className="h-8 px-2 text-slate-500 hover:text-slate-800"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </form>
          ) : (
            <div className="p-1.5 border-b border-slate-100 bg-slate-50/40 flex items-center justify-between px-3">
              <button
                type="button"
                onClick={() => setIsAddingInline(true)}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 cursor-pointer py-1"
              >
                <Plus className="w-3 h-3" />
                <span>Create New Category</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  setIsManagerOpen(true);
                }}
                className="text-[11px] font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <SlidersHorizontal className="w-3 h-3" />
                <span>Manage</span>
              </button>
            </div>
          )}

          {/* Categories List */}
          <div className="max-h-52 overflow-y-auto p-1.5 space-y-0.5">
            {filteredCategories.length > 0 ? (
              filteredCategories.map((cat) => {
                const isSelected = value?.toLowerCase() === cat.toLowerCase();
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => handleSelect(cat)}
                    className={`w-full text-left px-3 py-2 rounded-xl flex items-center justify-between text-xs font-bold transition cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/80'
                        : 'text-slate-700 hover:bg-slate-100/80'
                    }`}
                  >
                    <span>{cat}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                  </button>
                );
              })
            ) : (
              <div className="p-3 text-center space-y-2">
                <p className="text-slate-400 text-xs">No matching category found</p>
                <button
                  type="button"
                  onClick={() => {
                    setInlineNewCategory(searchTerm);
                    setIsAddingInline(true);
                  }}
                  className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold inline-flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add "{searchTerm}"</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Category Manager Modal */}
      <CategoryManagerModal
        isOpen={isManagerOpen}
        onClose={() => setIsManagerOpen(false)}
        onSelectCategory={(cat) => onChange(cat)}
      />
    </div>
  );
};
