import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { getTranslation } from '../../utils/translations';
import { ShopProfile, InvoiceTemplateType } from '../../types';
import { db } from '../../db';
import { SecuritySettingsSection } from '../security/SecuritySettingsSection';
import { CloudSyncSection } from '../sync/CloudSyncSection';
import { 
  Settings, 
  Store, 
  Printer, 
  FileText, 
  ShieldCheck, 
  Database, 
  Check, 
  Download, 
  Upload, 
  Trash2,
  Image as ImageIcon,
  PenTool,
  RotateCcw,
  Sparkles,
  Eye,
  Building,
  CreditCard,
  Phone,
  Mail,
  MapPin,
  FileCheck,
  AlertTriangle,
  X,
  RefreshCw
} from 'lucide-react';

export const SettingsModule: React.FC = () => {
  const { 
    shopProfile, 
    updateShopProfile, 
    selectedTemplate, 
    setSelectedTemplate, 
    language,
    playBeep,
    wipeAllData,
    products,
    showNotification
  } = useApp();

  const t = getTranslation(language);
  const [formData, setFormData] = useState<ShopProfile>({ ...shopProfile });
  const [isSaved, setIsSaved] = useState(false);
  const [signatureMode, setSignatureMode] = useState<'upload' | 'draw'>('upload');
  const [isDrawing, setIsDrawing] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Wipe Data Modal & Processing State
  const [isWipeConfirmOpen, setIsWipeConfirmOpen] = useState(false);
  const [isWiping, setIsWiping] = useState(false);
  const [wipeSuccessMessage, setWipeSuccessMessage] = useState<string | null>(null);

  const logoInputRef = useRef<HTMLInputElement>(null);
  const sigInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);

  // Sync formData when shopProfile changes from external sources
  useEffect(() => {
    setFormData({ ...shopProfile });
  }, [shopProfile]);

  // Handle immediate field change and auto-save
  const handleChange = (field: keyof ShopProfile, value: string) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    updateShopProfile({ [field]: value });
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    await updateShopProfile(formData);
    playBeep('success');
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  // Process Logo Upload
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Scale down large images to max 600px width/height for fast IndexedDB storage
        const canvas = document.createElement('canvas');
        const maxDim = 500;
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/png', 0.9);
          handleChange('logoUrl', dataUrl);
          playBeep('success');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    // Reset input
    if (logoInputRef.current) logoInputRef.current.value = '';
  };

  const handleRemoveLogo = () => {
    handleChange('logoUrl', '');
    playBeep('scan');
  };

  // Process Signature Photo Upload
  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 400;
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/png', 0.9);
          handleChange('signatureUrl', dataUrl);
          playBeep('success');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    if (sigInputRef.current) sigInputRef.current.value = '';
  };

  const handleRemoveSignature = () => {
    handleChange('signatureUrl', '');
    playBeep('scan');
  };

  // Canvas Drawing Handlers for Digital Signature
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = '#1e3a8a'; // Deep navy blue ink
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignatureCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const saveDrawnSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    handleChange('signatureUrl', dataUrl);
    playBeep('success');
  };

  // Full Database Backup Export
  const handleExportBackup = async () => {
    const products = await db.products.toArray();
    const invoices = await db.invoices.toArray();
    const purchases = await db.purchases.toArray();
    const parties = await db.parties.toArray();
    const khata = await db.khataTransactions.toArray();
    const wastage = await db.wastage.toArray();

    const backupData = {
      version: '2.5',
      exportDate: new Date().toISOString(),
      shopProfile: formData,
      products,
      invoices,
      purchases,
      parties,
      khataTransactions: khata,
      wastage
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Aman_Gift_Gallery_Full_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    playBeep('success');
  };

  // Full Database Backup Restore
  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const backup = JSON.parse(text);

      if (backup.shopProfile) {
        await updateShopProfile(backup.shopProfile);
        setFormData(backup.shopProfile);
      }

      if (Array.isArray(backup.products) && backup.products.length > 0) {
        await db.products.clear();
        await db.products.bulkAdd(backup.products);
      }

      if (Array.isArray(backup.invoices) && backup.invoices.length > 0) {
        await db.invoices.clear();
        await db.invoices.bulkAdd(backup.invoices);
      }

      if (Array.isArray(backup.parties) && backup.parties.length > 0) {
        await db.parties.clear();
        await db.parties.bulkAdd(backup.parties);
      }

      setImportStatus('✓ Backup data restored successfully!');
      playBeep('success');
      setTimeout(() => setImportStatus(null), 4000);
    } catch (err) {
      console.error('Backup import error:', err);
      setImportStatus('❌ Invalid backup JSON file format.');
      playBeep('alert');
    }

    if (backupInputRef.current) backupInputRef.current.value = '';
  };

  // Wipe All Store Data & Fresh Start Handler
  const handleWipeAllData = async () => {
    try {
      setIsWiping(true);
      await wipeAllData();
      setIsWiping(false);
      setIsWipeConfirmOpen(false);
      setWipeSuccessMessage('✓ All products, sales, and expense records have been wiped. You have a fresh 0-item start!');
      setTimeout(() => setWipeSuccessMessage(null), 5000);
    } catch (err) {
      console.error('Failed to wipe store data:', err);
      setIsWiping(false);
      setIsWipeConfirmOpen(false);
    }
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-5xl mx-auto overflow-y-auto bg-slate-50">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-red-600" />
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Shop Settings & Profile
            </h2>
            <span className="px-2 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-bold rounded-full">
              ⚡ Instant Live Sync Active
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {language === 'hi' 
              ? 'दुकान का नाम, लोगो, डिजिटल हस्ताक्षर, पता, जीएसटी, बिल फुटर व इनवॉइस टेम्प्लेट कस्टमाइज़ करें' 
              : 'Customize store name, official logo, digital signature, address, GSTIN, and print templates'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Backup Restore */}
          <input 
            type="file" 
            ref={backupInputRef} 
            onChange={handleImportBackup} 
            accept=".json" 
            className="hidden" 
          />
          <button
            type="button"
            onClick={() => backupInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer"
            title="Import previously saved JSON backup"
          >
            <Upload className="w-3.5 h-3.5 text-slate-600" />
            <span>{language === 'hi' ? 'रिस्टोर करें' : 'Restore'}</span>
          </button>

          {/* Backup Export */}
          <button
            type="button"
            onClick={handleExportBackup}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 transition cursor-pointer shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-red-600" />
            <span>{language === 'hi' ? 'बैकअप डाउनलोड' : 'Export DB Backup'}</span>
          </button>

          {/* Wipe All Data / Fresh Start Red Button */}
          <button
            type="button"
            id="btn-wipe-all-data-header"
            onClick={() => setIsWipeConfirmOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold rounded-xl transition cursor-pointer shadow-xs active:scale-95"
            title="Wipe all inventory, sales, expenses and start with a fresh slate"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Wipe All Data / Fresh Start</span>
          </button>
        </div>
      </div>

      {wipeSuccessMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 shadow-xs">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{wipeSuccessMessage}</span>
        </div>
      )}

      {importStatus && (
        <div className={`p-3.5 rounded-xl border text-xs font-bold ${
          importStatus.startsWith('✓') 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          {importStatus}
        </div>
      )}

      {/* Live Brand Identity Preview Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-slate-700/80 mb-4">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-red-400" />
            <span className="text-xs font-extrabold uppercase tracking-wider text-slate-300">
              Live Brand & Header Preview (Updates Navbar & Invoices in Real-Time)
            </span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            {formData.city}, {formData.state}
          </span>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {/* Logo display */}
            {formData.logoUrl ? (
              <div className="w-16 h-16 rounded-2xl bg-white p-1 flex items-center justify-center shadow-md overflow-hidden shrink-0 border border-slate-200">
                <img 
                  src={formData.logoUrl} 
                  alt="Shop Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center shadow-md text-white font-black text-2xl shrink-0">
                <Store className="w-8 h-8" />
              </div>
            )}

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black tracking-tight text-white">
                  {formData.name || 'Store Name'}
                </h3>
                <span className="px-2 py-0.5 bg-red-500/30 border border-red-400/40 text-red-200 text-[10px] font-bold rounded-full">
                  POS Live
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium mt-0.5">
                {formData.tagline || 'Store tagline will appear here'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                📍 {formData.address || 'Address'}, {formData.city} • 📞 {formData.phone}
              </p>
            </div>
          </div>

          {/* Signature badge */}
          {formData.signatureUrl && (
            <div className="bg-white/10 backdrop-blur-xs border border-white/10 rounded-xl p-2.5 text-right shrink-0">
              <div className="h-9 w-28 ml-auto flex items-center justify-end">
                <img 
                  src={formData.signatureUrl} 
                  alt="Signature" 
                  className="max-h-full max-w-full object-contain filter brightness-110"
                />
              </div>
              <p className="text-[9px] text-slate-300 font-medium mt-1">Authorized Digital Signatory</p>
            </div>
          )}
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* 1. Shop Identity & Contact Details */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <Store className="w-4 h-4 text-red-600" />
            <span>{language === 'hi' ? 'दुकान पहचान व संपर्क' : 'Store Identity & Contact Details'}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-600 font-bold block mb-1">
                Store Legal / Trade Name * <span className="text-[10px] text-red-500 font-normal">(Instant Live Preview)</span>
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="e.g. Aman Gift Gallery"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-extrabold focus:bg-white focus:border-red-600 focus:outline-hidden text-sm"
              />
            </div>

            <div>
              <label className="text-slate-600 font-bold block mb-1">
                Tagline / Subtitle <span className="text-[10px] text-red-500 font-normal">(Instant Live Preview)</span>
              </label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => handleChange('tagline', e.target.value)}
                placeholder="e.g. An Exclusive Gift, Crockery, Toy & Home Essentials Gallery"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-bold block mb-1">Primary Mobile / WhatsApp No. *</label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                placeholder="+91 98351 23456"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-mono font-semibold focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1">Alternate Phone / Landline</label>
              <input
                type="text"
                value={formData.altPhone || ''}
                onChange={(e) => handleChange('altPhone', e.target.value)}
                placeholder="+91 94311 78900"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-mono focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1">Official Email Address</label>
              <input
                type="email"
                value={formData.email || ''}
                onChange={(e) => handleChange('email', e.target.value)}
                placeholder="amangiftgallery.ranchi@gmail.com"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-600 font-medium">GSTIN Number</label>
                <span className="text-[11px] text-slate-400 font-semibold px-1.5 py-0.2 bg-slate-100 rounded">Optional</span>
              </div>
              <input
                type="text"
                value={formData.gstin || ''}
                onChange={(e) => handleChange('gstin', e.target.value.toUpperCase().trim())}
                placeholder="e.g. 20AAAAA0000A1Z5 (Leave blank if not registered)"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 font-mono uppercase font-bold focus:bg-white focus:border-red-600 focus:outline-hidden text-xs sm:text-sm"
              />
              <p className="text-[10px] text-slate-500 mt-1 font-medium">
                {language === 'hi' 
                  ? 'यदि आपके पास GSTIN नहीं है तो खाली छोड़ दें। बिल डिफ़ॉल्ट रूप से कैश मेमो / रिटेल इनवॉइस बनेगा।' 
                  : 'Leave blank if unregistered. Bills will default cleanly to Retail Invoice / Cash Memo.'}
              </p>
            </div>

            <div className="sm:col-span-2">
              <label className="text-slate-600 font-medium block mb-1">Store Address / Street Location</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => handleChange('address', e.target.value)}
                placeholder="Shop No. 12-14, Upper Bazar, Main Road"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1">City</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => handleChange('city', e.target.value)}
                placeholder="Ranchi"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-slate-600 font-medium block mb-1">State</label>
                <input
                  type="text"
                  value={formData.state}
                  onChange={(e) => handleChange('state', e.target.value)}
                  placeholder="Jharkhand"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium block mb-1">Pincode</label>
                <input
                  type="text"
                  value={formData.pincode}
                  onChange={(e) => handleChange('pincode', e.target.value)}
                  placeholder="834001"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono focus:bg-white focus:border-red-600 focus:outline-hidden"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 2. Logo & Store Branding Uploader */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-red-600" />
                <span>{language === 'hi' ? 'दुकान का लोगो व ब्रांडिंग' : 'Shop Logo & Brand Identity'}</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'hi' 
                  ? 'अपलोड किया गया लोगो टॉप नेवबार, डैशबोर्ड और सभी प्रिंटेड इनवॉइस PDF में दिखेगा' 
                  : 'Uploaded logo renders on top navbar, Dashboard header, and all printed Invoice PDFs'}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-slate-50 border border-slate-200 rounded-xl">
            {/* Logo Preview Container */}
            <div className="flex flex-col items-center gap-2">
              <div className="w-28 h-28 rounded-2xl border-2 border-dashed border-slate-300 bg-white flex items-center justify-center p-2 shadow-xs overflow-hidden">
                {formData.logoUrl ? (
                  <img 
                    src={formData.logoUrl} 
                    alt="Logo Preview" 
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <div className="text-center p-2 text-slate-400">
                    <ImageIcon className="w-8 h-8 mx-auto mb-1 opacity-50" />
                    <span className="text-[10px] font-semibold block leading-tight">No Logo Uploaded</span>
                  </div>
                )}
              </div>
              <span className="text-[10px] text-slate-500 font-medium">
                {formData.logoUrl ? '✓ Active Logo' : 'Preview Box'}
              </span>
            </div>

            {/* Action Buttons & Guidance */}
            <div className="flex-1 space-y-3 text-xs">
              <div>
                <p className="font-bold text-slate-800">Supported formats: PNG, JPG, SVG, WebP</p>
                <p className="text-slate-500 text-[11px] mt-0.5">
                  Recommendation: High-resolution PNG or SVG with transparent or white background for best print results.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <input 
                  type="file" 
                  ref={logoInputRef} 
                  onChange={handleLogoUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
                
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="flex items-center gap-1.5 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-md shadow-red-600/20 transition cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{formData.logoUrl ? 'Change Shop Logo' : '🖼️ Upload Shop Logo'}</span>
                </button>

                {formData.logoUrl && (
                  <button
                    type="button"
                    onClick={handleRemoveLogo}
                    className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-red-50 text-red-600 hover:text-red-700 font-semibold text-xs rounded-xl border border-red-200 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove Logo</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 3. Digital Signature Uploader & Drawing Canvas */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <PenTool className="w-4 h-4 text-red-600" />
                <span>{language === 'hi' ? 'डिजिटल हस्ताक्षर (Authorized Signatory)' : 'Digital Signature & Stamp'}</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'hi' 
                  ? 'दुकानदार का डिजिटल हस्ताक्षर इनवॉइस के नीचे "Authorized Signatory" में प्रिंट होगा' 
                  : 'Manager / Cashier signature stamped automatically at the bottom of customer receipts'}
              </p>
            </div>

            {/* Mode Switcher */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setSignatureMode('upload')}
                className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                  signatureMode === 'upload' 
                    ? 'bg-white text-slate-900 shadow-xs' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Upload Photo
              </button>
              <button
                type="button"
                onClick={() => setSignatureMode('draw')}
                className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                  signatureMode === 'draw' 
                    ? 'bg-white text-slate-900 shadow-xs' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Draw on Pad
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-slate-50 border border-slate-200 rounded-xl">
            {/* Mode 1: Upload Photo */}
            {signatureMode === 'upload' && (
              <div className="space-y-3 text-xs">
                <p className="font-bold text-slate-800">Option A: Upload Signature Image</p>
                <p className="text-slate-500 text-[11px]">
                  Upload a photo or scanned PNG of your signature (auto-transparency supported).
                </p>

                <input 
                  type="file" 
                  ref={sigInputRef} 
                  onChange={handleSignatureUpload} 
                  accept="image/*" 
                  className="hidden" 
                />

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => sigInputRef.current?.click()}
                    className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Signature Photo</span>
                  </button>

                  {formData.signatureUrl && (
                    <button
                      type="button"
                      onClick={handleRemoveSignature}
                      className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-red-50 text-red-600 font-semibold text-xs rounded-xl border border-red-200 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Mode 2: Interactive HTML5 Canvas Drawing Pad */}
            {signatureMode === 'draw' && (
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <p className="font-bold text-slate-800">Option B: Sign on Touch Pad / Mouse</p>
                  <span className="text-[10px] text-blue-700 font-semibold bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                    Navy Ink Pen
                  </span>
                </div>

                <div className="border border-slate-300 bg-white rounded-xl overflow-hidden shadow-inner">
                  <canvas
                    ref={canvasRef}
                    width={320}
                    height={110}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    className="w-full h-28 cursor-crosshair touch-none"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={saveDrawnSignature}
                    className="flex items-center gap-1 px-3.5 py-1.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Save Drawn Signature</span>
                  </button>

                  <button
                    type="button"
                    onClick={clearSignatureCanvas}
                    className="flex items-center gap-1 px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl transition cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Clear Pad</span>
                  </button>
                </div>
              </div>
            )}

            {/* Live Transparent Signature Receipt Preview */}
            <div className="flex flex-col justify-center border-t md:border-t-0 md:border-l border-slate-200 pt-4 md:pt-0 md:pl-6 space-y-2">
              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                Live Bill Receipt Stamp Preview
              </span>
              
              <div className="bg-white border border-slate-200 rounded-xl p-3 text-right space-y-1 shadow-xs">
                {formData.signatureUrl ? (
                  <div className="h-12 flex items-center justify-end">
                    <img 
                      src={formData.signatureUrl} 
                      alt="Active Signature" 
                      className="max-h-full max-w-[140px] object-contain ml-auto"
                    />
                  </div>
                ) : (
                  <div className="h-12 flex items-center justify-end text-xs italic text-slate-400">
                    (No signature registered)
                  </div>
                )}
                <p className="font-extrabold text-xs text-slate-900">
                  For {formData.name || 'Your Store Name'}
                </p>
                <p className="text-[10px] text-slate-500">Authorized Signatory</p>
              </div>
            </div>
          </div>
        </div>

        {/* 4. Bank & UPI Payment Details */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-red-600" />
            <span>{language === 'hi' ? 'बैंक खाता व UPI विवरण' : 'Bank Account & UPI Payment Details'}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="text-slate-600 font-medium block mb-1">Bank Name & Branch</label>
              <input
                type="text"
                value={formData.bankName || ''}
                onChange={(e) => handleChange('bankName', e.target.value)}
                placeholder="State Bank of India (Main Branch)"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1">Account Number</label>
              <input
                type="text"
                value={formData.accountNo || ''}
                onChange={(e) => handleChange('accountNo', e.target.value)}
                placeholder="30491823901"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1">IFSC Code</label>
              <input
                type="text"
                value={formData.ifscCode || ''}
                onChange={(e) => handleChange('ifscCode', e.target.value.toUpperCase())}
                placeholder="SBIN0000167"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono uppercase focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="text-slate-600 font-medium block mb-1">UPI ID (For Instant Customer Payment)</label>
              <input
                type="text"
                value={formData.upiId || ''}
                onChange={(e) => handleChange('upiId', e.target.value)}
                placeholder="amangifts.ranchi@sbi"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono focus:bg-white focus:border-red-600 focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* 5. Invoice Customization & Templates */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
            <FileText className="w-4 h-4 text-red-600" />
            <span>{language === 'hi' ? 'डिफ़ॉल्ट इनवॉइस टेम्प्लेट' : 'Default Print Template Selection'}</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { id: 'navy', title: 'Modern Navy Blue', desc: 'Corporate table with headers & QR' },
              { id: 'minimal', title: 'Minimal Slate', desc: 'Monochrome sleek format' },
              { id: 'bold', title: 'Retail Bold Promo', desc: 'Mint header with savings focus' },
              { id: 'thermal', title: 'Thermal 3" Slip', desc: '58mm/80mm ticket roll' }
            ].map((tmpl) => {
              const isSelected = selectedTemplate === tmpl.id;
              return (
                <div
                  key={tmpl.id}
                  onClick={() => setSelectedTemplate(tmpl.id as InvoiceTemplateType)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition space-y-1 ${
                    isSelected
                      ? 'bg-red-50/80 border-red-600 shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <p className="font-bold text-xs text-slate-900">{tmpl.title}</p>
                  <p className="text-[10px] text-slate-500 font-medium">{tmpl.desc}</p>
                  {isSelected && <span className="text-[10px] text-red-600 font-black block mt-2">✓ Active Default</span>}
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-200 text-xs">
            <label className="text-slate-600 font-medium block mb-1">Standard Bill Footer Terms & Conditions:</label>
            <textarea
              rows={2}
              value={formData.footerDisclaimer}
              onChange={(e) => handleChange('footerDisclaimer', e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:bg-white focus:border-red-600 focus:outline-hidden"
            />
          </div>
        </div>

        {/* 6. Security & Master PIN Lock */}
        <SecuritySettingsSection language={language} showNotification={showNotification} />

        {/* 7. Cloud Data Sync & Multi-Device Account */}
        <CloudSyncSection language={language} />

        {/* 8. Danger Zone / Wipe All Data */}
        <div className="bg-rose-50/80 border border-rose-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="font-bold text-base text-rose-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>{language === 'hi' ? 'डेटा रीसेट व फ्रेश स्टार्ट' : 'Wipe All Store Data / Fresh Start'}</span>
              </h3>
              <p className="text-xs text-rose-700/90 font-medium">
                {language === 'hi'
                  ? 'सभी उत्पाद, बिल इनवॉइस, खरीद वाउचर व खाता लेज़र तुरंत 0 कर नया स्टोर शुरू करें।'
                  : 'Permanently wipe all products (products=[]), sales invoices (sales=[]), and purchases/expenses (expenses=[]). Refreshes state to 0 items immediately.'}
              </p>
            </div>

            <button
              type="button"
              id="btn-wipe-all-data-danger-zone"
              onClick={() => setIsWipeConfirmOpen(true)}
              className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-rose-600/25 transition cursor-pointer shrink-0 active:scale-95"
            >
              <Trash2 className="w-4 h-4" />
              <span>Wipe All Data / Fresh Start</span>
            </button>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center gap-3">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-red-600/30 transition cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>{language === 'hi' ? 'सेटिंग्स सहेजें' : 'Save Store Profile & Preferences'}</span>
          </button>

          {isSaved && (
            <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
              <Check className="w-4 h-4 text-emerald-600" />
              Settings saved & live across POS, Invoices & Reports!
            </span>
          )}
        </div>
      </form>

      {/* Confirmation Modal for Wiping All Data */}
      {isWipeConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            id="modal-wipe-confirmation"
            className="bg-white rounded-3xl border border-rose-200 max-w-md w-full p-6 shadow-2xl space-y-5 animate-in zoom-in-95 duration-200"
          >
            <div className="flex items-start justify-between">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-200 flex items-center justify-center text-rose-600 shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <button
                type="button"
                onClick={() => setIsWipeConfirmOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Wipe All Store Data / Fresh Start?
              </h3>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                This action will completely clear all local database records and reset your inventory and financial history to a clean 0-item slate:
              </p>
              
              <ul className="text-xs text-rose-800 bg-rose-50 border border-rose-100 rounded-2xl p-3.5 space-y-1.5 font-semibold">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Products Inventory</strong> → products = [] (0 items)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Sales Invoices & Billing</strong> → sales = [] (0 bills)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Purchases & Expenses</strong> → expenses = [] (0 vouchers)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                  <span><strong>Customer & Supplier Khata</strong> → all balances cleared</span>
                </li>
              </ul>

              <p className="text-[11px] text-slate-500 italic">
                Tip: You can export a JSON backup beforehand using the &quot;Export DB Backup&quot; button above.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsWipeConfirmOpen(false)}
                disabled={isWiping}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                type="button"
                id="btn-confirm-wipe-all-data"
                onClick={handleWipeAllData}
                disabled={isWiping}
                className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition cursor-pointer active:scale-95 disabled:opacity-50"
              >
                {isWiping ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Wiping Database...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4" />
                    <span>Yes, Wipe All Data</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
