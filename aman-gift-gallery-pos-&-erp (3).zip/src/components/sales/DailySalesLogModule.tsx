import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { db } from '../../db';
import { Invoice, PaymentMethod, CartItem, Product } from '../../types';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { generateWhatsAppLink } from '../../utils/invoiceGenerator';
import { 
  Calendar, 
  CalendarDays, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  Plus, 
  Receipt, 
  TrendingUp, 
  IndianRupee, 
  ShoppingCart, 
  CreditCard, 
  Smartphone, 
  Banknote, 
  Users2, 
  Eye, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  AlertCircle, 
  AlertTriangle,
  RefreshCw,
  Clock,
  Sparkles,
  ArrowUpRight,
  Send,
  X,
  PackageCheck
} from 'lucide-react';

export const DailySalesLogModule: React.FC = () => {
  const { products, setActiveInvoicePreview, playBeep, refreshData, shopProfile, deleteInvoice } = useApp();

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  
  // Date filtering state
  const todayStr = new Date().toISOString().split('T')[0];
  const [dateFilterType, setDateFilterType] = useState<'today' | 'yesterday' | 'last7' | 'this_month' | 'custom'>('today');
  const [customStartDate, setCustomStartDate] = useState<string>(todayStr);
  const [customEndDate, setCustomEndDate] = useState<string>(todayStr);
  
  // Search and payment filter
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  
  // Expanded dates map
  const [expandedDates, setExpandedDates] = useState<Record<string, boolean>>({});

  // Delete Invoice Confirmation Modal & Toast State
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Auto-dismiss toast timer
  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      setToastMessage(null);
    }, 4500);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  // Quick Manual Sale Modal state
  const [isManualSaleModalOpen, setIsManualSaleModalOpen] = useState<boolean>(false);
  const [manualDate, setManualDate] = useState<string>(todayStr);
  const [manualCustomer, setManualCustomer] = useState<string>('');
  const [manualPhone, setManualPhone] = useState<string>('');
  const [manualItemName, setManualItemName] = useState<string>('');
  const [manualQty, setManualQty] = useState<number>(1);
  const [manualPrice, setManualPrice] = useState<number>(500);
  const [manualPayment, setManualPayment] = useState<PaymentMethod>('cash');
  const [manualNotes, setManualNotes] = useState<string>('Manual Counter Entry');
  const [isSubmittingManual, setIsSubmittingManual] = useState<boolean>(false);

  // Load invoices from IndexedDB
  const loadInvoices = async () => {
    try {
      setLoading(true);
      const allInvs = await db.invoices.toArray();
      // Sort descending by date, then time / createdAt
      allInvs.sort((a, b) => {
        const dateComp = (b.date || '').localeCompare(a.date || '');
        if (dateComp !== 0) return dateComp;
        return (b.createdAt || '').localeCompare(a.createdAt || '');
      });
      setInvoices(allInvs);
      
      // Auto-expand the most recent date by default
      if (allInvs.length > 0) {
        const firstDate = allInvs[0].date;
        setExpandedDates({ [firstDate]: true, [todayStr]: true });
      }
    } catch (err) {
      console.error('Error loading invoices in DailySalesLog:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, [products]);

  // Compute active date boundaries based on dateFilterType
  const { startDate, endDate } = useMemo(() => {
    const now = new Date();
    if (dateFilterType === 'today') {
      return { startDate: todayStr, endDate: todayStr };
    }
    if (dateFilterType === 'yesterday') {
      const y = new Date(now);
      y.setDate(y.getDate() - 1);
      const yStr = y.toISOString().split('T')[0];
      return { startDate: yStr, endDate: yStr };
    }
    if (dateFilterType === 'last7') {
      const past = new Date(now);
      past.setDate(past.getDate() - 6);
      return { startDate: past.toISOString().split('T')[0], endDate: todayStr };
    }
    if (dateFilterType === 'this_month') {
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      return { startDate: firstDay, endDate: todayStr };
    }
    return { startDate: customStartDate, endDate: customEndDate };
  }, [dateFilterType, todayStr, customStartDate, customEndDate]);

  // Filter invoices based on date range, search query, and payment filter
  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      // Date boundary check
      if (inv.date < startDate || inv.date > endDate) {
        return false;
      }
      // Payment filter check
      if (paymentFilter !== 'all' && inv.paymentMethod !== paymentFilter) {
        return false;
      }
      // Search query check
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesInvoice = inv.invoiceNumber.toLowerCase().includes(q);
        const matchesCustomer = (inv.customerName || '').toLowerCase().includes(q);
        const matchesPhone = (inv.customerPhone || '').includes(q);
        const matchesItem = inv.items.some(item => item.product.name.toLowerCase().includes(q));
        if (!matchesInvoice && !matchesCustomer && !matchesPhone && !matchesItem) {
          return false;
        }
      }
      return true;
    });
  }, [invoices, startDate, endDate, paymentFilter, searchQuery]);

  // Group filtered invoices by date (YYYY-MM-DD)
  const groupedByDate = useMemo(() => {
    const map: Record<string, Invoice[]> = {};
    for (const inv of filteredInvoices) {
      const d = inv.date || todayStr;
      if (!map[d]) {
        map[d] = [];
      }
      map[d].push(inv);
    }
    // Return entries sorted descending by date
    return Object.entries(map).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filteredInvoices, todayStr]);

  // Aggregate high-level summary KPIs for the active filter view
  const summaryKpis = useMemo(() => {
    let totalRevenue = 0;
    let totalProfit = 0;
    let totalGst = 0;
    let totalItemsCount = 0;
    const paymentTotals = {
      cash: 0,
      upi: 0,
      card: 0,
      khata: 0
    };

    for (const inv of filteredInvoices) {
      totalRevenue += inv.grandTotal;
      totalProfit += (inv.cashierProfit || 0);
      totalGst += (inv.totalGst || 0);
      for (const item of inv.items) {
        totalItemsCount += Math.abs(item.quantity);
      }
      const pm = inv.paymentMethod || 'cash';
      if (pm === 'cash') paymentTotals.cash += inv.grandTotal;
      else if (pm === 'upi') paymentTotals.upi += inv.grandTotal;
      else if (pm === 'card') paymentTotals.card += inv.grandTotal;
      else if (pm === 'khata') paymentTotals.khata += inv.grandTotal;
    }

    const avgTicketSize = filteredInvoices.length > 0 ? Math.round(totalRevenue / filteredInvoices.length) : 0;
    const profitMargin = totalRevenue > 0 ? Math.round((totalProfit / totalRevenue) * 100) : 0;

    return {
      totalRevenue,
      totalProfit,
      totalGst,
      totalInvoices: filteredInvoices.length,
      totalItemsCount,
      avgTicketSize,
      profitMargin,
      paymentTotals
    };
  }, [filteredInvoices]);

  // Toggle date accordion
  const toggleDateAccordion = (dateStr: string) => {
    setExpandedDates(prev => ({
      ...prev,
      [dateStr]: !prev[dateStr]
    }));
  };

  // Expand all / Collapse all
  const expandAllDates = () => {
    const next: Record<string, boolean> = {};
    groupedByDate.forEach(([date]) => {
      next[date] = true;
    });
    setExpandedDates(next);
  };

  const collapseAllDates = () => {
    setExpandedDates({});
  };

  // Open Delete Confirmation Dialog
  const handleOpenDeleteDialog = (inv: Invoice) => {
    setInvoiceToDelete(inv);
    playBeep('alert');
  };

  // Confirm Delete & Restore Stock
  const handleConfirmDeleteInvoice = async () => {
    if (!invoiceToDelete) return;
    const invNum = invoiceToDelete.invoiceNumber;
    const invId = invoiceToDelete.id;

    try {
      setIsDeleting(true);
      await deleteInvoice(invId || invNum);

      // Immediately remove from local state to recalculate all daily totals & KPIs instantaneously
      setInvoices(prev => prev.filter(i => (invId ? i.id !== invId : i.invoiceNumber !== invNum)));

      playBeep('success');
      setToastMessage(`✅ Invoice #${invNum} deleted and stock restored successfully.`);
      setInvoiceToDelete(null);
    } catch (e) {
      console.error('Failed to delete invoice and restore stock:', e);
      alert(`Failed to delete invoice #${invNum}. Please try again.`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Manual Counter Sale submit
  const handleSaveManualSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (manualPrice <= 0 || manualQty <= 0) {
      alert('Please enter valid sale amount and quantity.');
      return;
    }

    try {
      setIsSubmittingManual(true);
      const totalAmount = manualPrice * manualQty;
      const gstAmount = Math.round(totalAmount * 0.18);
      const taxable = totalAmount - gstAmount;
      const landingEst = Math.round(manualPrice * 0.7);
      const profitEst = totalAmount - (landingEst * manualQty);
      const invNum = `AGG-${new Date(manualDate).getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

      const manualInvoice: Omit<Invoice, 'id'> = {
        invoiceNumber: invNum,
        date: manualDate,
        time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        customerName: manualCustomer.trim() || 'Counter Customer',
        customerPhone: manualPhone.trim(),
        items: [
          {
            product: {
              barcode: `AGG-MAN-${Date.now().toString().slice(-4)}`,
              name: manualItemName.trim() || 'General Gift / Retail Item',
              brand: 'General',
              category: 'General',
              hsn: '999999',
              stockQty: 50,
              minThreshold: 2,
              basicPurchaseRate: landingEst,
              gstPercent: 18,
              landingCost: landingEst,
              mrp: manualPrice,
              sellingPrice: manualPrice,
              createdAt: manualDate,
              updatedAt: manualDate
            },
            quantity: manualQty,
            customPrice: manualPrice,
            discountPercent: 0
          }
        ],
        subtotal: taxable,
        totalDiscount: 0,
        totalGst: gstAmount,
        roundOff: 0,
        grandTotal: totalAmount,
        totalLandingCost: landingEst * manualQty,
        cashierProfit: Math.max(0, profitEst),
        paymentMethod: manualPayment,
        isExchangeBill: false,
        notes: manualNotes,
        template: 'navy',
        showDiscount: true,
        showSavings: true,
        createdAt: new Date(`${manualDate}T12:00:00Z`).toISOString()
      };

      await db.invoices.add(manualInvoice as Invoice);
      playBeep('success');
      setIsManualSaleModalOpen(false);
      
      // Reset form
      setManualCustomer('');
      setManualPhone('');
      setManualItemName('');
      setManualQty(1);
      setManualPrice(500);
      
      await loadInvoices();
    } catch (err) {
      console.error('Error saving manual counter sale:', err);
    } finally {
      setIsSubmittingManual(false);
    }
  };

  // Export Daily Register to CSV
  const handleExportCsv = () => {
    if (filteredInvoices.length === 0) {
      alert('No sales records to export for the selected filter.');
      return;
    }

    const headers = ['Date', 'Time', 'Invoice No', 'Customer Name', 'Phone', 'Items Details', 'Total Qty', 'Payment Method', 'Taxable Value', 'GST Amount', 'Grand Total', 'Profit'];
    const rows = filteredInvoices.map(inv => {
      const itemsStr = inv.items.map(i => `${i.product.name} (x${i.quantity})`).join('; ');
      const totalQty = inv.items.reduce((s, i) => s + Math.abs(i.quantity), 0);
      return [
        inv.date,
        inv.time,
        inv.invoiceNumber,
        `"${(inv.customerName || '').replace(/"/g, '""')}"`,
        inv.customerPhone || '',
        `"${itemsStr.replace(/"/g, '""')}"`,
        totalQty,
        inv.paymentMethod,
        inv.subtotal,
        inv.totalGst,
        inv.grandTotal,
        inv.cashierProfit || 0
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Daily_Sales_Register_${startDate}_to_${endDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    playBeep('success');
  };

  // Format Date for header
  const formatDateHeader = (dateStr: string) => {
    try {
      const [year, month, day] = dateStr.split('-');
      const d = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
      const isToday = dateStr === todayStr;
      const isYesterday = (() => {
        const y = new Date();
        y.setDate(y.getDate() - 1);
        return y.toISOString().split('T')[0] === dateStr;
      })();

      const formatted = d.toLocaleDateString('en-IN', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      if (isToday) return `✨ Today (${formatted})`;
      if (isYesterday) return `Yesterday (${formatted})`;
      return formatted;
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto overflow-y-auto bg-slate-50 select-none">
      {/* Module Title & Header Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white border border-slate-200/80 p-5 rounded-2xl shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-md shadow-indigo-600/20">
              <CalendarDays className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
                <span>Daily Sales Log</span>
                <span className="text-xs px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-full font-bold">
                  दैनिक बिक्री रजिस्टर
                </span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Automatic chronological register of all counter bills, quick-sales, and cash register logs.
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          <button
            type="button"
            id="btn-export-daily-csv"
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          <button
            type="button"
            id="btn-log-manual-sale"
            onClick={() => setIsManualSaleModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-indigo-600/25 transition cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>+ Log Counter Sale</span>
          </button>
        </div>
      </div>

      {/* Date Filter & Search Controls Bar */}
      <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-3">
        {/* Quick Date Presets */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mr-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Date:
            </span>
            {[
              { id: 'today', label: 'Today' },
              { id: 'yesterday', label: 'Yesterday' },
              { id: 'last7', label: 'Last 7 Days' },
              { id: 'this_month', label: 'This Month' },
              { id: 'custom', label: 'Custom Date' }
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setDateFilterType(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  dateFilterType === tab.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={expandAllDates}
              className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition cursor-pointer"
            >
              Expand All
            </button>
            <span className="text-slate-300">|</span>
            <button
              type="button"
              onClick={collapseAllDates}
              className="text-[11px] font-bold text-slate-500 hover:text-slate-700 transition cursor-pointer"
            >
              Collapse All
            </button>
          </div>
        </div>

        {/* Custom Date Inputs (if custom selected) */}
        {dateFilterType === 'custom' && (
          <div className="flex flex-wrap items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl animate-in fade-in">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">From:</span>
              <input
                type="date"
                value={customStartDate}
                onChange={e => setCustomStartDate(e.target.value)}
                className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-600">To:</span>
              <input
                type="date"
                value={customEndDate}
                onChange={e => setCustomEndDate(e.target.value)}
                className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800"
              />
            </div>
          </div>
        )}

        {/* Search Input & Payment Filter */}
        <div className="flex flex-col sm:flex-row items-center gap-3 pt-2 border-t border-slate-100">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Bill #, Customer Name, Phone, or Item Name..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9.5 pr-4 py-2 bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl text-xs text-slate-800 font-medium focus:outline-none transition"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <select
              value={paymentFilter}
              onChange={e => setPaymentFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none cursor-pointer w-full sm:w-auto"
            >
              <option value="all">All Payment Modes</option>
              <option value="cash">💵 Cash Only</option>
              <option value="upi">📱 UPI / QR Only</option>
              <option value="card">💳 Card Only</option>
              <option value="khata">👥 Khata / Credit Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Revenue */}
        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
            <span>Period Revenue</span>
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
              <IndianRupee className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            {formatCurrency(summaryKpis.totalRevenue)}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 font-bold">
            <TrendingUp className="w-3 h-3" />
            <span>Profit: {formatCurrency(summaryKpis.totalProfit)} ({summaryKpis.profitMargin}%)</span>
          </div>
        </div>

        {/* Total Invoices Count */}
        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
            <span>Total Bills Issued</span>
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <Receipt className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            {summaryKpis.totalInvoices} <span className="text-xs font-bold text-slate-400">bills</span>
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            Avg Ticket: <span className="font-bold text-slate-700">{formatCurrency(summaryKpis.avgTicketSize)}</span>
          </div>
        </div>

        {/* Total Units Sold */}
        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1.5">
          <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
            <span>Total Units Sold</span>
            <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
              <ShoppingCart className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            {summaryKpis.totalItemsCount} <span className="text-xs font-bold text-slate-400">items</span>
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            GST Collected: <span className="font-bold text-slate-700">{formatCurrency(summaryKpis.totalGst)}</span>
          </div>
        </div>

        {/* Payment Methods Split */}
        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-2">
          <div className="text-slate-500 text-xs font-bold">Payment Mode Split</div>
          <div className="grid grid-cols-2 gap-1.5 text-[11px]">
            <div className="flex items-center justify-between px-2 py-1 bg-emerald-50 text-emerald-800 rounded-lg font-bold">
              <span>UPI:</span>
              <span>{formatCurrency(summaryKpis.paymentTotals.upi)}</span>
            </div>
            <div className="flex items-center justify-between px-2 py-1 bg-amber-50 text-amber-800 rounded-lg font-bold">
              <span>Cash:</span>
              <span>{formatCurrency(summaryKpis.paymentTotals.cash)}</span>
            </div>
            <div className="flex items-center justify-between px-2 py-1 bg-blue-50 text-blue-800 rounded-lg font-bold">
              <span>Card:</span>
              <span>{formatCurrency(summaryKpis.paymentTotals.card)}</span>
            </div>
            <div className="flex items-center justify-between px-2 py-1 bg-purple-50 text-purple-800 rounded-lg font-bold">
              <span>Khata:</span>
              <span>{formatCurrency(summaryKpis.paymentTotals.khata)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grouped Date-by-Date Register Stream */}
      <div className="space-y-4">
        {groupedByDate.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-3 shadow-xs">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
              <Calendar className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-black text-slate-800">No Sales Records Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No bills match the selected date range or search query. Issue a new bill in POS or click below to log a counter sale.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsManualSaleModalOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              + Log Counter Sale
            </button>
          </div>
        ) : (
          groupedByDate.map(([dateKey, dayInvoices]) => {
            const isExpanded = Boolean(expandedDates[dateKey]);
            const dayRevenue = dayInvoices.reduce((sum, i) => sum + i.grandTotal, 0);
            const dayProfit = dayInvoices.reduce((sum, i) => sum + (i.cashierProfit || 0), 0);
            const dayItemsSold = dayInvoices.reduce((sum, i) => sum + i.items.reduce((isum, itm) => isum + Math.abs(itm.quantity), 0), 0);
            const upiTotal = dayInvoices.filter(i => i.paymentMethod === 'upi').reduce((s, i) => s + i.grandTotal, 0);
            const cashTotal = dayInvoices.filter(i => i.paymentMethod === 'cash').reduce((s, i) => s + i.grandTotal, 0);

            return (
              <div key={dateKey} className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-xs transition">
                {/* Date Group Accordion Header */}
                <div
                  onClick={() => toggleDateAccordion(dateKey)}
                  className="p-4 sm:p-5 bg-slate-50/70 hover:bg-slate-100/70 border-b border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 cursor-pointer transition select-none"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-xl font-bold">
                      <CalendarDays className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm sm:text-base font-black text-slate-900">
                          {formatDateHeader(dateKey)}
                        </span>
                        <span className="px-2 py-0.5 bg-slate-200 text-slate-700 text-[10px] rounded-full font-bold">
                          {dayInvoices.length} {dayInvoices.length === 1 ? 'bill' : 'bills'}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-0.5">
                        <span>Items sold: <strong className="text-slate-700">{dayItemsSold}</strong></span>
                        <span>•</span>
                        <span>Profit: <strong className="text-emerald-700">{formatCurrency(dayProfit)}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                    {/* Payment breakdown pills */}
                    <div className="hidden md:flex items-center gap-2 text-[11px]">
                      {upiTotal > 0 && (
                        <span className="px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg font-bold">
                          UPI: {formatCurrency(upiTotal)}
                        </span>
                      )}
                      {cashTotal > 0 && (
                        <span className="px-2 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-lg font-bold">
                          Cash: {formatCurrency(cashTotal)}
                        </span>
                      )}
                    </div>

                    <div className="text-right">
                      <div className="text-xs text-slate-400 font-bold uppercase tracking-wider">Day Total</div>
                      <div className="text-base sm:text-lg font-black text-indigo-600">
                        {formatCurrency(dayRevenue)}
                      </div>
                    </div>

                    <div className="p-1 text-slate-400 hover:text-slate-700">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </div>

                {/* Day Invoices Table / List (Expanded) */}
                {isExpanded && (
                  <div className="divide-y divide-slate-100 overflow-x-auto">
                    <table className="w-full text-left border-collapse min-w-[700px]">
                      <thead>
                        <tr className="bg-slate-50/40 text-[11px] font-black uppercase text-slate-400 tracking-wider">
                          <th className="py-2.5 px-4">Time & Bill #</th>
                          <th className="py-2.5 px-4">Customer</th>
                          <th className="py-2.5 px-4">Items Summary</th>
                          <th className="py-2.5 px-4">Payment</th>
                          <th className="py-2.5 px-4 text-right">Bill Total</th>
                          <th className="py-2.5 px-4 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs">
                        {dayInvoices.map((inv) => {
                          const totalQty = inv.items.reduce((s, i) => s + Math.abs(i.quantity), 0);
                          const firstItem = inv.items[0]?.product?.name || 'Item';
                          const otherItemsCount = inv.items.length - 1;

                          return (
                            <tr key={inv.id || inv.invoiceNumber} className="hover:bg-slate-50/80 transition">
                              {/* Time & Bill # */}
                              <td className="py-3 px-4">
                                <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                                  <Receipt className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                  <span>{inv.invoiceNumber}</span>
                                </div>
                                <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                                  <Clock className="w-3 h-3" />
                                  <span>{inv.time || '12:00 PM'}</span>
                                </div>
                              </td>

                              {/* Customer */}
                              <td className="py-3 px-4">
                                <div className="font-bold text-slate-800">
                                  {inv.customerName || 'Walk-in Customer'}
                                </div>
                                {inv.customerPhone && (
                                  <div className="text-[11px] text-slate-400 font-mono">
                                    {inv.customerPhone}
                                  </div>
                                )}
                              </td>

                              {/* Items Summary */}
                              <td className="py-3 px-4 max-w-xs">
                                <div className="truncate font-medium text-slate-700" title={inv.items.map(i => `${i.product.name} (x${i.quantity})`).join(', ')}>
                                  {firstItem} {otherItemsCount > 0 && <span className="text-indigo-600 font-bold">(+{otherItemsCount} more)</span>}
                                </div>
                                <div className="text-[10px] text-slate-400 mt-0.5">
                                  {totalQty} {totalQty === 1 ? 'unit' : 'units'} • {inv.items.length} line {inv.items.length === 1 ? 'item' : 'items'}
                                </div>
                              </td>

                              {/* Payment Mode Badge */}
                              <td className="py-3 px-4">
                                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                                  inv.paymentMethod === 'upi' ? 'bg-emerald-100 text-emerald-800' :
                                  inv.paymentMethod === 'cash' ? 'bg-amber-100 text-amber-800' :
                                  inv.paymentMethod === 'card' ? 'bg-blue-100 text-blue-800' :
                                  'bg-purple-100 text-purple-800'
                                }`}>
                                  {inv.paymentMethod === 'upi' && <Smartphone className="w-3 h-3" />}
                                  {inv.paymentMethod === 'cash' && <Banknote className="w-3 h-3" />}
                                  {inv.paymentMethod === 'card' && <CreditCard className="w-3 h-3" />}
                                  {inv.paymentMethod === 'khata' && <Users2 className="w-3 h-3" />}
                                  <span>{inv.paymentMethod}</span>
                                </span>
                              </td>

                              {/* Bill Total */}
                              <td className="py-3 px-4 text-right">
                                <div className="font-black text-slate-900 text-sm">
                                  {formatCurrency(inv.grandTotal)}
                                </div>
                                {inv.cashierProfit !== undefined && inv.cashierProfit > 0 && (
                                  <div className="text-[10px] text-emerald-600 font-bold">
                                    +{formatCurrency(inv.cashierProfit)} profit
                                  </div>
                                )}
                              </td>

                              {/* Actions */}
                              <td className="py-3 px-4 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveInvoicePreview(inv);
                                      playBeep('scan');
                                    }}
                                    className="p-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg transition cursor-pointer"
                                    title="View & Print Bill"
                                  >
                                    <Eye className="w-3.5 h-3.5" />
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      try {
                                        playBeep('success');
                                        const waUrl = generateWhatsAppLink(inv, shopProfile);
                                        window.open(waUrl, '_blank', 'noopener,noreferrer');
                                      } catch (err: any) {
                                        console.error('Send bill on WhatsApp failed:', err);
                                        playBeep('alert');
                                        alert(err.message || 'Failed to send bill on WhatsApp. Please check customer phone number.');
                                      }
                                    }}
                                    className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition cursor-pointer"
                                    title="Send Bill via WhatsApp (Digital Receipt)"
                                  >
                                    <Send className="w-3.5 h-3.5" />
                                  </button>

                                  <button
                                    type="button"
                                    id={`btn-delete-inv-${inv.invoiceNumber}`}
                                    onClick={() => handleOpenDeleteDialog(inv)}
                                    className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition cursor-pointer"
                                    title="Delete Bill & Restore Stock"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Visual Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 max-w-md bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500/50 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-emerald-500 text-white rounded-xl shrink-0">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <p className="text-xs font-bold leading-snug">{toastMessage}</p>
          </div>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Delete Invoice & Stock Restore Confirmation Modal */}
      {invoiceToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4 animate-in zoom-in-95">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-rose-100 text-rose-600 rounded-2xl">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base">Delete Sale Invoice</h3>
                  <p className="text-xs text-slate-500 font-medium">Invoice #{invoiceToDelete.invoiceNumber}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Confirmation Prompt Question */}
              <div className="p-3.5 bg-rose-50/70 border border-rose-200/80 rounded-2xl">
                <p className="text-xs font-bold text-rose-900 leading-relaxed">
                  Are you sure you want to delete Invoice #{invoiceToDelete.invoiceNumber}? This will restore stock.
                </p>
              </div>

              {/* Invoice details summary */}
              <div className="p-3 bg-slate-50 border border-slate-200/70 rounded-2xl space-y-2 text-xs">
                <div className="flex justify-between items-center text-slate-600">
                  <span className="font-medium">Customer:</span>
                  <span className="font-bold text-slate-900">{invoiceToDelete.customerName || 'Walk-in Customer'}</span>
                </div>
                <div className="flex justify-between items-center text-slate-600">
                  <span className="font-medium">Date & Time:</span>
                  <span className="font-bold text-slate-900">{invoiceToDelete.date} • {invoiceToDelete.time || '12:00 PM'}</span>
                </div>
                <div className="flex justify-between items-center text-slate-600">
                  <span className="font-medium">Bill Total:</span>
                  <span className="font-black text-emerald-600 text-sm">{formatCurrency(invoiceToDelete.grandTotal)}</span>
                </div>
              </div>

              {/* Stock items being restored */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1">
                  <PackageCheck className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Inventory Stock to Restore:</span>
                </div>
                <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                  {invoiceToDelete.items.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between gap-2 p-1.5 bg-white rounded-lg border border-slate-200/60">
                      <span className="font-semibold text-slate-800 truncate" title={item.product.name}>
                        {item.product.name}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[11px] font-black shrink-0 ${
                        item.isExchangeReturn || item.quantity < 0
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {item.isExchangeReturn || item.quantity < 0
                          ? `-${Math.abs(item.quantity)} (Return deducted)`
                          : `+${Math.abs(item.quantity)} stock restored`}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <p className="text-[11px] text-slate-400 font-medium leading-tight">
                ⚠️ This action will permanently remove the sale from sales history and immediately recalculate daily revenue and totals.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-delete-invoice"
                onClick={handleConfirmDeleteInvoice}
                disabled={isDeleting}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-rose-600/25 transition cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting & Restoring...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete & Restore Stock</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Counter Sale Modal */}
      {isManualSaleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-600 text-white rounded-xl">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base">Log Manual Counter Sale</h3>
                  <p className="text-xs text-slate-400">Record an offline slip or past counter transaction directly.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsManualSaleModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveManualSale} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Sale Date *</label>
                  <input
                    type="date"
                    required
                    value={manualDate}
                    onChange={e => setManualDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method *</label>
                  <select
                    value={manualPayment}
                    onChange={e => setManualPayment(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="cash">💵 Cash</option>
                    <option value="upi">📱 UPI / QR</option>
                    <option value="card">💳 Card</option>
                    <option value="khata">👥 Khata / Credit</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Item Description / Product *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Milton Thermosteel Flask 1000ml"
                  value={manualItemName}
                  onChange={e => setManualItemName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-medium focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Quantity (Pcs) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={manualQty}
                    onChange={e => setManualQty(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Unit Sale Price (₹) *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={manualPrice}
                    onChange={e => setManualPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Customer Name (Optional)</label>
                  <input
                    type="text"
                    placeholder="Walk-in Customer"
                    value={manualCustomer}
                    onChange={e => setManualCustomer(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-medium focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number (Optional)</label>
                  <input
                    type="tel"
                    placeholder="10-digit mobile"
                    value={manualPhone}
                    onChange={e => setManualPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 font-medium focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Total Summary Preview */}
              <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-2xl flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-bold text-indigo-900">Total Transaction Amount:</div>
                  <div className="text-xs text-indigo-700">Includes 18% GST estimate</div>
                </div>
                <div className="text-xl font-black text-indigo-700">
                  {formatCurrency(manualPrice * manualQty)}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsManualSaleModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingManual}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-indigo-600/30 transition cursor-pointer disabled:opacity-50"
                >
                  {isSubmittingManual ? 'Saving...' : 'Confirm & Save Bill'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
