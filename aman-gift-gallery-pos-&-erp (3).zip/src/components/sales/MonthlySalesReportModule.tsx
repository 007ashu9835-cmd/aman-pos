import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { db } from '../../db';
import { Invoice, Product, CartItem } from '../../types';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { exportMonthlyCaPackage } from '../../utils/exportCaPackage';
import { 
  BarChart3, 
  Calendar, 
  TrendingUp, 
  TrendingDown, 
  IndianRupee, 
  ShoppingCart, 
  Receipt, 
  Download, 
  ChevronRight, 
  ChevronDown, 
  X, 
  Award, 
  Sparkles, 
  Flame, 
  Eye, 
  RefreshCw, 
  Layers, 
  ArrowUpRight, 
  ArrowDownRight,
  Filter,
  CheckCircle2
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from 'recharts';

interface MonthData {
  monthIndex: number; // 0 = Jan, 11 = Dec
  monthName: string; // "January", "February"...
  year: number;
  monthKey: string; // "2026-01", "2026-02"...
  totalRevenue: number;
  totalProfit: number;
  totalGst: number;
  totalInvoices: number;
  totalUnitsSold: number;
  avgTicketSize: number;
  momGrowthPercent: number | null; // compared to previous month
  topProducts: {
    name: string;
    brand?: string;
    unitsSold: number;
    revenue: number;
  }[];
  invoices: Invoice[];
  dailyBreakdown: {
    day: number;
    dateStr: string;
    revenue: number;
    profit: number;
    invoicesCount: number;
    itemsCount: number;
    invoices: Invoice[];
  }[];
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const MonthlySalesReportModule: React.FC = () => {
  const { products, setActiveInvoicePreview, playBeep, shopProfile } = useApp();

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  
  // Active Year Selection
  const currentYear = new Date().getFullYear();
  const currentMonthIdx = new Date().getMonth();
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);

  // Selected Month Drilldown Modal / Drawer
  const [selectedMonthDrilldown, setSelectedMonthDrilldown] = useState<MonthData | null>(null);
  const [expandedDayInDrilldown, setExpandedDayInDrilldown] = useState<number | null>(null);

  // Load all invoices
  const loadInvoices = async () => {
    try {
      setLoading(true);
      const allInvs = await db.invoices.toArray();
      setInvoices(allInvs);
    } catch (err) {
      console.error('Error loading invoices in MonthlySalesReport:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, [products]);

  // Available Years from Invoices
  const availableYears = useMemo(() => {
    const yearsSet = new Set<number>([currentYear, currentYear - 1]);
    for (const inv of invoices) {
      if (inv.date) {
        const y = parseInt(inv.date.split('-')[0]);
        if (!isNaN(y)) yearsSet.add(y);
      }
    }
    return Array.from(yearsSet).sort((a, b) => b - a);
  }, [invoices, currentYear]);

  // Compute 12 Months Breakdown for the selected year
  const monthsDataList = useMemo<MonthData[]>(() => {
    const list: MonthData[] = [];

    // Filter invoices for the selected year and prior December for MoM
    const yearInvoices = invoices.filter(i => i.date && i.date.startsWith(`${selectedYear}-`));
    const prevYearDecInvoices = invoices.filter(i => i.date && i.date.startsWith(`${selectedYear - 1}-12`));

    let prevMonthRevenue = prevYearDecInvoices.reduce((sum, i) => sum + i.grandTotal, 0);

    for (let m = 0; m < 12; m++) {
      const monthNumStr = String(m + 1).padStart(2, '0');
      const monthKey = `${selectedYear}-${monthNumStr}`;
      const monthInvs = yearInvoices.filter(i => i.date && i.date.startsWith(monthKey));

      let totalRevenue = 0;
      let totalProfit = 0;
      let totalGst = 0;
      let totalUnitsSold = 0;
      const productStatsMap: Record<string, { name: string; brand?: string; units: number; rev: number }> = {};

      // Days breakdown setup (1 to 28/30/31)
      const daysInMonth = new Date(selectedYear, m + 1, 0).getDate();
      const dailyMap: Record<number, { day: number; dateStr: string; revenue: number; profit: number; invoicesCount: number; itemsCount: number; invoices: Invoice[] }> = {};

      for (let d = 1; d <= daysInMonth; d++) {
        const dayStr = `${selectedYear}-${monthNumStr}-${String(d).padStart(2, '0')}`;
        dailyMap[d] = {
          day: d,
          dateStr: dayStr,
          revenue: 0,
          profit: 0,
          invoicesCount: 0,
          itemsCount: 0,
          invoices: []
        };
      }

      for (const inv of monthInvs) {
        totalRevenue += inv.grandTotal;
        totalProfit += (inv.cashierProfit || 0);
        totalGst += (inv.totalGst || 0);

        // Day aggregation
        const dayNum = parseInt(inv.date.split('-')[2], 10);
        if (!isNaN(dayNum) && dailyMap[dayNum]) {
          dailyMap[dayNum].revenue += inv.grandTotal;
          dailyMap[dayNum].profit += (inv.cashierProfit || 0);
          dailyMap[dayNum].invoicesCount += 1;
          dailyMap[dayNum].invoices.push(inv);
        }

        // Product stats aggregation
        for (const item of inv.items) {
          const qty = Math.abs(item.quantity);
          totalUnitsSold += qty;
          if (dailyMap[dayNum]) {
            dailyMap[dayNum].itemsCount += qty;
          }

          const prodName = item.product.name;
          if (!productStatsMap[prodName]) {
            productStatsMap[prodName] = {
              name: prodName,
              brand: item.product.brand,
              units: 0,
              rev: 0
            };
          }
          productStatsMap[prodName].units += qty;
          productStatsMap[prodName].rev += (item.customPrice || item.product.sellingPrice || item.product.mrp) * qty;
        }
      }

      // Top 3 Products
      const topProducts = Object.values(productStatsMap)
        .sort((a, b) => b.units - a.units || b.rev - a.rev)
        .slice(0, 3)
        .map(p => ({
          name: p.name,
          brand: p.brand,
          unitsSold: p.units,
          revenue: p.rev
        }));

      // Month-over-Month Growth
      let momGrowthPercent: number | null = null;
      if (prevMonthRevenue > 0) {
        momGrowthPercent = Math.round(((totalRevenue - prevMonthRevenue) / prevMonthRevenue) * 100);
      } else if (totalRevenue > 0 && prevMonthRevenue === 0) {
        momGrowthPercent = 100;
      }

      prevMonthRevenue = totalRevenue;

      list.push({
        monthIndex: m,
        monthName: MONTH_NAMES[m],
        year: selectedYear,
        monthKey,
        totalRevenue,
        totalProfit,
        totalGst,
        totalInvoices: monthInvs.length,
        totalUnitsSold,
        avgTicketSize: monthInvs.length > 0 ? Math.round(totalRevenue / monthInvs.length) : 0,
        momGrowthPercent,
        topProducts,
        invoices: monthInvs,
        dailyBreakdown: Object.values(dailyMap)
      });
    }

    return list;
  }, [invoices, selectedYear]);

  // Annual Totals
  const annualSummary = useMemo(() => {
    const totalRev = monthsDataList.reduce((sum, m) => sum + m.totalRevenue, 0);
    const totalProfit = monthsDataList.reduce((sum, m) => sum + m.totalProfit, 0);
    const totalInvs = monthsDataList.reduce((sum, m) => sum + m.totalInvoices, 0);
    const totalUnits = monthsDataList.reduce((sum, m) => sum + m.totalUnitsSold, 0);
    
    // Find best performing month
    const nonZeroMonths = monthsDataList.filter(m => m.totalRevenue > 0);
    const topMonth = nonZeroMonths.length > 0
      ? [...nonZeroMonths].sort((a, b) => b.totalRevenue - a.totalRevenue)[0]
      : null;

    const avgMonthly = Math.round(totalRev / (nonZeroMonths.length || 1));

    return {
      totalRev,
      totalProfit,
      totalInvs,
      totalUnits,
      topMonth,
      avgMonthly
    };
  }, [monthsDataList]);

  // Chart Data for Top Growth Visualizer
  const chartData = useMemo(() => {
    return monthsDataList.map(m => ({
      name: m.monthName.slice(0, 3),
      revenue: m.totalRevenue,
      profit: m.totalProfit,
      growth: m.momGrowthPercent,
      isCurrent: selectedYear === currentYear && m.monthIndex === currentMonthIdx
    }));
  }, [monthsDataList, selectedYear, currentYear, currentMonthIdx]);

  // Export Full Year Sales to CSV
  const handleExportAnnualCsv = () => {
    const headers = ['Month', 'Year', 'Total Revenue', 'Profit', 'Invoices Count', 'Units Sold', 'Avg Ticket Size', 'Top Product 1', 'Top Product 2', 'Top Product 3'];
    const rows = monthsDataList.map(m => {
      const top1 = m.topProducts[0] ? `${m.topProducts[0].name} (${m.topProducts[0].unitsSold} pcs)` : '-';
      const top2 = m.topProducts[1] ? `${m.topProducts[1].name} (${m.topProducts[1].unitsSold} pcs)` : '-';
      const top3 = m.topProducts[2] ? `${m.topProducts[2].name} (${m.topProducts[2].unitsSold} pcs)` : '-';
      return [
        m.monthName,
        m.year,
        m.totalRevenue,
        m.totalProfit,
        m.totalInvoices,
        m.totalUnitsSold,
        m.avgTicketSize,
        `"${top1.replace(/"/g, '""')}"`,
        `"${top2.replace(/"/g, '""')}"`,
        `"${top3.replace(/"/g, '""')}"`
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Monthly_Sales_Report_${selectedYear}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    playBeep('success');
  };

  // Export Single Month CA Package
  const handleExportMonthCa = async (monthData: MonthData) => {
    try {
      exportMonthlyCaPackage(
        monthData.invoices,
        monthData.monthIndex + 1,
        monthData.year,
        shopProfile?.name || 'Aman Gift Gallery'
      );
      playBeep('success');
    } catch (e) {
      console.error('Error exporting CA package for month:', e);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto overflow-y-auto bg-slate-50 select-none">
      {/* Header & Year Selector */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white border border-slate-200/80 p-5 rounded-2xl shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-md shadow-indigo-600/20">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
                <span>Monthly Sales Report</span>
                <span className="text-xs px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-full font-bold">
                  मासिक बिक्री रिपोर्ट
                </span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Comprehensive 12-month calendar breakdown with revenue, units sold, and best-selling products.
              </p>
            </div>
          </div>
        </div>

        {/* Year Selector & Global Actions */}
        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          {/* Year Buttons */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl">
            {availableYears.map(yr => (
              <button
                key={yr}
                type="button"
                onClick={() => setSelectedYear(yr)}
                className={`px-3 py-1.5 rounded-lg text-xs font-black transition cursor-pointer ${
                  selectedYear === yr
                    ? 'bg-white text-indigo-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {yr}
              </button>
            ))}
          </div>

          <button
            type="button"
            id="btn-export-annual-csv"
            onClick={handleExportAnnualCsv}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-bold text-xs rounded-xl transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export {selectedYear} Report</span>
          </button>
        </div>
      </div>

      {/* Annual Summary Highlights KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1">
          <div className="text-slate-500 text-xs font-bold flex items-center justify-between">
            <span>{selectedYear} Annual Turnover</span>
            <IndianRupee className="w-3.5 h-3.5 text-indigo-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            {formatCurrency(annualSummary.totalRev)}
          </div>
          <div className="text-[11px] text-emerald-600 font-bold">
            Profit: {formatCurrency(annualSummary.totalProfit)}
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1">
          <div className="text-slate-500 text-xs font-bold flex items-center justify-between">
            <span>Annual Invoices</span>
            <Receipt className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            {annualSummary.totalInvs} <span className="text-xs font-bold text-slate-400">bills</span>
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            Total Units Sold: <strong className="text-slate-800">{annualSummary.totalUnits}</strong>
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1">
          <div className="text-slate-500 text-xs font-bold flex items-center justify-between">
            <span>Top Grossing Month</span>
            <Award className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-base sm:text-lg font-black text-amber-900 truncate">
            {annualSummary.topMonth ? annualSummary.topMonth.monthName : 'No Sales Yet'}
          </div>
          <div className="text-[11px] text-amber-700 font-bold">
            {annualSummary.topMonth ? formatCurrency(annualSummary.topMonth.totalRevenue) : '₹0'}
          </div>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-2xl shadow-xs space-y-1">
          <div className="text-slate-500 text-xs font-bold flex items-center justify-between">
            <span>Avg Monthly Sales</span>
            <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">
            {formatCurrency(annualSummary.avgMonthly)}
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            Across active months
          </div>
        </div>
      </div>

      {/* Month-over-Month Growth Visualizer Chart */}
      <div className="bg-white border border-slate-200/80 p-5 rounded-2xl shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            <h3 className="font-extrabold text-sm text-slate-800">
              {selectedYear} Month-over-Month Sales & Turnover Trajectory
            </h3>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-bold text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-indigo-600 rounded-xs"></span> Revenue
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-xs"></span> Profit
            </span>
          </div>
        </div>

        <div className="h-44 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} tickFormatter={(val) => `₹${val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val}`} />
              <Tooltip 
                formatter={(val: number) => [formatCurrency(val), '']}
                labelFormatter={(label) => `${label} ${selectedYear}`}
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '12px', color: '#fff', fontSize: '11px', fontWeight: 'bold' }}
              />
              <Bar dataKey="revenue" name="Revenue" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.isCurrent ? '#4f46e5' : '#6366f1'} 
                  />
                ))}
              </Bar>
              <Bar dataKey="profit" name="Profit" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 12-Month Cards Grid (January through December) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span>All 12 Months Breakdown ({selectedYear})</span>
          </h2>
          <span className="text-xs text-slate-400 font-medium">Click any month to open full calendar log</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {monthsDataList.map((month) => {
            const isCurrentMonth = selectedYear === currentYear && month.monthIndex === currentMonthIdx;
            const hasSales = month.totalRevenue > 0;

            return (
              <div
                key={month.monthKey}
                className={`bg-white border rounded-2xl p-5 shadow-xs transition hover:shadow-md flex flex-col justify-between space-y-4 ${
                  isCurrentMonth 
                    ? 'border-indigo-300 ring-2 ring-indigo-500/20' 
                    : hasSales 
                      ? 'border-slate-200/90 hover:border-indigo-200' 
                      : 'border-slate-200/50 opacity-80'
                }`}
              >
                {/* Month Header & Status */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-base font-black text-slate-900">
                        {month.monthName} {month.year}
                      </span>
                      {isCurrentMonth && (
                        <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-[10px] rounded-full font-extrabold animate-pulse">
                          Current Month
                        </span>
                      )}
                    </div>

                    {/* MoM Growth Pill */}
                    {month.momGrowthPercent !== null && hasSales && (
                      <span className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        month.momGrowthPercent >= 0 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {month.momGrowthPercent >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        <span>{month.momGrowthPercent >= 0 ? `+${month.momGrowthPercent}%` : `${month.momGrowthPercent}%`}</span>
                      </span>
                    )}
                  </div>

                  {/* Revenue & Profit Display */}
                  <div className="flex items-baseline justify-between pt-1">
                    <div>
                      <div className="text-2xl font-black text-slate-900">
                        {formatCurrency(month.totalRevenue)}
                      </div>
                      <div className="text-[11px] text-emerald-600 font-bold">
                        Profit: {formatCurrency(month.totalProfit)}
                      </div>
                    </div>

                    <div className="text-right text-xs">
                      <div className="font-extrabold text-slate-700">{month.totalInvoices} bills</div>
                      <div className="text-[11px] text-slate-400">{month.totalUnitsSold} items sold</div>
                    </div>
                  </div>
                </div>

                {/* Top 3 Best-Selling Products for this month */}
                <div className="space-y-1.5 pt-2 border-t border-slate-100">
                  <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider flex items-center gap-1">
                    <Flame className="w-3 h-3 text-amber-500" />
                    <span>Top Selling Items</span>
                  </div>

                  {month.topProducts.length > 0 ? (
                    <div className="space-y-1 text-xs">
                      {month.topProducts.map((prod, idx) => (
                        <div key={idx} className="flex items-center justify-between bg-slate-50 px-2.5 py-1.5 rounded-lg">
                          <div className="truncate pr-2 font-medium text-slate-800">
                            <span className="font-bold text-slate-400 mr-1.5">#{idx + 1}</span>
                            {prod.name}
                          </div>
                          <div className="shrink-0 text-right">
                            <span className="font-bold text-indigo-700">{prod.unitsSold} pcs</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-2 text-[11px] text-slate-400 italic">
                      No products sold in {month.monthName}
                    </div>
                  )}
                </div>

                {/* Card Footer Actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMonthDrilldown(month);
                      playBeep('scan');
                    }}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition cursor-pointer active:scale-95"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>View Full Month Log</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  {hasSales && (
                    <button
                      type="button"
                      onClick={() => handleExportMonthCa(month)}
                      title="Export CA Tax Package for this Month"
                      className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-slate-600" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Full Month Calendar Drilldown Modal */}
      {selectedMonthDrilldown && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-4xl w-full p-6 shadow-2xl border border-slate-100 space-y-5 max-h-[90vh] flex flex-col animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-600 text-white rounded-xl">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-lg flex items-center gap-2">
                    <span>{selectedMonthDrilldown.monthName} {selectedMonthDrilldown.year} Complete Calendar Log</span>
                    <span className="text-xs px-2.5 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-full font-bold">
                      {selectedMonthDrilldown.totalInvoices} Bills
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Day-by-day revenue breakdown (1st to end of month) with complete transactional register.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleExportMonthCa(selectedMonthDrilldown)}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CA Package</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedMonthDrilldown(null)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Month Summary Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 shrink-0">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500">Month Turnover</div>
                <div className="text-lg font-black text-slate-900">{formatCurrency(selectedMonthDrilldown.totalRevenue)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500">Estimated Profit</div>
                <div className="text-lg font-black text-emerald-600">{formatCurrency(selectedMonthDrilldown.totalProfit)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500">GST Collected</div>
                <div className="text-lg font-black text-slate-800">{formatCurrency(selectedMonthDrilldown.totalGst)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="text-[11px] font-bold text-slate-500">Avg Daily Sale</div>
                <div className="text-lg font-black text-indigo-600">
                  {formatCurrency(Math.round(selectedMonthDrilldown.totalRevenue / 30))}
                </div>
              </div>
            </div>

            {/* Day-by-Day Calendar Timeline / Table (Scrollable) */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 divide-y divide-slate-100">
              {selectedMonthDrilldown.dailyBreakdown.map((dayData, idx) => {
                const isDayExpanded = expandedDayInDrilldown === dayData.day;
                const hasDaySales = dayData.revenue > 0;

                return (
                  <div key={dayData.dateStr || (dayData.day && !isNaN(dayData.day) ? `day-${dayData.day}` : `day-${idx}`)} className="pt-2">
                    <div
                      onClick={() => hasDaySales && setExpandedDayInDrilldown(isDayExpanded ? null : dayData.day)}
                      className={`flex items-center justify-between p-3 rounded-xl transition select-none ${
                        hasDaySales 
                          ? 'bg-slate-50/80 hover:bg-slate-100 cursor-pointer' 
                          : 'bg-white text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg font-black text-xs flex items-center justify-center ${
                          hasDaySales ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 text-slate-400'
                        }`}>
                          {dayData.day}
                        </div>
                        <div>
                          <div className={`text-xs font-bold ${hasDaySales ? 'text-slate-900' : 'text-slate-400'}`}>
                            {dayData.dateStr}
                          </div>
                          {hasDaySales ? (
                            <div className="text-[11px] text-slate-500">
                              {dayData.invoicesCount} {dayData.invoicesCount === 1 ? 'bill' : 'bills'} • {dayData.itemsCount} items sold
                            </div>
                          ) : (
                            <div className="text-[11px] text-slate-400 italic">No transactions</div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        {hasDaySales && (
                          <div className="text-right">
                            <div className="text-xs font-black text-slate-900">{formatCurrency(dayData.revenue)}</div>
                            <div className="text-[10px] font-bold text-emerald-600">+{formatCurrency(dayData.profit)} profit</div>
                          </div>
                        )}
                        {hasDaySales && (
                          <div className="text-slate-400">
                            {isDayExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Expanded Daily Bills List */}
                    {isDayExpanded && dayData.invoices.length > 0 && (
                      <div className="p-3 bg-indigo-50/40 rounded-xl mt-1 space-y-2 border border-indigo-100 animate-in fade-in">
                        <div className="text-[11px] font-black text-indigo-900 uppercase tracking-wider">
                          Transactions on {dayData.dateStr}:
                        </div>
                        <div className="divide-y divide-indigo-100/60 bg-white rounded-xl border border-indigo-100 overflow-hidden">
                          {dayData.invoices.map((inv) => (
                            <div key={inv.id || inv.invoiceNumber} className="p-2.5 flex items-center justify-between hover:bg-slate-50 text-xs">
                              <div>
                                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                                  <Receipt className="w-3.5 h-3.5 text-indigo-600" />
                                  <span>{inv.invoiceNumber}</span>
                                  <span className="text-[11px] text-slate-400">({inv.time || '12:00 PM'})</span>
                                </div>
                                <div className="text-[11px] text-slate-500 mt-0.5">
                                  {inv.customerName || 'Walk-in Customer'} • {inv.items.length} items
                                </div>
                              </div>

                              <div className="flex items-center gap-3">
                                <span className="text-xs font-black text-slate-900">{formatCurrency(inv.grandTotal)}</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveInvoicePreview(inv);
                                    playBeep('scan');
                                  }}
                                  className="p-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg transition cursor-pointer"
                                  title="View Invoice"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Modal Footer */}
            <div className="border-t border-slate-100 pt-3 flex items-center justify-end shrink-0">
              <button
                type="button"
                onClick={() => setSelectedMonthDrilldown(null)}
                className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Close Register
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
