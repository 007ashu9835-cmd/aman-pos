import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { getTranslation } from '../../utils/translations';
import { db } from '../../db';
import { Invoice, PurchaseEntry, WastageEntry } from '../../types';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { exportMonthlyCaPackage } from '../../utils/exportCaPackage';
import { calculateBrandPerformance } from '../../utils/brandAnalytics';
import { BrandDrilldownModal, BrandPerformanceData } from '../common/BrandDrilldownModal';
import { 
  FileSpreadsheet, 
  Download, 
  Send, 
  PieChart as PieChartIcon, 
  TrendingUp, 
  Receipt, 
  Percent, 
  Scale, 
  Calendar,
  Layers,
  ArrowDownRight,
  ArrowUpRight,
  ShieldCheck,
  Check,
  Award,
  BarChart3,
  Flame,
  ChevronRight,
  Filter
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  Cell 
} from 'recharts';

export const ReportsModule: React.FC = () => {
  const { products, language, shopProfile } = useApp();
  const t = getTranslation(language);

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseEntry[]>([]);
  const [wastages, setWastages] = useState<WastageEntry[]>([]);
  const [activeReportTab, setActiveReportTab] = useState<'ca_hub' | 'brands' | 'gstr1' | 'gstr3b' | 'pnl'>('ca_hub');
  const [selectedBrandDrilldown, setSelectedBrandDrilldown] = useState<BrandPerformanceData | null>(null);
  const [brandSortBy, setBrandSortBy] = useState<'sales' | 'units' | 'profit' | 'stock'>('sales');

  // Filter Period
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());

  useEffect(() => {
    async function loadData() {
      const invs = await db.invoices.toArray();
      const purs = await db.purchases.toArray();
      const wsts = await db.wastage.toArray();
      setInvoices(invs);
      setPurchases(purs);
      setWastages(wsts);
    }
    loadData();
  }, []);

  // Filtered Data by Month/Year
  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      const d = new Date(inv.date);
      return d.getMonth() + 1 === selectedMonth && d.getFullYear() === selectedYear;
    });
  }, [invoices, selectedMonth, selectedYear]);

  const filteredPurchases = useMemo(() => {
    return purchases.filter(p => {
      const d = new Date(p.billDate);
      return d.getMonth() + 1 === selectedMonth && d.getFullYear() === selectedYear;
    });
  }, [purchases, selectedMonth, selectedYear]);

  const filteredWastage = useMemo(() => {
    return wastages.filter(w => {
      const d = new Date(w.date);
      return d.getMonth() + 1 === selectedMonth && d.getFullYear() === selectedYear;
    });
  }, [wastages, selectedMonth, selectedYear]);

  // Tax calculations
  const totalSalesVal = useMemo(() => filteredInvoices.reduce((s, i) => s + i.grandTotal, 0), [filteredInvoices]);
  const totalSalesGst = useMemo(() => filteredInvoices.reduce((s, i) => s + i.totalGst, 0), [filteredInvoices]);
  const taxableSales = totalSalesVal - totalSalesGst;

  const totalPurchaseVal = useMemo(() => filteredPurchases.reduce((s, p) => s + p.totalBillAmount, 0), [filteredPurchases]);
  const totalItcGst = useMemo(() => filteredPurchases.reduce((s, p) => s + p.totalGstAmount, 0), [filteredPurchases]);
  const netGstPayable = Math.max(0, totalSalesGst - totalItcGst);

  // Profit and Loss calculations
  const totalLandingCostOfGoodsSold = useMemo(() => filteredInvoices.reduce((s, i) => s + (i.totalLandingCost || 0), 0), [filteredInvoices]);
  const totalWastageLoss = useMemo(() => filteredWastage.reduce((s, w) => s + w.lossValue, 0), [filteredWastage]);
  const grossProfit = totalSalesVal - totalLandingCostOfGoodsSold - totalWastageLoss;
  const netMarginPercent = totalSalesVal > 0 ? (grossProfit / totalSalesVal) * 100 : 0;

  // Real-Time Dynamic Brand Analytics (Computed for current filtered period invoices)
  const brandAnalyticsList = useMemo(() => {
    return calculateBrandPerformance(products, filteredInvoices);
  }, [products, filteredInvoices]);

  const sortedBrands = useMemo(() => {
    return [...brandAnalyticsList].sort((a, b) => {
      if (brandSortBy === 'sales') return b.totalSalesValue - a.totalSalesValue;
      if (brandSortBy === 'units') return b.totalUnitsSold - a.totalUnitsSold;
      if (brandSortBy === 'profit') return b.totalProfitContribution - a.totalProfitContribution;
      return b.inventoryValuation - a.inventoryValuation;
    });
  }, [brandAnalyticsList, brandSortBy]);

  const chartBrandsData = useMemo(() => {
    return sortedBrands.slice(0, 8).map((b) => ({
      name: b.brand,
      sales: b.totalSalesValue,
      units: b.totalUnitsSold,
      profit: b.totalProfitContribution,
      stock: b.totalStockUnits,
      valuation: b.inventoryValuation,
      raw: b
    }));
  }, [sortedBrands]);

  const maxSales = Math.max(...sortedBrands.map(b => b.totalSalesValue), 1);
  const maxUnits = Math.max(...sortedBrands.map(b => b.totalUnitsSold), 1);

  // Monthly breakdown for bar chart
  const monthlyChartData = useMemo(() => {
    return [
      { name: 'Turnover', amount: totalSalesVal, fill: '#6366f1' },
      { name: 'Cost of Goods', amount: totalLandingCostOfGoodsSold, fill: '#f43f5e' },
      { name: 'Gross Profit', amount: Math.max(0, grossProfit), fill: '#10b981' },
      { name: 'Output GST', amount: totalSalesGst, fill: '#f59e0b' },
      { name: 'Input ITC', amount: totalItcGst, fill: '#06b6d4' }
    ];
  }, [totalSalesVal, totalLandingCostOfGoodsSold, grossProfit, totalSalesGst, totalItcGst]);

  // 1-Click CA Package Generator
  const handleExportCaExcel = () => {
    exportMonthlyCaPackage(filteredInvoices, selectedMonth, selectedYear, shopProfile.name);
  };

  // 1-Click WhatsApp to CA
  const handleShareWithCa = () => {
    const periodStr = `${selectedMonth}/${selectedYear}`;
    const text = `*GST Tax Summary & Data for ${shopProfile.name}*
GSTIN: ${shopProfile.gstin || '20AABCA1234F1Z8'}
Period: ${periodStr}
Total Sales: ${formatCurrency(totalSalesVal)} (${filteredInvoices.length} bills)
Output GST Liability: ${formatCurrency(totalSalesGst)}
Input Tax Credit (ITC): ${formatCurrency(totalItcGst)}
Estimated Net GST Payable: ${formatCurrency(netGstPayable)}

_The detailed Excel file has been exported from Aman Gift Gallery POS ERP._`;

    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto overflow-y-auto bg-slate-50">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-red-600" />
            <h2 className="text-xl font-black text-slate-900">
              GST & CA Reports
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            {language === 'hi' 
              ? 'ब्रांड्स रैंकिंग, GSTR-1, GSTR-3B एक्सेल एक्सपोर्ट और 1-क्लिक सीए शेयरिंग' 
              : 'Audit-ready GSTR-1, GSTR-3B calculation, Brand performance drill-down, and CA export package'}
          </p>
        </div>

        {/* Month / Year Filters & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-slate-50 px-2 py-1.5 rounded-xl border border-slate-300 text-xs">
            <Calendar className="w-3.5 h-3.5 text-slate-500 mr-1.5" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(Number(e.target.value))}
              className="bg-transparent text-slate-900 font-bold focus:outline-hidden pr-2 text-xs"
            >
              {[
                { m: 1, name: 'Jan' }, { m: 2, name: 'Feb' }, { m: 3, name: 'Mar' },
                { m: 4, name: 'Apr' }, { m: 5, name: 'May' }, { m: 6, name: 'Jun' },
                { m: 7, name: 'Jul' }, { m: 8, name: 'Aug' }, { m: 9, name: 'Sep' },
                { m: 10, name: 'Oct' }, { m: 11, name: 'Nov' }, { m: 12, name: 'Dec' }
              ].map(item => (
                <option key={item.m} value={item.m} className="bg-white text-slate-900">{item.name}</option>
              ))}
            </select>

            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="bg-transparent text-slate-900 font-bold focus:outline-hidden text-xs"
            >
              <option value={2026} className="bg-white text-slate-900">2026</option>
              <option value={2025} className="bg-white text-slate-900">2025</option>
            </select>
          </div>

          <button
            onClick={handleExportCaExcel}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-lg shadow-emerald-600/20 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? '1-क्लिक CA पैकेज (Excel)' : '1-Click CA Package'}</span>
          </button>

          <button
            onClick={handleShareWithCa}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-200 transition cursor-pointer"
          >
            <Send className="w-3.5 h-3.5 text-red-600" />
            <span>{language === 'hi' ? 'व्हाट्सएप भेजें' : 'Share via WA'}</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 space-x-6 text-xs font-bold">
        {[
          { id: 'ca_hub', label: 'CA Package Overview' },
          { id: 'brands', label: 'Top Brands & Products' },
          { id: 'gstr1', label: 'GSTR-1 Outward (Sales)' },
          { id: 'gstr3b', label: 'GSTR-3B Tax Liability' },
          { id: 'pnl', label: 'Profit & Loss Statement' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveReportTab(tab.id as any)}
            className={`pb-2.5 transition cursor-pointer ${
              activeReportTab === tab.id
                ? 'text-red-600 border-b-2 border-red-600 font-extrabold'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB CONTENT: CA HUB OVERVIEW */}
      {activeReportTab === 'ca_hub' && (
        <div className="space-y-6">
          {/* Key Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
              <span className="text-xs text-slate-500 uppercase tracking-wider font-bold">Total Monthly Sales</span>
              <h3 className="text-2xl font-black text-slate-900 mt-1">{formatCurrency(totalSalesVal)}</h3>
              <p className="text-[11px] text-slate-500 font-medium mt-1">{filteredInvoices.length} retail invoices</p>
            </div>

            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
              <span className="text-xs text-amber-700 uppercase tracking-wider font-bold">Output GST Collected</span>
              <h3 className="text-2xl font-black text-amber-700 mt-1">{formatCurrency(totalSalesGst)}</h3>
              <p className="text-[11px] text-slate-500 font-medium mt-1">Payable to Govt (CGST + SGST)</p>
            </div>

            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
              <span className="text-xs text-teal-700 uppercase tracking-wider font-bold">Input Tax Credit (ITC)</span>
              <h3 className="text-2xl font-black text-teal-700 mt-1">{formatCurrency(totalItcGst)}</h3>
              <p className="text-[11px] text-slate-500 font-medium mt-1">Claimable on Inward Purchases</p>
            </div>

            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs">
              <span className="text-xs text-emerald-700 uppercase tracking-wider font-bold">Net Cash GST Payable</span>
              <h3 className="text-2xl font-black text-emerald-700 mt-1">{formatCurrency(netGstPayable)}</h3>
              <p className="text-[11px] text-slate-500 font-medium mt-1">Output GST minus Input ITC</p>
            </div>
          </div>

          {/* Graphical Summary */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-red-600" />
              Monthly Financial & Tax Breakdown
            </h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11, fill: '#475569' }} />
                  <YAxis stroke="#64748b" tick={{ fontSize: 11, fill: '#475569' }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', color: '#0f172a' }}
                    formatter={(val: any) => [`₹${Number(val).toLocaleString('en-IN')}`, 'Amount']}
                  />
                  <Bar dataKey="amount" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: TOP BRANDS & PRODUCTS */}
      {activeReportTab === 'brands' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-xs">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <div className="p-2 bg-red-100 text-red-600 rounded-xl">
                  <Award className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-black text-slate-900">
                  {language === 'hi' ? 'टॉप सेलिंग ब्रांड्स व प्रोडक्ट परफॉर्मेंस' : 'Top Selling Brands & Product Performance'}
                </h3>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-1">
                {language === 'hi' 
                  ? 'चयनित अवधि के दौरान सभी ब्रांड्स का सेल्स व यूनिट्स रैंक बार चार्ट (1-क्लिक ड्रिल-डाउन)' 
                  : 'Ranked performance bar chart by sales value, units sold, profit, and in-stock units'}
              </p>
            </div>

            {/* Filter Toggle */}
            <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-500 px-2 flex items-center gap-1">
                <Filter className="w-3 h-3" /> Sort By:
              </span>
              <button
                onClick={() => setBrandSortBy('sales')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                  brandSortBy === 'sales'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Sales (₹)
              </button>
              <button
                onClick={() => setBrandSortBy('units')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                  brandSortBy === 'units'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Units Sold
              </button>
              <button
                onClick={() => setBrandSortBy('profit')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                  brandSortBy === 'profit'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Net Profit
              </button>
              <button
                onClick={() => setBrandSortBy('stock')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition cursor-pointer ${
                  brandSortBy === 'stock'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Stock Valuation
              </button>
            </div>
          </div>

          {/* Visual Ranked Bar Chart */}
          <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-red-600" />
                {brandSortBy === 'units' ? 'Brand Units Sold Comparison' : 'Brand Total Sales Value (₹)'}
              </h4>
              <span className="text-slate-500 font-medium text-[11px]">
                Click any bar to drill down into product models
              </span>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartBrandsData}
                  margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                  onClick={(e: any) => {
                    if (e && e.activePayload && e.activePayload[0]) {
                      setSelectedBrandDrilldown(e.activePayload[0].payload.raw);
                    }
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis 
                    dataKey="name" 
                    stroke="#64748b" 
                    tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                    interval={0}
                  />
                  <YAxis 
                    stroke="#64748b" 
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    tickFormatter={(val) => brandSortBy === 'units' ? `${val} pcs` : `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
                  />
                  <Tooltip
                    cursor={{ fill: '#fee2e2', opacity: 0.4 }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white border border-slate-200 p-3 rounded-xl shadow-xl text-xs space-y-1">
                            <p className="font-black text-slate-900 text-sm">{data.name}</p>
                            <div className="pt-1 border-t border-slate-100 space-y-0.5">
                              <p className="text-slate-600 font-medium">Sales Revenue: <strong className="text-slate-900">₹{Number(data.sales).toLocaleString('en-IN')}</strong></p>
                              <p className="text-slate-600 font-medium">Units Sold: <strong className="text-emerald-600">{data.units} Pcs</strong></p>
                              <p className="text-slate-600 font-medium">Net Profit: <strong className="text-red-600">₹{Number(data.profit).toLocaleString('en-IN')}</strong></p>
                              <p className="text-slate-600 font-medium">In-Stock Remaining: <strong className="text-blue-600">{data.stock} Pcs</strong></p>
                            </div>
                            <p className="text-[10px] text-red-600 font-bold pt-1">Click to drill down</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey={brandSortBy === 'units' ? 'units' : 'sales'} radius={[6, 6, 0, 0]} cursor="pointer">
                    {chartBrandsData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={index === 0 ? '#dc2626' : index === 1 ? '#ea580c' : index === 2 ? '#f59e0b' : '#64748b'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Brand Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sortedBrands.map((bStat, idx) => {
              const barWidth = brandSortBy === 'units'
                ? Math.max(8, (bStat.totalUnitsSold / maxUnits) * 100)
                : Math.max(8, (bStat.totalSalesValue / maxSales) * 100);

              return (
                <div
                  key={bStat.brand}
                  onClick={() => setSelectedBrandDrilldown(bStat)}
                  className="bg-slate-50 border border-slate-200 hover:border-red-400 hover:bg-white p-4 rounded-xl cursor-pointer transition space-y-3 group shadow-xs hover:shadow-md"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2.5">
                      <span className={`w-7 h-7 rounded-lg text-xs font-black flex items-center justify-center ${
                        idx === 0 
                          ? 'bg-red-600 text-white shadow-xs shadow-red-600/30' 
                          : idx === 1 
                          ? 'bg-amber-500 text-white' 
                          : idx === 2 
                          ? 'bg-slate-700 text-white' 
                          : 'bg-slate-200 text-slate-700'
                      }`}>
                        #{idx + 1}
                      </span>
                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-red-600 transition flex items-center gap-1.5">
                          {bStat.brand}
                          {idx === 0 && <Flame className="w-3.5 h-3.5 text-red-600 fill-red-600" />}
                        </h4>
                        <p className="text-[11px] text-slate-500 font-medium">
                          {bStat.totalProducts} Models • {bStat.totalStockUnits} In Stock
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-red-600 group-hover:translate-x-0.5 transition" />
                  </div>

                  {/* Metrics Row */}
                  <div className="grid grid-cols-3 gap-2 text-xs pt-1 border-t border-slate-200">
                    <div>
                      <span className="text-slate-500 text-[10px] uppercase font-bold">Sales Value</span>
                      <p className="font-extrabold text-slate-900">{formatCurrency(bStat.totalSalesValue)}</p>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] uppercase font-bold">Units Sold</span>
                      <p className="font-bold text-emerald-600">{bStat.totalUnitsSold} Pcs</p>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[10px] uppercase font-bold">Net Profit</span>
                      <p className="font-bold text-red-600">{formatCurrency(bStat.totalProfitContribution)}</p>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-red-600 group-hover:bg-red-500 h-full rounded-full transition-all"
                      style={{ width: `${barWidth}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-slate-500">
                    <span>Stock Value: <strong className="text-slate-700">{formatCurrency(bStat.inventoryValuation)}</strong></span>
                    <span className="text-red-600 font-extrabold group-hover:underline">1-Click Drill-Down →</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB CONTENT: GSTR-1 */}
      {activeReportTab === 'gstr1' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-xs">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-base text-slate-900">GSTR-1 Outward Supply Invoices</h3>
              <p className="text-xs text-slate-500">All B2CS retail tax invoices formatted for GST portal filing.</p>
            </div>
            <button
              onClick={handleExportCaExcel}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              Export GSTR-1 Excel
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-700">
              <thead>
                <tr className="bg-slate-100 text-slate-600 uppercase text-[10px] tracking-wider border-b border-slate-200 font-bold">
                  <th className="py-2.5 px-3">Invoice No</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3 text-right">Taxable Value</th>
                  <th className="py-2.5 px-3 text-right">CGST</th>
                  <th className="py-2.5 px-3 text-right">SGST</th>
                  <th className="py-2.5 px-3 text-right">Invoice Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredInvoices.map((inv) => {
                  const taxable = inv.grandTotal - inv.totalGst;
                  return (
                    <tr key={inv.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-mono font-bold text-red-600">{inv.invoiceNumber}</td>
                      <td className="py-2 px-3 text-slate-600 font-medium">{inv.date}</td>
                      <td className="py-2 px-3 font-bold text-slate-900">{inv.customerName || 'Walk-in'}</td>
                      <td className="py-2 px-3 text-right text-slate-700 font-medium">₹{taxable.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right text-amber-700 font-bold">₹{(inv.totalGst / 2).toFixed(2)}</td>
                      <td className="py-2 px-3 text-right text-amber-700 font-bold">₹{(inv.totalGst / 2).toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-black text-slate-900">₹{inv.grandTotal.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB CONTENT: GSTR-3B */}
      {activeReportTab === 'gstr3b' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-xs">
          <div>
            <h3 className="font-bold text-base text-slate-900">GSTR-3B Monthly Tax Return Computation</h3>
            <p className="text-xs text-slate-500">Summary table for Table 3.1 (Outward Supplies) & Table 4 (Eligible ITC).</p>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
            <div className="bg-slate-100 p-3 font-bold text-slate-800 border-b border-slate-200">
              3.1 Details of Outward Supplies and Inward Supplies Liable to Reverse Charge
            </div>
            <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50">
              <div>
                <span className="text-slate-500 block font-medium">Total Taxable Turnover</span>
                <p className="text-base font-black text-slate-900 mt-0.5">{formatCurrency(taxableSales)}</p>
              </div>
              <div>
                <span className="text-slate-500 block font-medium">Integrated Tax (IGST)</span>
                <p className="text-base font-bold text-slate-600 mt-0.5">₹0.00</p>
              </div>
              <div>
                <span className="text-slate-500 block font-medium">Central Tax (CGST)</span>
                <p className="text-base font-bold text-amber-700 mt-0.5">₹{(totalSalesGst / 2).toFixed(2)}</p>
              </div>
              <div>
                <span className="text-slate-500 block font-medium">State Tax (SGST)</span>
                <p className="text-base font-bold text-amber-700 mt-0.5">₹{(totalSalesGst / 2).toFixed(2)}</p>
              </div>
            </div>

            <div className="bg-slate-100 p-3 font-bold text-slate-800 border-t border-b border-slate-200">
              4. Eligible Input Tax Credit (ITC from Supplier Inward Bills)
            </div>
            <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50">
              <div>
                <span className="text-slate-500 block font-medium">Total Inward Purchase Value</span>
                <p className="text-base font-black text-slate-900 mt-0.5">{formatCurrency(totalPurchaseVal)}</p>
              </div>
              <div>
                <span className="text-slate-500 block font-medium">Total ITC Claimable</span>
                <p className="text-base font-bold text-teal-700 mt-0.5">{formatCurrency(totalItcGst)}</p>
              </div>
              <div>
                <span className="text-slate-500 block font-medium">ITC Central Tax (CGST)</span>
                <p className="text-base font-bold text-teal-700 mt-0.5">₹{(totalItcGst / 2).toFixed(2)}</p>
              </div>
              <div>
                <span className="text-slate-500 block font-medium">ITC State Tax (SGST)</span>
                <p className="text-base font-bold text-teal-700 mt-0.5">₹{(totalItcGst / 2).toFixed(2)}</p>
              </div>
            </div>

            <div className="bg-emerald-50 p-4 border-t border-emerald-200 flex justify-between items-center">
              <div>
                <span className="text-emerald-800 font-bold uppercase tracking-wider text-[10px]">Table 5: Net Tax Payable in Cash</span>
                <p className="text-xs text-emerald-900 font-medium">Liability after adjusting eligible ITC</p>
              </div>
              <h4 className="text-2xl font-black text-emerald-700">{formatCurrency(netGstPayable)}</h4>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: P&L */}
      {activeReportTab === 'pnl' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-6 shadow-xs">
          <div>
            <h3 className="font-bold text-base text-slate-900">Monthly Store Profit & Loss Statement</h3>
            <p className="text-xs text-slate-500">Actual financial profit factoring in Landing Cost of Goods and Wastage/Damages.</p>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-800">1. Gross Revenue / Retail Sales</span>
              <span className="font-black text-emerald-700 text-sm">+{formatCurrency(totalSalesVal)}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-800">2. Total Landing Cost of Goods Sold (COGS)</span>
              <span className="font-black text-rose-700 text-sm">-{formatCurrency(totalLandingCostOfGoodsSold)}</span>
            </div>

            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-800">3. Stock Wastage & Broken Damages Loss</span>
              <span className="font-black text-rose-700 text-sm">-{formatCurrency(totalWastageLoss)}</span>
            </div>

            <div className="flex justify-between items-center p-4 bg-red-50 border border-red-200 rounded-xl">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">Net Gross Profit</h4>
                <p className="text-[11px] text-slate-600 font-medium">Profit margin: {netMarginPercent.toFixed(1)}%</p>
              </div>
              <span className={`text-xl font-black ${grossProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                {formatCurrency(grossProfit)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* 1-Click Brand Drill-Down Modal Component */}
      <BrandDrilldownModal
        brandData={selectedBrandDrilldown}
        onClose={() => setSelectedBrandDrilldown(null)}
        language={language}
      />
    </div>
  );
};

