import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { getTranslation } from '../../utils/translations';
import { db } from '../../db';
import { Invoice, Product } from '../../types';
import { formatCurrency, formatNumber } from '../../utils/calculations';
import { calculateBrandPerformance } from '../../utils/brandAnalytics';
import { BrandDrilldownModal, BrandPerformanceData } from '../common/BrandDrilldownModal';
import { 
  TrendingUp, 
  IndianRupee, 
  Package, 
  AlertTriangle, 
  Award, 
  ChevronRight, 
  ShoppingCart, 
  ArrowUpRight, 
  BarChart3, 
  Tag, 
  Calendar,
  Layers,
  Sparkles,
  Flame,
  Filter,
  FileSpreadsheet,
  Users2,
  RefreshCw,
  Settings,
  ChevronDown,
  CalendarDays,
  Receipt,
  Cloud,
  CheckCircle2,
  Sliders
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from 'recharts';

export const DashboardModule: React.FC = () => {
  const { products, lowStockProducts, language, setActiveTab, shopProfile, isOnline, setIsCloudSyncModalOpen } = useApp();
  const t = getTranslation(language);

  const [todayInvoices, setTodayInvoices] = useState<Invoice[]>([]);
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [selectedBrandDrilldown, setSelectedBrandDrilldown] = useState<BrandPerformanceData | null>(null);
  const [brandSortBy, setBrandSortBy] = useState<'sales' | 'units' | 'profit' | 'stock'>('sales');
  const [showUtilitiesDropdown, setShowUtilitiesDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowUtilitiesDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    async function loadInvoices() {
      const invs = await db.invoices.toArray();
      setAllInvoices(invs);
      const todays = invs.filter(i => i.date === todayStr);
      setTodayInvoices(todays);
    }
    loadInvoices();
  }, [todayStr, products]);

  // Compute Metrics
  const todaySales = todayInvoices.reduce((sum, i) => sum + (i.grandTotal || 0), 0);
  const todayGrossProfit = todayInvoices.reduce((sum, i) => sum + (i.cashierProfit || 0), 0);

  const totalStockValuationLanding = products.reduce((sum, p) => sum + ((p.landingCost || 0) * (p.stockQty || 0)), 0);
  const totalStockValuationMrp = products.reduce((sum, p) => sum + ((p.mrp || 0) * (p.stockQty || 0)), 0);
  const totalStockUnits = products.reduce((sum, p) => sum + (p.stockQty || 0), 0);

  // Compute Real-Time Dynamic Brand Analytics
  const brandAnalyticsList = useMemo(() => {
    return calculateBrandPerformance(products, allInvoices);
  }, [products, allInvoices]);

  // Sorted Brand List based on user selection
  const sortedBrands = useMemo(() => {
    return [...brandAnalyticsList].sort((a, b) => {
      if (brandSortBy === 'sales') return b.totalSalesValue - a.totalSalesValue;
      if (brandSortBy === 'units') return b.totalUnitsSold - a.totalUnitsSold;
      if (brandSortBy === 'profit') return b.totalProfitContribution - a.totalProfitContribution;
      return b.inventoryValuation - a.inventoryValuation;
    });
  }, [brandAnalyticsList, brandSortBy]);

  // Ranked Bar Chart Data for Top Brands
  const chartBrandsData = useMemo(() => {
    return sortedBrands.slice(0, 7).map((b) => ({
      name: b.brand,
      sales: b.totalSalesValue,
      units: b.totalUnitsSold,
      profit: b.totalProfitContribution,
      stock: b.totalStockUnits,
      valuation: b.inventoryValuation,
      raw: b
    }));
  }, [sortedBrands]);

  const maxSales = Math.max(...sortedBrands.map(b => b.totalSalesValue), 1);
  const maxUnits = Math.max(...sortedBrands.map(b => b.totalUnitsSold), 1);

  // Utilities & Settings Item Definitions
  const utilityItems = [
    {
      id: 'reports',
      title: 'GST / CA Reports',
      hindiTitle: 'जीएसटी व सीए रिपोर्ट',
      description: 'GSTR-1, GSTR-3B tax summary, ITC ledger, Excel export & CA packages',
      icon: FileSpreadsheet,
      iconBg: 'bg-amber-50 text-amber-600 border border-amber-200/60',
      badge: 'Tax / Audit',
      badgeColor: 'bg-amber-100 text-amber-800'
    },
    {
      id: 'khata',
      title: 'Khata / Party Ledger',
      hindiTitle: 'खाता / पार्टी लेजर',
      description: 'Customer credit books, supplier udhar ledgers & WhatsApp payment reminders',
      icon: Users2,
      iconBg: 'bg-blue-50 text-blue-600 border border-blue-200/60',
      badge: 'Udhar Book',
      badgeColor: 'bg-blue-100 text-blue-800'
    },
    {
      id: 'data-sync',
      title: 'Cloud & Offline Sync',
      hindiTitle: 'क्लाउड सिंक व बैकअप',
      description: '100% Offline Dexie storage with Firebase & Google Drive backup hub',
      icon: RefreshCw,
      iconBg: 'bg-indigo-50 text-indigo-600 border border-indigo-200/60',
      badge: isOnline ? 'Online Hub' : 'Offline Ready',
      badgeColor: isOnline ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
    },
    {
      id: 'settings',
      title: 'Shop Settings',
      hindiTitle: 'दुकान सेटिंग्स व प्रोफाइल',
      description: 'Store branding, thermal bill formats, UPI QR codes & barcode preferences',
      icon: Settings,
      iconBg: 'bg-slate-100 text-slate-700 border border-slate-200',
      badge: 'Admin',
      badgeColor: 'bg-slate-200 text-slate-800'
    }
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto overflow-y-auto bg-slate-50 select-none">
      
      {/* ========================================================================= */}
      {/* 1. TOP WELCOME & HIGH-FREQUENCY ACTION BAR */}
      {/* ========================================================================= */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-5 bg-white border border-slate-200/80 p-6 rounded-2xl shadow-xs">
        
        {/* Store Brand / Info Header */}
        <div className="flex items-center gap-4">
          {shopProfile.logoUrl ? (
            <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-100 p-1.5 flex items-center justify-center shadow-xs shrink-0">
              <img 
                src={shopProfile.logoUrl} 
                alt={shopProfile.name} 
                className="w-full h-full object-contain"
              />
            </div>
          ) : (
            <div className="w-14 h-14 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-md shadow-indigo-600/20 text-white font-black text-xl shrink-0">
              <Award className="w-7 h-7" />
            </div>
          )}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-indigo-50 text-indigo-700 font-bold text-xs rounded-lg">
                Dashboard & Analytics
              </span>
              <span className="text-xs text-slate-400 font-medium hidden sm:inline">
                • {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              </span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">
              {shopProfile.name}
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              {shopProfile.address}, {shopProfile.city} • Ph: {shopProfile.phone}
            </p>
          </div>
        </div>

        {/* High-Frequency Actions Group: [ New Billing / POS ], [ Inventory / Stock ], [ Recent Bills / Sales Report ] + [ Utilities Dropdown ] */}
        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          
          {/* Action 1: New Billing / POS (Primary) */}
          <button
            type="button"
            id="btn-dash-pos"
            onClick={() => setActiveTab('pos')}
            className="h-11 px-4 sm:px-5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-black rounded-xl shadow-md shadow-indigo-600/20 transition active:scale-95 flex items-center gap-2 cursor-pointer"
            title="Open POS Terminal (New Bill)"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>New Billing / POS</span>
          </button>

          {/* Action 2: Inventory / Stock */}
          <button
            type="button"
            id="btn-dash-inventory"
            onClick={() => setActiveTab('inventory')}
            className="h-11 px-3.5 sm:px-4 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 text-xs sm:text-sm font-bold rounded-xl transition active:scale-95 flex items-center gap-2 cursor-pointer"
            title="Manage Products & Stock Inventory"
          >
            <Package className="w-4 h-4 text-sky-600" />
            <span>Inventory / Stock</span>
            {lowStockProducts.length > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] bg-amber-500 text-white font-black rounded-md">
                {lowStockProducts.length}
              </span>
            )}
          </button>

          {/* Action 3: Recent Bills / Sales Report */}
          <button
            type="button"
            id="btn-dash-sales-report"
            onClick={() => setActiveTab('daily-sales')}
            className="h-11 px-3.5 sm:px-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 text-xs sm:text-sm font-bold rounded-xl transition active:scale-95 flex items-center gap-2 cursor-pointer"
            title="View Daily Sales Log & Invoices"
          >
            <Receipt className="w-4 h-4 text-emerald-600" />
            <span>Recent Bills / Sales</span>
          </button>

          {/* Utilities & Settings Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              id="btn-dash-utilities-dropdown"
              onClick={() => setShowUtilitiesDropdown(!showUtilitiesDropdown)}
              className={`h-11 px-3.5 rounded-xl border text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer ${
                showUtilitiesDropdown
                  ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                  : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
              }`}
              title="Utilities, Reports, Khata & Admin Settings"
            >
              <Settings className="w-4 h-4 text-slate-500" />
              <span>Utilities / Settings</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${showUtilitiesDropdown ? 'rotate-180 text-white' : 'text-slate-400'}`} />
            </button>

            {/* Dropdown Menu Overlay */}
            {showUtilitiesDropdown && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-40 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-3.5 py-2 border-b border-slate-100">
                  <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                    ⚙️ Utilities & Admin Tools
                  </p>
                </div>

                <div className="p-1 space-y-0.5">
                  {utilityItems.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setShowUtilitiesDropdown(false);
                          setActiveTab(item.id);
                        }}
                        className="w-full px-3 py-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-3 transition cursor-pointer text-left group"
                      >
                        <div className={`p-2 rounded-xl shrink-0 ${item.iconBg}`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h5 className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition truncate">
                              {item.title}
                            </h5>
                          </div>
                          <p className="text-[10px] text-slate-400 truncate mt-0.5">
                            {item.description}
                          </p>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition shrink-0" />
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. REAL-TIME METRIC CARDS */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* Card 1: Today's Sales */}
        <div className="bg-white border border-slate-200/80 p-6 rounded-2xl relative overflow-hidden group hover:shadow-md transition shadow-2xs">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {t.todaySales}
              </p>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1.5 tracking-tight">
                {formatCurrency(todaySales)}
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-1">
                {todayInvoices.length} {language === 'hi' ? 'बिल कटे हैं' : 'Invoices Billed Today'}
              </p>
            </div>
            <div className="p-3.5 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100/60">
              <IndianRupee className="w-6 h-6" />
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
            <div className="bg-indigo-600 h-full rounded-full w-3/4"></div>
          </div>
        </div>

        {/* Card 2: Today's Gross Profit */}
        <div className="bg-white border border-slate-200/80 p-6 rounded-2xl relative overflow-hidden group hover:shadow-md transition shadow-2xs">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {t.todayProfit}
              </p>
              <h3 className="text-2xl sm:text-3xl font-black text-emerald-600 mt-1.5 tracking-tight">
                {formatCurrency(todayGrossProfit)}
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-1">
                {todaySales > 0 ? `${((todayGrossProfit / todaySales) * 100).toFixed(1)}% Gross Margin` : 'Net Cashier Margin'}
              </p>
            </div>
            <div className="p-3.5 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-100/60">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full w-2/3"></div>
          </div>
        </div>

        {/* Card 3: Stock Inventory Valuation */}
        <div className="bg-white border border-slate-200/80 p-6 rounded-2xl relative overflow-hidden group hover:shadow-md transition shadow-2xs">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
                {t.stockValuation}
              </p>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1.5 tracking-tight">
                {formatCurrency(totalStockValuationLanding)}
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-1">
                MRP: <span className="text-slate-700 font-bold">{formatCurrency(totalStockValuationMrp)}</span> ({totalStockUnits} Pcs)
              </p>
            </div>
            <div className="p-3.5 bg-sky-50 text-sky-600 rounded-2xl border border-sky-100/60">
              <Package className="w-6 h-6" />
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full mt-4 overflow-hidden">
            <div className="bg-sky-500 h-full rounded-full w-4/5"></div>
          </div>
        </div>

        {/* Card 4: Low Stock Alerts */}
        <div 
          onClick={() => setActiveTab('inventory')}
          className="bg-amber-50/50 border border-amber-200/80 hover:border-amber-400 p-6 rounded-2xl relative overflow-hidden cursor-pointer transition shadow-2xs hover:shadow-md"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                {t.lowStockAlerts}
              </p>
              <h3 className="text-2xl sm:text-3xl font-black text-amber-950 mt-1.5 tracking-tight">
                {lowStockProducts.length} <span className="text-sm font-normal text-amber-800">Items</span>
              </h3>
              <p className="text-xs text-amber-900 font-semibold mt-1 flex items-center gap-1">
                {language === 'hi' ? 'री-ऑर्डर लिस्ट देखने के लिए क्लिक करें' : 'Click to view re-order list'}
                <ChevronRight className="w-3.5 h-3.5" />
              </p>
            </div>
            <div className="p-3.5 bg-amber-100 text-amber-700 rounded-2xl border border-amber-200/80">
              <AlertTriangle className="w-6 h-6" />
            </div>
          </div>
          <div className="w-full bg-amber-200/60 h-1.5 rounded-full mt-4 overflow-hidden">
            <div className="bg-amber-600 h-full rounded-full w-1/2"></div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. PROMINENT TOP SELLING BRANDS & ANALYTICS SECTION */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-7 space-y-6 shadow-2xs">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-black text-slate-900">
                {language === 'hi' ? 'टॉप सेलिंग ब्रांड्स व परफॉर्मेंस' : 'Top Selling Brands & Product Performance'}
              </h3>
            </div>
            <p className="text-xs text-slate-400 font-medium mt-1">
              {language === 'hi' 
                ? 'Milton, Cello, Borosil, Treo सहित सभी ब्रांड्स की बिक्री, मुनाफा और स्टॉक का रियल-टाइम रैंक चार्ट' 
                : 'Real-time sales value, units sold, and profit metrics across all brands with 1-click product drill-down'}
            </p>
          </div>

          {/* Sort Controller Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100/80 p-1.5 rounded-2xl border border-slate-200/60">
            <span className="text-[11px] uppercase font-extrabold text-slate-400 px-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Rank:
            </span>
            <button
              type="button"
              onClick={() => setBrandSortBy('sales')}
              className={`h-8 px-3.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                brandSortBy === 'sales'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sales (₹)
            </button>
            <button
              type="button"
              onClick={() => setBrandSortBy('units')}
              className={`h-8 px-3.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                brandSortBy === 'units'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Units Sold
            </button>
            <button
              type="button"
              onClick={() => setBrandSortBy('profit')}
              className={`h-8 px-3.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                brandSortBy === 'profit'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Net Profit
            </button>
            <button
              type="button"
              onClick={() => setBrandSortBy('stock')}
              className={`h-8 px-3.5 text-xs font-bold rounded-xl transition cursor-pointer ${
                brandSortBy === 'stock'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Stock Valuation
            </button>
          </div>
        </div>

        {/* Visual Ranked Bar Chart for Top Brands */}
        <div className="bg-slate-50/50 border border-slate-100 rounded-2xl p-4 sm:p-6 space-y-3">
          <div className="flex justify-between items-center text-xs">
            <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-indigo-600" />
              {language === 'hi' ? 'ब्रांड्स रैंकिंग चार्ट' : 'Brand Revenue & Performance Comparison'}
            </h4>
            <span className="text-slate-400 font-medium text-[11px]">
              Click any bar or card below to view models
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartBrandsData}
                margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                onClick={(e: any) => {
                  if (e && e.activePayload && e.activePayload[0]) {
                    setSelectedBrandDrilldown(e.activePayload[0].payload.raw);
                  }
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#94a3b8" 
                  tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }}
                  interval={0}
                />
                <YAxis 
                  stroke="#94a3b8" 
                  tick={{ fontSize: 11, fill: '#94a3b8' }}
                  tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
                />
                <Tooltip
                  cursor={{ fill: '#e0e7ff', opacity: 0.3 }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white border border-slate-100 p-4 rounded-2xl shadow-xl text-xs space-y-1.5">
                          <p className="font-black text-slate-900 text-sm">{data.name}</p>
                          <div className="pt-1.5 border-t border-slate-100 space-y-1">
                            <p className="text-slate-600 font-medium">Sales Revenue: <strong className="text-slate-900">₹{Number(data.sales).toLocaleString('en-IN')}</strong></p>
                            <p className="text-slate-600 font-medium">Units Sold: <strong className="text-emerald-600">{data.units} Pcs</strong></p>
                            <p className="text-slate-600 font-medium">Net Profit: <strong className="text-indigo-600">₹{Number(data.profit).toLocaleString('en-IN')}</strong></p>
                            <p className="text-slate-600 font-medium">In-Stock Remaining: <strong className="text-sky-600">{data.stock} Pcs</strong></p>
                          </div>
                          <p className="text-[10px] text-indigo-600 font-bold pt-1">Click to drill down</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="sales" radius={[8, 8, 0, 0]} cursor="pointer">
                  {chartBrandsData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={index === 0 ? '#4f46e5' : index === 1 ? '#6366f1' : index === 2 ? '#818cf8' : '#cbd5e1'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Brand Analytics Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedBrands.map((bStat, idx) => {
            const barWidth = brandSortBy === 'units'
              ? Math.max(8, (bStat.totalUnitsSold / maxUnits) * 100)
              : Math.max(8, (bStat.totalSalesValue / maxSales) * 100);

            return (
              <div
                key={bStat.brand}
                onClick={() => setSelectedBrandDrilldown(bStat)}
                className="bg-slate-50/50 border border-slate-100 hover:border-indigo-300 hover:bg-white p-5 rounded-2xl cursor-pointer transition-all space-y-3.5 group shadow-2xs hover:shadow-md"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <span className={`w-8 h-8 rounded-xl text-xs font-black flex items-center justify-center ${
                      idx === 0 
                        ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30' 
                        : idx === 1 
                        ? 'bg-indigo-500 text-white' 
                        : idx === 2 
                        ? 'bg-slate-700 text-white' 
                        : 'bg-slate-200 text-slate-700'
                    }`}>
                      #{idx + 1}
                    </span>
                    <div>
                      <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-indigo-600 transition flex items-center gap-1.5">
                        {bStat.brand}
                        {idx === 0 && <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />}
                      </h4>
                      <p className="text-xs text-slate-400 font-medium">
                        {bStat.totalProducts} Models • {bStat.totalStockUnits} In Stock
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition" />
                </div>

                {/* Sales & Profit Row */}
                <div className="grid grid-cols-3 gap-2 text-xs pt-2 border-t border-slate-100">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold">Total Sales</span>
                    <p className="font-extrabold text-slate-900">{formatCurrency(bStat.totalSalesValue)}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold">Units Sold</span>
                    <p className="font-bold text-emerald-600">{bStat.totalUnitsSold} Pcs</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold">Net Profit</span>
                    <p className="font-bold text-indigo-600">{formatCurrency(bStat.totalProfitContribution)}</p>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-slate-200/80 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="bg-indigo-600 group-hover:bg-indigo-500 h-full rounded-full transition-all"
                    style={{ width: `${barWidth}%` }}
                  ></div>
                </div>

                <div className="flex justify-between items-center text-[11px] text-slate-400">
                  <span>Stock: <strong className="text-slate-700">{formatCurrency(bStat.inventoryValuation)}</strong></span>
                  <span className="text-indigo-600 font-extrabold group-hover:underline">Drill-Down →</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. DEDICATED UTILITIES & ADMIN TOOLS CARD SECTION (BOTTOM MODULE) */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-7 space-y-5 shadow-2xs">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-slate-100 text-slate-700 rounded-xl">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                <span>⚙️ Utilities & Admin Tools</span>
              </h3>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                Manage GST filings, party udhar credit books, cloud data sync, and shop billing settings
              </p>
            </div>
          </div>
        </div>

        {/* 4 Clean Utility Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {utilityItems.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className="bg-slate-50 hover:bg-white border border-slate-200/80 hover:border-indigo-400 p-5 rounded-2xl cursor-pointer transition-all duration-150 flex flex-col justify-between group shadow-2xs hover:shadow-md"
              >
                <div className="space-y-3">
                  <div className="flex justify-between items-start">
                    <div className={`p-3 rounded-2xl ${item.iconBg} shadow-2xs`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-lg ${item.badgeColor}`}>
                      {item.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-extrabold text-sm text-slate-900 group-hover:text-indigo-600 transition">
                      {item.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 font-medium mt-1 leading-relaxed line-clamp-2">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs font-bold text-indigo-600 group-hover:text-indigo-700">
                  <span>Open Tool</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 1-Click Brand Drill-Down Modal Component */}
      <BrandDrilldownModal
        brandData={selectedBrandDrilldown}
        onClose={() => setSelectedBrandDrilldown(null)}
        language={language}
      />
    </div>
  );
};
