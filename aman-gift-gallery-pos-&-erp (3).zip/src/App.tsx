import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardModule } from './components/dashboard/DashboardModule';
import { DailySalesLogModule } from './components/sales/DailySalesLogModule';
import { MonthlySalesReportModule } from './components/sales/MonthlySalesReportModule';
import { PosModule } from './components/pos/PosModule';
import { InventoryModule } from './components/inventory/InventoryModule';
import { PurchasesModule } from './components/purchases/PurchasesModule';
import { ReportsModule } from './components/reports/ReportsModule';
import { KhataModule } from './components/khata/KhataModule';
import { SettingsModule } from './components/settings/SettingsModule';
import { DataSyncView } from './components/sync/DataSyncView';
import { InvoiceModal } from './components/modals/InvoiceModal';
import { CameraScannerModal } from './components/common/CameraScannerModal';

import { CustomerReceiptView } from './components/common/CustomerReceiptView';
import { AppLockGatekeeper } from './components/security/AppLockGatekeeper';

const AppContent: React.FC = () => {
  const { activeTab } = useApp();
  const [hash, setHash] = React.useState(() => (typeof window !== 'undefined' ? window.location.hash : ''));

  React.useEffect(() => {
    const onHashChange = () => setHash(window.location.hash);
    window.addEventListener('hashchange', onHashChange);
    window.addEventListener('popstate', onHashChange);
    return () => {
      window.removeEventListener('hashchange', onHashChange);
      window.removeEventListener('popstate', onHashChange);
    };
  }, []);

  const isReceiptView = () => {
    if (typeof window !== 'undefined') {
      const currentHash = window.location.hash || hash || '';
      if (
        currentHash.startsWith('#/invoice/') || 
        currentHash.startsWith('#/receipt-view') || 
        currentHash.startsWith('#/receipt/') ||
        currentHash.startsWith('#/receipt')
      ) {
        return true;
      }
      const urlParams = new URLSearchParams(window.location.search);
      let hashParams = new URLSearchParams();
      if (currentHash.includes('?')) {
        hashParams = new URLSearchParams(currentHash.split('?')[1]);
      }
      return !!(
        urlParams.get('b') || hashParams.get('b') ||
        urlParams.get('data') || hashParams.get('data') ||
        urlParams.get('bill') || hashParams.get('bill')
      );
    }
    return false;
  };

  if (isReceiptView()) {
    return <CustomerReceiptView />;
  }

  const renderActiveModule = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardModule />;
      case 'daily-sales':
        return <DailySalesLogModule />;
      case 'monthly-sales':
        return <MonthlySalesReportModule />;
      case 'inventory':
        return <InventoryModule />;
      case 'pos':
        return <PosModule />;
      case 'purchases':
        return <PurchasesModule />;
      case 'reports':
        return <ReportsModule />;
      case 'khata':
        return <KhataModule />;
      case 'data-sync':
        return <DataSyncView />;
      case 'settings':
        return <SettingsModule />;
      default:
        return <DashboardModule />;
    }
  };

  return (
    <AppLockGatekeeper>
      <div className="flex flex-col h-screen w-screen bg-slate-50 text-slate-900 overflow-hidden font-sans print:h-auto print:w-auto print:overflow-visible print:bg-white">
        {/* Top Navigation Bar */}
        <div className="print:hidden">
          <Navbar />
        </div>

        {/* Main Workspace Body */}
        <div className="flex-1 flex overflow-hidden print:hidden">
          {/* Left Navigation Sidebar */}
          <Sidebar />

          {/* Dynamic Active Module Area */}
          <main className="flex-1 flex flex-col overflow-hidden bg-slate-50 relative">
            {renderActiveModule()}
          </main>
        </div>

        {/* Global Interactive Overlays & Modals */}
        <InvoiceModal />
        <CameraScannerModal />
      </div>
    </AppLockGatekeeper>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
