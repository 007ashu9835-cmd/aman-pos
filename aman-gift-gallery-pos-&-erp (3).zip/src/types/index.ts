export type Language = 'en' | 'hi';

export type InvoiceTemplateType = 'navy' | 'minimal' | 'bold' | 'thermal';

export type PaymentMethod = 'cash' | 'upi' | 'card' | 'khata' | 'split';

export type ItemCategory = 
  | 'Bottles / Flasks'
  | 'Crockery'
  | 'Kitchenware'
  | 'Glassware'
  | 'Home Essentials'
  | 'Gifts'
  | 'Toys'
  | 'Plastics'
  | 'Furniture'
  | 'Electronics'
  | 'General'
  | (string & {});

export const DEFAULT_MASTER_CATEGORIES: string[] = [
  'Bottles / Flasks',
  'Crockery',
  'Kitchenware',
  'Glassware',
  'Home Essentials',
  'Gifts',
  'Toys',
  'Plastics',
  'Furniture',
  'Electronics',
  'General'
];

export type WastageReason = 'Damaged' | 'Broken' | 'Defect' | 'Sample' | 'Expired';

export interface ShopProfile {
  name: string;
  tagline: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  altPhone?: string;
  email?: string;
  gstin?: string;
  logoUrl?: string;
  signatureUrl?: string; // Digital signature transparent png
  bankName?: string;
  accountNo?: string;
  ifscCode?: string;
  upiId?: string;
  footerDisclaimer: string;
}

export interface Product {
  id?: number;
  barcode: string;
  name: string;
  brand: string;
  category: ItemCategory;
  hsn: string;
  stockQty: number;
  minThreshold: number; // Low stock alert threshold (e.g. 2-3)
  basicPurchaseRate: number; // Before GST
  gstPercent: number; // e.g. 12, 18, 5, 0
  landingCost: number; // basicPurchaseRate + (basicPurchaseRate * gstPercent / 100)
  mrp: number;
  sellingPrice: number;
  lastPurchaseDate?: string;
  lastSoldDate?: string;
  isUnbranded?: boolean;
  vendor?: string;
  createdAt: string;
  updatedAt: string;
}

export const STANDARD_WARRANTY_OPTIONS = [
  'No Warranty',
  '3 Months Warranty',
  '6 Months Warranty',
  '1 Year Warranty',
  '2 Years Warranty',
  '3 Years Warranty',
  '5 Years Warranty',
  'Custom Warranty'
] as const;

export interface CartItem {
  product: Product;
  quantity: number; // Can be negative for exchange return items
  customPrice?: number; // Overridden selling price
  discountPercent?: number; // e.g. 5%
  isExchangeReturn?: boolean; // True if returned in exchange mode
  exchangeReason?: string;
  warranty?: {
    enabled: boolean;
    duration: string; // e.g. "No Warranty", "3 Months Warranty", "6 Months Warranty", "1 Year Warranty", "2 Years Warranty", "3 Years Warranty", "5 Years Warranty", "Custom Warranty"
  };
}

export interface Invoice {
  id?: number;
  invoiceNumber: string;
  date: string;
  time: string;
  customerName?: string;
  customerPhone?: string;
  customerGstin?: string;
  items: CartItem[];
  subtotal: number;
  totalDiscount: number;
  totalGst: number;
  roundOff: number;
  grandTotal: number;
  totalLandingCost: number; // Cashier private metric
  cashierProfit: number; // grandTotal - totalLandingCost
  paymentMethod: PaymentMethod;
  paymentBreakdown?: {
    cash?: number;
    upi?: number;
    card?: number;
    khata?: number;
  };
  isExchangeBill: boolean;
  exchangeNetDelta?: number; // Negative or positive difference
  isGstInvoice?: boolean; // True when GST Tax Invoice is explicitly enabled
  notes?: string;
  template: InvoiceTemplateType;
  showDiscount: boolean;
  showSavings: boolean;
  createdAt: string;
}

export interface PurchaseBillItem {
  name: string;
  brand: string;
  category: ItemCategory;
  quantity: number;
  basicRate: number;
  gstPercent: number;
  landingCost: number;
  mrp: number;
  sellingPrice: number;
  hsn?: string;
}

export interface PurchaseEntry {
  id?: number;
  voucherNo: string;
  supplierName: string;
  supplierGstin?: string;
  billDate: string;
  items: PurchaseBillItem[];
  totalBasicAmount: number;
  totalGstAmount: number;
  totalBillAmount: number;
  paymentStatus: 'paid' | 'pending' | 'partial';
  source: 'manual' | 'gemini-ocr' | 'sheets-sync';
  rawBillImage?: string;
  syncedToSheets?: boolean;
  createdAt: string;
}

export interface Party {
  id?: number;
  type: 'customer' | 'supplier';
  name: string;
  phone: string;
  address?: string;
  gstin?: string;
  balance: number; // Positive = Receivable (हमें लेना है), Negative = Payable (हमें देना है)
  isArchived?: boolean; // When balance is 0
  createdAt: string;
  updatedAt: string;
}

export interface KhataTransaction {
  id?: number;
  partyId: number;
  partyName: string;
  partyType: 'customer' | 'supplier';
  type: 'got' | 'gave'; // 'got' = Green आया (Received), 'gave' = Red दिया (Gave / Credit)
  amount: number;
  date: string;
  invoiceNumber?: string;
  notes?: string;
  paymentMode: 'cash' | 'upi' | 'bank' | 'other';
  createdAt: string;
}

export interface WastageEntry {
  id?: number;
  productId: number;
  productName: string;
  brand: string;
  quantity: number;
  reason: WastageReason;
  lossValue: number; // quantity * landingCost
  date: string;
  notes?: string;
}

export interface GoogleSheetsSyncConfig {
  sheetId: string;
  sheetName: string;
  lastSyncTime?: string;
  autoSyncEnabled: boolean;
  isConnected: boolean;
}
