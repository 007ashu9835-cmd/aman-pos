import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { 
  Language, 
  InvoiceTemplateType, 
  Product, 
  CartItem, 
  Invoice, 
  ShopProfile, 
  GoogleSheetsSyncConfig,
  PaymentMethod,
  Party,
  DEFAULT_MASTER_CATEGORIES
} from '../types';
import { db, DEFAULT_SHOP_PROFILE, initializeDatabase } from '../db';
import { calculateCartTotals } from '../utils/calculations';
import {
  saveProductToCloud,
  bulkSaveProductsToCloud,
  deleteProductFromCloud,
  saveInvoiceToCloud,
  bulkSaveInvoicesToCloud,
  deleteInvoiceFromCloud,
  saveCategoriesToCloud,
  saveShopProfileToCloud,
  subscribeToProducts,
  subscribeToInvoices,
  subscribeToMasterCategories,
  subscribeToShopProfile,
  fetchAllProductsFromCloud,
  fetchAllInvoicesFromCloud,
  fetchMasterCategoriesFromCloud,
  fetchShopProfileFromCloud,
  clearAllCloudData,
  CloudAccountProfile,
  loginWithEmailCloud,
  registerWithEmailCloud,
  loginWithGoogleCloud,
  logoutCloudUser,
  sendCloudPasswordReset,
  subscribeToCloudAuthState
} from '../lib/firebase';
import confetti from 'canvas-confetti';

interface AppContextType {
  // Language & Navigation
  language: Language;
  setLanguage: (lang: Language) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;

  // Shop Profile & Settings
  shopProfile: ShopProfile;
  updateShopProfile: (profile: Partial<ShopProfile>) => Promise<void>;
  selectedTemplate: InvoiceTemplateType;
  setSelectedTemplate: (template: InvoiceTemplateType) => void;
  sheetsConfig: GoogleSheetsSyncConfig;
  updateSheetsConfig: (config: Partial<GoogleSheetsSyncConfig>) => Promise<void>;

  // Products & Inventory
  products: Product[];
  inventory: Product[];
  setInventory: (inventory: any[]) => void;
  lowStockProducts: Product[];
  refreshData: () => Promise<void>;
  addProduct: (product: Omit<Product, 'id'>) => Promise<number>;
  updateProduct: (id: number, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: number) => Promise<void>;
  deleteInvoice: (idOrInvoiceNumber: number | string) => Promise<{ success: boolean; invoice?: Invoice; restoredItemsCount: number }>;
  wipeAllData: () => Promise<void>;

  // Master Categories
  masterCategories: string[];
  addCategory: (name: string) => Promise<void>;
  updateCategory: (oldName: string, newName: string) => Promise<void>;
  deleteCategory: (name: string) => Promise<void>;
  registerDiscoveredCategories: (categories: string[]) => Promise<void>;

  // Real-Time Firebase Cloud Sync & Master Account
  isCloudSyncEnabled: boolean;
  setIsCloudSyncEnabled: (enabled: boolean) => void;
  cloudSyncStatus: 'synced' | 'syncing' | 'offline' | 'error';
  lastCloudSyncTimestamp: string | null;
  cloudSyncedProductsCount: number;
  cloudSyncedInvoicesCount: number;
  pushAllLocalToCloud: () => Promise<{ productsCount: number; invoicesCount: number }>;
  pullAllFromCloud: () => Promise<{ productsCount: number; invoicesCount: number }>;
  isCloudSyncing: boolean;
  cloudUser: CloudAccountProfile | null;
  loginWithEmailAccount: (email: string, pass: string) => Promise<void>;
  registerWithEmailAccount: (email: string, pass: string, name?: string) => Promise<void>;
  loginWithGoogleAccount: () => Promise<void>;
  logoutCloudAccount: () => Promise<void>;
  sendPasswordResetLink: (email: string) => Promise<void>;

  // POS & Cart
  cart: CartItem[];
  customerName: string;
  setCustomerName: (name: string) => void;
  customerPhone: string;
  setCustomerPhone: (phone: string) => void;
  isExchangeMode: boolean;
  setIsExchangeMode: (enabled: boolean) => void;
  showCashierProfit: boolean;
  setShowCashierProfit: (show: boolean) => void;
  showDiscountOnBill: boolean;
  setShowDiscountOnBill: (show: boolean) => void;
  showSavingsOnBill: boolean;
  setShowSavingsOnBill: (show: boolean) => void;
  isGstInvoiceEnabled: boolean;
  setIsGstInvoiceEnabled: (enabled: boolean) => void;
  
  // Cart Actions
  addToCart: (product: Product, isExchangeReturn?: boolean, initialPrice?: number) => void;
  removeFromCart: (index: number) => void;
  updateCartQuantity: (index: number, quantity: number) => void;
  updateCartPrice: (index: number, customPrice: number) => void;
  updateCartDiscount: (index: number, discountPercent: number) => void;
  toggleCartWarranty: (index: number, enabled: boolean, duration?: string) => void;
  clearCart: () => void;
  completeCheckout: (paymentMethod: PaymentMethod, notes?: string, isGstInvoice?: boolean) => Promise<Invoice>;

  // Modal / Preview States
  activeInvoicePreview: Invoice | null;
  setActiveInvoicePreview: (invoice: Invoice | null) => void;
  isCloudSyncModalOpen: boolean;
  setIsCloudSyncModalOpen: (open: boolean) => void;
  isCameraScannerOpen: boolean;
  setIsCameraScannerOpen: (open: boolean) => void;
  cameraScannerMode: 'pos' | 'inventory' | 'purchases';
  cameraScanCallback: ((barcode: string) => void) | null;
  setCameraScanCallback: (cb: ((barcode: string) => void) | null) => void;
  openCameraScanner: (mode?: 'pos' | 'inventory' | 'purchases', onScan?: (barcode: string) => void) => void;

  // Sound feedback
  playBeep: (type?: 'scan' | 'success' | 'alert' | 'exchange') => void;

  // Global Offline State
  isOnline: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState<string>('pos');
  const [shopProfile, setShopProfile] = useState<ShopProfile>(() => {
    try {
      const cached = localStorage.getItem('shopProfile');
      if (cached) {
        return { ...DEFAULT_SHOP_PROFILE, ...JSON.parse(cached) };
      }
    } catch (e) {
      console.warn('Failed to load shopProfile from localStorage', e);
    }
    return DEFAULT_SHOP_PROFILE;
  });
  const [selectedTemplate, setSelectedTemplate] = useState<InvoiceTemplateType>('navy');
  const [sheetsConfig, setSheetsConfig] = useState<GoogleSheetsSyncConfig>({
    sheetId: '1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms',
    sheetName: 'Aman_Gift_Gallery_Sales_Inventory',
    autoSyncEnabled: true,
    isConnected: true
  });

  const [products, setProducts] = useState<Product[]>([]);
  const [lowStockProducts, setLowStockProducts] = useState<Product[]>([]);
  
  // Master Categories State (Synchronized across storage, UI and imports)
  const [masterCategories, setMasterCategories] = useState<string[]>(() => {
    try {
      const isWiped = localStorage.getItem('app_data_wiped') === 'true';
      if (isWiped) return [];
      const cached = localStorage.getItem('master_categories');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse master_categories from localStorage', e);
    }
    return [];
  });

  // Cart & POS State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [isExchangeMode, setIsExchangeMode] = useState<boolean>(false);
  const [showCashierProfit, setShowCashierProfit] = useState<boolean>(true);
  const [showDiscountOnBill, setShowDiscountOnBill] = useState<boolean>(true);
  const [showSavingsOnBill, setShowSavingsOnBill] = useState<boolean>(true);
  const [isGstInvoiceEnabled, setIsGstInvoiceEnabled] = useState<boolean>(false);

  // Modals
  const [activeInvoicePreview, setActiveInvoicePreview] = useState<Invoice | null>(null);
  const [isCloudSyncModalOpen, setIsCloudSyncModalOpen] = useState<boolean>(false);
  const [isCameraScannerOpen, setIsCameraScannerOpen] = useState<boolean>(false);
  const [cameraScannerMode, setCameraScannerMode] = useState<'pos' | 'inventory' | 'purchases'>('pos');
  const [cameraScanCallback, setCameraScanCallback] = useState<((barcode: string) => void) | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Real-Time Firebase Cloud Sync State
  const [isCloudSyncEnabled, setIsCloudSyncEnabled] = useState<boolean>(() => {
    return localStorage.getItem('cloud_sync_enabled') !== 'false';
  });
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'synced' | 'syncing' | 'offline' | 'error'>('synced');
  const [isCloudSyncing, setIsCloudSyncing] = useState<boolean>(false);
  const [lastCloudSyncTimestamp, setLastCloudSyncTimestamp] = useState<string | null>(() => {
    return localStorage.getItem('last_cloud_sync_timestamp') || null;
  });
  const [cloudSyncedProductsCount, setCloudSyncedProductsCount] = useState<number>(0);
  const [cloudSyncedInvoicesCount, setCloudSyncedInvoicesCount] = useState<number>(0);
  
  // Cloud Master Account State
  const [cloudUser, setCloudUser] = useState<CloudAccountProfile | null>(() => {
    try {
      const saved = localStorage.getItem('cloud_user_account');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Track Firebase Auth State changes for Cloud Sync Account
  useEffect(() => {
    const unsub = subscribeToCloudAuthState((user) => {
      if (user && !user.isAnonymous) {
        const prof: CloudAccountProfile = {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName || user.email?.split('@')[0] || 'Store Admin',
          photoURL: user.photoURL,
          isAnonymous: false
        };
        setCloudUser(prof);
        try {
          localStorage.setItem('cloud_user_account', JSON.stringify(prof));
        } catch (e) {
          console.warn('LocalStorage error:', e);
        }
      } else {
        setCloudUser(null);
        localStorage.removeItem('cloud_user_account');
      }
    });
    return () => unsub();
  }, []);

  // Ref to prevent local updates triggered by remote onSnapshot from creating update loops
  const isApplyingRemoteSyncRef = useRef<boolean>(false);

  // Audio feedback synthesis using Web Audio API (zero external asset dependency, 100% offline)
  const playBeep = useCallback((type: 'scan' | 'success' | 'alert' | 'exchange' = 'scan') => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'scan') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.08);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.08);
      } else if (type === 'exchange') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        osc.frequency.setValueAtTime(600, audioCtx.currentTime + 0.05);
        gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } else if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08); // A5
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      } else if (type === 'alert') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.2);
      }
    } catch (e) {
      console.warn('Audio playback error (browser policy):', e);
    }
  }, []);

  const setInventory = useCallback((newInv: any[]) => {
    const formatted: Product[] = (newInv || []).map((row, idx) => ({
      id: typeof row.id === 'number' ? row.id : (parseInt(String(row.id).replace(/\D/g, ''), 10) || idx + 1),
      barcode: row.sku || row.barcode || String(row.id) || `AGG-${10000 + idx}`,
      name: row['Item Name'] || row.name || 'Item',
      brand: row.brand || 'General',
      category: (row.Category || row.category || 'General') as any,
      hsn: row.hsn || '999999',
      stockQty: Number(row['Stock left '] || row['Stock left'] || row.stock || row.stockQty || 0),
      minThreshold: Number(row['Reorder Level'] || row.reorderLevel || row.minThreshold || 2),
      basicPurchaseRate: Number(row['purchase price'] || row.purchasePrice || row.basicPurchaseRate || 0),
      gstPercent: row.gstPercent !== undefined ? Number(row.gstPercent) : 18,
      landingCost: Number(row.landingCost || (Number(row['purchase price'] || row.purchasePrice || 0) * 1.18)),
      mrp: Number(row.MRP || row.mrp || (Number(row['purchase price'] || row.purchasePrice || 0) * 1.35) || 100),
      sellingPrice: Number(row.sellingPrice || row.MRP || row.mrp || (Number(row['purchase price'] || row.purchasePrice || 0) * 1.35) || 100),
      createdAt: row.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));
    setProducts(formatted);
    setLowStockProducts(formatted.filter(p => p.stockQty <= (p.minThreshold || 2)));
  }, []);

  const refreshData = useCallback(async () => {
    try {
      const allProducts = await fetchAllProductsFromCloud().catch(() => db.products.toArray());
      setProducts(allProducts);

      const lowStock = allProducts.filter(p => p.stockQty <= (p.minThreshold || 3));
      setLowStockProducts(lowStock);

      const profileSetting = await db.settings.get('shopProfile');
      if (profileSetting?.value) {
        setShopProfile(profileSetting.value);
      }

      const syncSetting = await db.settings.get('sheetsSync');
      if (syncSetting?.value) {
        setSheetsConfig(syncSetting.value);
      }

      // Sync categories with database settings and any existing products
      const categorySetting = await db.settings.get('masterCategories');
      const dbCategories: string[] = categorySetting?.value || [];
      const productCategories = allProducts.map(p => p.category).filter(Boolean);
      
      setMasterCategories(prev => {
        const combined = Array.from(new Set([...prev, ...dbCategories, ...productCategories]));
        try {
          localStorage.setItem('master_categories', JSON.stringify(combined));
        } catch (e) {
          console.warn('Failed to save master_categories to localStorage', e);
        }
        return combined;
      });
    } catch (err) {
      console.error('Error fetching data from Dexie:', err);
    }
  }, []);

  // Initialize DB on mount and check for direct view_invoice URL links
  useEffect(() => {
    async function setup() {
      await initializeDatabase();
      await refreshData();

      // Check if URL has ?view_invoice=... or ?invoice=... to open directly (e.g. from WhatsApp Link)
      try {
        const searchParams = new URLSearchParams(window.location.search);
        const invQuery = searchParams.get('view_invoice') || searchParams.get('invoice') || searchParams.get('inv');
        if (invQuery) {
          const found = await db.invoices.where('invoiceNumber').equals(invQuery).first();
          if (found) {
            setActiveInvoicePreview(found);
          } else {
            const numId = parseInt(invQuery, 10);
            if (!isNaN(numId)) {
              const byId = await db.invoices.get(numId);
              if (byId) setActiveInvoicePreview(byId);
            }
          }
        }
      } catch (urlErr) {
        console.warn('Could not parse view_invoice parameter:', urlErr);
      }
    }
    setup();

    const handleOnline = () => {
      setIsOnline(true);
      setCloudSyncStatus('synced');
    };
    const handleOffline = () => {
      setIsOnline(false);
      setCloudSyncStatus('offline');
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [refreshData]);

  // Real-Time Firebase Firestore Synchronization Listeners (Cross-device Mobile ↔ Desktop)
  useEffect(() => {
    if (!isCloudSyncEnabled) return;

    let unsubProducts: (() => void) | null = null;
    let unsubInvoices: (() => void) | null = null;
    let unsubCategories: (() => void) | null = null;
    let unsubProfile: (() => void) | null = null;

    try {
      // 1. Real-time Products Sync
      unsubProducts = subscribeToProducts(
        async (remoteProducts) => {
          isApplyingRemoteSyncRef.current = true;
          try {
            if (remoteProducts.length > 0) {
              // Update local Dexie with remote products to ensure offline cache is updated
              for (const p of remoteProducts) {
                if (p.barcode) {
                  const localByBarcode = await db.products.where('barcode').equals(p.barcode).first();
                  if (localByBarcode?.id) {
                    await db.products.put({ ...p, id: localByBarcode.id });
                  } else {
                    await db.products.put(p);
                  }
                } else if (p.id) {
                  await db.products.put(p);
                }
              }
              const localAll = await db.products.toArray();
              setProducts(localAll);
              setLowStockProducts(localAll.filter(p => p.stockQty <= (p.minThreshold || 3)));
              setCloudSyncedProductsCount(remoteProducts.length);
              setCloudSyncStatus('synced');
              const nowIso = new Date().toISOString();
              setLastCloudSyncTimestamp(nowIso);
              localStorage.setItem('last_cloud_sync_timestamp', nowIso);
            } else {
              // Firestore products collection is empty
              const isWiped = localStorage.getItem('app_data_wiped') === 'true';
              if (isWiped) {
                await db.products.clear();
                setProducts([]);
                setLowStockProducts([]);
                setCloudSyncedProductsCount(0);
              }
            }
          } catch (err) {
            console.warn('Error applying remote products:', err);
          } finally {
            isApplyingRemoteSyncRef.current = false;
          }
        },
        (err) => {
          console.warn('Firestore products listener error:', err);
          if (!navigator.onLine) setCloudSyncStatus('offline');
        }
      );

      // 2. Real-time Invoices / Billing Sales Sync
      unsubInvoices = subscribeToInvoices(
        async (remoteInvoices) => {
          if (remoteInvoices.length > 0) {
            try {
              for (const inv of remoteInvoices) {
                const existing = await db.invoices.where('invoiceNumber').equals(inv.invoiceNumber).first();
                if (existing?.id) {
                  await db.invoices.put({ ...inv, id: existing.id });
                } else {
                  await db.invoices.put(inv);
                }
              }
              setCloudSyncedInvoicesCount(remoteInvoices.length);
              setCloudSyncStatus('synced');
            } catch (err) {
              console.warn('Error applying remote invoices:', err);
            }
          } else {
            const isWiped = localStorage.getItem('app_data_wiped') === 'true';
            if (isWiped) {
              await db.invoices.clear();
              setCloudSyncedInvoicesCount(0);
            }
          }
        },
        (err) => {
          console.warn('Firestore invoices listener error:', err);
        }
      );

      // 3. Real-time Master Categories Sync
      unsubCategories = subscribeToMasterCategories(
        async (remoteCategories) => {
          if (Array.isArray(remoteCategories)) {
            setMasterCategories(remoteCategories);
            try {
              localStorage.setItem('master_categories', JSON.stringify(remoteCategories));
            } catch (e) {
              console.warn('Failed to save master_categories to localStorage', e);
            }
            await db.settings.put({ key: 'masterCategories', value: remoteCategories });
          }
        },
        (err) => {
          console.warn('Firestore categories listener error:', err);
        }
      );

      // 4. Real-time Shop Profile Sync
      unsubProfile = subscribeToShopProfile(
        async (remoteProfile) => {
          if (remoteProfile?.name) {
            setShopProfile(remoteProfile);
            localStorage.setItem('shopProfile', JSON.stringify(remoteProfile));
            await db.settings.put({ key: 'shopProfile', value: remoteProfile });
          }
        },
        (err) => {
          console.warn('Firestore profile listener error:', err);
        }
      );
    } catch (e) {
      console.warn('Firebase listeners initialization error:', e);
    }

    return () => {
      if (unsubProducts) unsubProducts();
      if (unsubInvoices) unsubInvoices();
      if (unsubCategories) unsubCategories();
      if (unsubProfile) unsubProfile();
    };
  }, [isCloudSyncEnabled]);

  // Global Hardware Barcode Gun listener
  useEffect(() => {
    let barcodeBuffer = '';
    let lastKeyTime = Date.now();

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is currently typing in an input/textarea
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        return;
      }

      const currentTime = Date.now();
      // Hardware barcode guns type very rapidly (typically < 35ms between characters)
      if (currentTime - lastKeyTime > 150) {
        barcodeBuffer = '';
      }
      lastKeyTime = currentTime;

      if (e.key === 'Enter') {
        if (barcodeBuffer.length >= 3) {
          const scannedCode = barcodeBuffer.trim();
          barcodeBuffer = '';
          if (activeTab === 'pos') {
            handleGunScan(scannedCode);
          }
        }
      } else if (e.key.length === 1) {
        barcodeBuffer += e.key;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [products, isExchangeMode, activeTab]);

  const handleGunScan = (barcode: string) => {
    const product = products.find(p => p.barcode === barcode || p.name.toLowerCase().includes(barcode.toLowerCase()));
    if (product) {
      addToCart(product, isExchangeMode);
      playBeep(isExchangeMode ? 'exchange' : 'scan');
    } else {
      playBeep('alert');
      console.warn(`Scanned barcode "${barcode}" not found in inventory`);
    }
  };

  const updateShopProfile = async (profile: Partial<ShopProfile>) => {
    const updated = { ...shopProfile, ...profile };
    setShopProfile(updated);
    try {
      localStorage.setItem('shopProfile', JSON.stringify(updated));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    await db.settings.put({ key: 'shopProfile', value: updated });
    // Push update to Firebase Cloud in real-time
    if (isCloudSyncEnabled) {
      saveShopProfileToCloud(updated).catch(e => console.warn('Cloud profile sync error:', e));
    }
  };

  const updateSheetsConfig = async (config: Partial<GoogleSheetsSyncConfig>) => {
    const updated = { ...sheetsConfig, ...config };
    setSheetsConfig(updated);
    await db.settings.put({ key: 'sheetsSync', value: updated });
  };

  const addProduct = async (product: Omit<Product, 'id'>) => {
    const id = await db.products.add(product as Product);
    const savedProd: Product = { ...product, id: id as number };
    await refreshData();
    // Real-time Cloud Firestore synchronization
    if (isCloudSyncEnabled) {
      saveProductToCloud(savedProd).catch(e => console.warn('Cloud product add sync error:', e));
    }
    return id as number;
  };

  const updateProduct = async (id: number, product: Partial<Product>) => {
    await db.products.update(id, { ...product, updatedAt: new Date().toISOString() });
    const updatedProd = await db.products.get(id);
    await refreshData();
    // Real-time Cloud Firestore synchronization
    if (isCloudSyncEnabled && updatedProd) {
      saveProductToCloud(updatedProd).catch(e => console.warn('Cloud product update sync error:', e));
    }
  };

  const deleteProduct = async (id: number) => {
    const existing = await db.products.get(id);
    await db.products.delete(id);
    await refreshData();
    // Real-time Cloud Firestore deletion
    if (isCloudSyncEnabled && existing) {
      deleteProductFromCloud(existing.barcode || existing.id || id).catch(e => console.warn('Cloud product delete sync error:', e));
    }
  };

  const deleteInvoice = async (invoiceIdOrNumber: number | string) => {
    try {
      let invoice: Invoice | undefined;
      let targetId: number | undefined;

      if (typeof invoiceIdOrNumber === 'number') {
        targetId = invoiceIdOrNumber;
        invoice = await db.invoices.get(invoiceIdOrNumber);
      } else {
        invoice = await db.invoices.where('invoiceNumber').equals(invoiceIdOrNumber).first();
        if (invoice?.id) targetId = invoice.id;
      }

      if (!invoice && typeof invoiceIdOrNumber === 'string') {
        const num = parseInt(invoiceIdOrNumber, 10);
        if (!isNaN(num)) {
          invoice = await db.invoices.get(num);
          if (invoice?.id) targetId = invoice.id;
        }
      }

      if (!invoice) {
        if (targetId) await db.invoices.delete(targetId);
        await refreshData();
        return { success: true, restoredItemsCount: 0 };
      }

      let restoredItemsCount = 0;
      // Auto-restore Inventory Stock:
      // Loop through all items present in that deleted invoice
      for (const item of invoice.items) {
        const itemQty = item.quantity;
        let targetProduct: Product | undefined;

        if (item.product?.id) {
          targetProduct = await db.products.get(item.product.id);
        }
        if (!targetProduct && item.product?.barcode) {
          targetProduct = await db.products.where('barcode').equals(item.product.barcode).first();
        }
        if (!targetProduct && item.product?.name) {
          targetProduct = await db.products.where('name').equals(item.product.name).first();
        }

        if (targetProduct && targetProduct.id) {
          // If sold (quantity > 0 and !isExchangeReturn): add quantity back to stock
          // If exchange return (quantity < 0 or isExchangeReturn): remove returned item from stock
          const delta = (item.isExchangeReturn || itemQty < 0) ? -Math.abs(itemQty) : Math.abs(itemQty);
          const newStock = Math.max(0, targetProduct.stockQty + delta);
          const updatedTarget = {
            ...targetProduct,
            stockQty: newStock,
            updatedAt: new Date().toISOString()
          };
          await db.products.update(targetProduct.id, {
            stockQty: newStock,
            updatedAt: new Date().toISOString()
          });
          if (isCloudSyncEnabled) {
            saveProductToCloud(updatedTarget).catch(e => console.warn('Cloud stock restore sync error:', e));
          }
          restoredItemsCount += Math.abs(itemQty);
        }
      }

      // If khata transaction, reverse credit
      if (invoice.paymentMethod === 'khata' && invoice.customerName) {
        const party = await db.parties
          .filter(p => p.type === 'customer' && (p.name.toLowerCase() === invoice.customerName.toLowerCase() || (invoice.customerPhone && p.phone === invoice.customerPhone)))
          .first();
        if (party && party.id) {
          const newBal = Math.max(0, party.balance - invoice.grandTotal);
          await db.parties.update(party.id, {
            balance: newBal,
            isArchived: newBal === 0,
            updatedAt: new Date().toISOString()
          });
        }
      }

      // Delete from local database
      if (invoice.id) {
        await db.invoices.delete(invoice.id);
      } else if (targetId) {
        await db.invoices.delete(targetId);
      } else {
        await db.invoices.where('invoiceNumber').equals(invoice.invoiceNumber).delete();
      }

      // Delete from Firebase Cloud in real-time
      if (isCloudSyncEnabled && invoice.invoiceNumber) {
        deleteInvoiceFromCloud(invoice.invoiceNumber).catch(e => console.warn('Cloud invoice delete sync error:', e));
      }

      // Clean from localStorage pos_invoices if present
      try {
        const cached = localStorage.getItem('pos_invoices');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed)) {
            const filtered = parsed.filter((i: any) => i.id !== invoice.id && i.invoiceNumber !== invoice.invoiceNumber);
            localStorage.setItem('pos_invoices', JSON.stringify(filtered));
          }
        }
      } catch (err) {
        console.warn('Could not update localStorage pos_invoices', err);
      }

      await refreshData();
      return { success: true, invoice, restoredItemsCount };
    } catch (err) {
      console.error('Error deleting invoice and restoring stock:', err);
      throw err;
    }
  };

  // Master Categories Actions
  const addCategory = async (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    
    // Check if category already exists (case-insensitive)
    const exists = masterCategories.some(c => c.toLowerCase() === trimmed.toLowerCase());
    if (exists) return;

    const updated = [...masterCategories, trimmed];
    setMasterCategories(updated);
    try {
      localStorage.setItem('master_categories', JSON.stringify(updated));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    await db.settings.put({ key: 'masterCategories', value: updated });
    if (isCloudSyncEnabled) {
      saveCategoriesToCloud(updated).catch(e => console.warn('Cloud category add sync error:', e));
    }
    playBeep('success');
  };

  const updateCategory = async (oldName: string, newName: string) => {
    const trimmedNew = newName.trim();
    if (!trimmedNew || oldName === trimmedNew) return;

    const updated: string[] = masterCategories.map(c => c.toLowerCase() === oldName.toLowerCase() ? trimmedNew : c);
    const uniqueUpdated: string[] = Array.from(new Set<string>(updated));
    setMasterCategories(uniqueUpdated);

    try {
      localStorage.setItem('master_categories', JSON.stringify(uniqueUpdated));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    await db.settings.put({ key: 'masterCategories', value: uniqueUpdated });
    if (isCloudSyncEnabled) {
      saveCategoriesToCloud(uniqueUpdated).catch(e => console.warn('Cloud category update sync error:', e));
    }

    // Update all existing products in DB with old category name
    const matchingProducts = await db.products.filter(p => p.category?.toLowerCase() === oldName.toLowerCase()).toArray();
    for (const prod of matchingProducts) {
      if (prod.id) {
        await db.products.update(prod.id, { category: trimmedNew });
        if (isCloudSyncEnabled) {
          saveProductToCloud({ ...prod, category: trimmedNew }).catch(e => console.warn('Cloud category prod sync error:', e));
        }
      }
    }
    await refreshData();
    playBeep('success');
  };

  const deleteCategory = async (nameToDelete: string) => {
    const trimmed = nameToDelete.trim();
    const updated = masterCategories.filter(c => c.toLowerCase() !== trimmed.toLowerCase());
    const finalCategories = updated.length > 0 ? updated : ['General'];
    setMasterCategories(finalCategories);

    try {
      localStorage.setItem('master_categories', JSON.stringify(finalCategories));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    await db.settings.put({ key: 'masterCategories', value: finalCategories });
    if (isCloudSyncEnabled) {
      saveCategoriesToCloud(finalCategories).catch(e => console.warn('Cloud category delete sync error:', e));
    }

    // Fallback products of deleted category to 'General'
    const matchingProducts = await db.products.filter(p => p.category?.toLowerCase() === trimmed.toLowerCase()).toArray();
    for (const prod of matchingProducts) {
      if (prod.id) {
        await db.products.update(prod.id, { category: 'General' });
        if (isCloudSyncEnabled) {
          saveProductToCloud({ ...prod, category: 'General' }).catch(e => console.warn('Cloud prod fallback sync error:', e));
        }
      }
    }
    await refreshData();
    playBeep('alert');
  };

  const registerDiscoveredCategories = async (discovered: string[]) => {
    if (!Array.isArray(discovered) || discovered.length === 0) return;
    
    const validNew = discovered
      .map(c => (c || '').trim())
      .filter(c => c.length > 1 && c.toLowerCase() !== 'undefined' && c.toLowerCase() !== 'null');

    if (validNew.length === 0) return;

    let hasChange = false;
    const currentList = [...masterCategories];
    
    for (const cat of validNew) {
      const exists = currentList.some(c => c.toLowerCase() === cat.toLowerCase());
      if (!exists) {
        currentList.push(cat);
        hasChange = true;
      }
    }

    if (hasChange) {
      setMasterCategories(currentList);
      try {
        localStorage.setItem('master_categories', JSON.stringify(currentList));
      } catch (e) {
        console.warn('LocalStorage error:', e);
      }
      await db.settings.put({ key: 'masterCategories', value: currentList });
      if (isCloudSyncEnabled) {
        saveCategoriesToCloud(currentList).catch(e => console.warn('Cloud discovered categories sync error:', e));
      }
    }
  };

  // Push all local Dexie records to Firebase Cloud
  const pushAllLocalToCloud = async (): Promise<{ productsCount: number; invoicesCount: number }> => {
    setIsCloudSyncing(true);
    setCloudSyncStatus('syncing');
    try {
      const localProducts = await db.products.toArray();
      const localInvoices = await db.invoices.toArray();
      
      if (localProducts.length > 0) {
        await bulkSaveProductsToCloud(localProducts);
      }
      if (localInvoices.length > 0) {
        await bulkSaveInvoicesToCloud(localInvoices);
      }
      if (masterCategories.length > 0) {
        await saveCategoriesToCloud(masterCategories);
      }
      if (shopProfile) {
        await saveShopProfileToCloud(shopProfile);
      }

      const nowIso = new Date().toISOString();
      setLastCloudSyncTimestamp(nowIso);
      localStorage.setItem('last_cloud_sync_timestamp', nowIso);
      setCloudSyncedProductsCount(localProducts.length);
      setCloudSyncedInvoicesCount(localInvoices.length);
      setCloudSyncStatus('synced');
      playBeep('success');
      return { productsCount: localProducts.length, invoicesCount: localInvoices.length };
    } catch (err) {
      console.error('Error pushing local data to cloud:', err);
      setCloudSyncStatus('error');
      playBeep('alert');
      throw err;
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Pull all data from Firebase Cloud to local Dexie & state
  const pullAllFromCloud = async (): Promise<{ productsCount: number; invoicesCount: number }> => {
    if (!navigator.onLine) {
      setCloudSyncStatus('offline');
      return { productsCount: products.length, invoicesCount: 0 };
    }
    setIsCloudSyncing(true);
    setCloudSyncStatus('syncing');
    try {
      const remoteProducts = await fetchAllProductsFromCloud();
      const remoteInvoices = await fetchAllInvoicesFromCloud();
      const remoteCategories = await fetchMasterCategoriesFromCloud();
      const remoteProfile = await fetchShopProfileFromCloud();

      if (remoteProducts.length > 0) {
        for (const p of remoteProducts) {
          if (p.barcode) {
            const localByBarcode = await db.products.where('barcode').equals(p.barcode).first();
            if (localByBarcode?.id) {
              await db.products.put({ ...p, id: localByBarcode.id });
            } else {
              await db.products.put(p);
            }
          } else {
            await db.products.put(p);
          }
        }
      }

      if (remoteInvoices.length > 0) {
        for (const inv of remoteInvoices) {
          const existing = await db.invoices.where('invoiceNumber').equals(inv.invoiceNumber).first();
          if (existing?.id) {
            await db.invoices.put({ ...inv, id: existing.id });
          } else {
            await db.invoices.put(inv);
          }
        }
      }

      if (remoteCategories && remoteCategories.length > 0) {
        setMasterCategories(prev => Array.from(new Set([...prev, ...remoteCategories])));
        await db.settings.put({ key: 'masterCategories', value: remoteCategories });
      }

      if (remoteProfile) {
        setShopProfile(remoteProfile);
        await db.settings.put({ key: 'shopProfile', value: remoteProfile });
      }

      await refreshData();
      const nowIso = new Date().toISOString();
      setLastCloudSyncTimestamp(nowIso);
      localStorage.setItem('last_cloud_sync_timestamp', nowIso);
      setCloudSyncedProductsCount(remoteProducts.length);
      setCloudSyncedInvoicesCount(remoteInvoices.length);
      setCloudSyncStatus('synced');
      return { productsCount: remoteProducts.length, invoicesCount: remoteInvoices.length };
    } catch (err: any) {
      console.warn('Pull cloud data notice:', err?.message || err);
      const isOfflineErr = err?.message?.includes('offline') || err?.code === 'unavailable';
      setCloudSyncStatus(isOfflineErr ? 'offline' : 'error');
      return { productsCount: products.length, invoicesCount: 0 };
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Cloud Account Authentication methods
  const loginWithEmailAccount = async (email: string, pass: string) => {
    setIsCloudSyncing(true);
    try {
      const user = await loginWithEmailCloud(email, pass);
      const prof: CloudAccountProfile = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || user.email?.split('@')[0] || 'Store Admin',
        photoURL: user.photoURL,
        isAnonymous: false
      };
      setCloudUser(prof);
      localStorage.setItem('cloud_user_account', JSON.stringify(prof));
      setIsCloudSyncEnabled(true);
      localStorage.setItem('cloud_sync_enabled', 'true');
      playBeep('success');
      // Automatically pull latest cloud data on login to sync mobile/desktop
      pullAllFromCloud().catch(e => console.warn('Auto-pull after login:', e));
      return prof;
    } catch (err) {
      playBeep('alert');
      throw err;
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const registerWithEmailAccount = async (email: string, pass: string, name?: string) => {
    setIsCloudSyncing(true);
    try {
      const user = await registerWithEmailCloud(email, pass, name);
      const prof: CloudAccountProfile = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || name || user.email?.split('@')[0] || 'Store Admin',
        photoURL: user.photoURL,
        isAnonymous: false
      };
      setCloudUser(prof);
      localStorage.setItem('cloud_user_account', JSON.stringify(prof));
      setIsCloudSyncEnabled(true);
      localStorage.setItem('cloud_sync_enabled', 'true');
      playBeep('success');
      // Push existing local inventory & sales to cloud for the newly registered account
      pushAllLocalToCloud().catch(e => console.warn('Auto-push after register:', e));
      return prof;
    } catch (err) {
      playBeep('alert');
      throw err;
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const loginWithGoogleAccount = async () => {
    setIsCloudSyncing(true);
    try {
      const user = await loginWithGoogleCloud();
      const prof: CloudAccountProfile = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || user.email?.split('@')[0] || 'Store Admin',
        photoURL: user.photoURL,
        isAnonymous: false
      };
      setCloudUser(prof);
      localStorage.setItem('cloud_user_account', JSON.stringify(prof));
      setIsCloudSyncEnabled(true);
      localStorage.setItem('cloud_sync_enabled', 'true');
      playBeep('success');
      // Automatically pull latest cloud data on Google login to sync devices
      pullAllFromCloud().catch(e => console.warn('Auto-pull after Google login:', e));
    } catch (err) {
      playBeep('alert');
      throw err;
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const logoutCloudAccount = async () => {
    try {
      await logoutCloudUser();
      setCloudUser(null);
      localStorage.removeItem('cloud_user_account');
      localStorage.removeItem('app_master_uid');
      localStorage.removeItem('app_master_email');
      localStorage.setItem('app_force_relogin', 'true');
      window.dispatchEvent(new CustomEvent('app_lock_required'));
      playBeep('scan');
    } catch (err) {
      console.warn('Logout error:', err);
      setCloudUser(null);
      localStorage.removeItem('cloud_user_account');
      localStorage.removeItem('app_master_uid');
      localStorage.removeItem('app_master_email');
      localStorage.setItem('app_force_relogin', 'true');
      window.dispatchEvent(new CustomEvent('app_lock_required'));
    }
  };

  const sendPasswordResetLink = async (email: string) => {
    await sendCloudPasswordReset(email);
    playBeep('success');
  };

  const wipeAllData = async () => {
    try {
      // Clear all transactional and inventory tables from IndexedDB
      await db.products.clear();
      await db.invoices.clear();
      await db.purchases.clear();
      await db.parties.clear();
      await db.khataTransactions.clear();
      await db.wastage.clear();
      await db.settings.clear();

      // Ensure minimal clean shop profile exists
      await db.settings.put({
        key: 'shopProfile',
        value: DEFAULT_SHOP_PROFILE
      });

      // Clear all browser storage keys completely
      try {
        localStorage.clear();
        sessionStorage.clear();
      } catch (e) {
        console.warn('Storage clear error:', e);
      }

      // Flag localStorage to prevent auto-reseed of demo data permanently
      localStorage.setItem('app_data_wiped', 'true');

      // Purge cloud Firestore records permanently
      try {
        await clearAllCloudData();
      } catch (cloudErr) {
        console.warn('Could not clear cloud Firestore data during wipe:', cloudErr);
      }

      // Instantly wipe all active memory state to 0 items
      setProducts([]);
      setLowStockProducts([]);
      setCart([]);
      setMasterCategories([]);
      setCustomerName('');
      setCustomerPhone('');
      setActiveInvoicePreview(null);
      setCloudSyncedProductsCount(0);
      setCloudSyncedInvoicesCount(0);

      playBeep('success');
    } catch (err) {
      console.error('Error wiping all application data:', err);
      playBeep('alert');
      throw err;
    }
  };

  // Cart operations
  const addToCart = (product: Product, isExchangeReturn = false, initialPrice?: number) => {
    playBeep(isExchangeReturn ? 'exchange' : 'scan');
    setCart(prevCart => {
      // Find if item already exists with matching exchange status
      const existingIndex = prevCart.findIndex(
        item => item.product.id === product.id && Boolean(item.isExchangeReturn) === Boolean(isExchangeReturn)
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        const currentQty = updated[existingIndex].quantity;
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: isExchangeReturn ? currentQty - 1 : currentQty + 1
        };
        return updated;
      } else {
        return [
          ...prevCart,
          {
            product,
            quantity: isExchangeReturn ? -1 : 1,
            customPrice: initialPrice !== undefined ? initialPrice : (product.sellingPrice !== undefined && product.sellingPrice > 0 ? product.sellingPrice : (product.mrp || 0)),
            discountPercent: 0,
            isExchangeReturn: Boolean(isExchangeReturn),
            warranty: { enabled: false, duration: 'No Warranty' }
          }
        ];
      }
    });
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const updateCartQuantity = (index: number, quantity: number) => {
    if (quantity === 0) {
      removeFromCart(index);
      return;
    }
    setCart(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], quantity };
      return updated;
    });
  };

  const updateCartPrice = (index: number, customPrice: number) => {
    setCart(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], customPrice: Math.max(0, customPrice) };
      return updated;
    });
  };

  const updateCartDiscount = (index: number, discountPercent: number) => {
    setCart(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], discountPercent: Math.min(100, Math.max(0, discountPercent)) };
      return updated;
    });
  };

  const toggleCartWarranty = (index: number, enabled: boolean, duration = 'No Warranty') => {
    setCart(prev => {
      const updated = [...prev];
      if (updated[index]) {
        const isNoWarranty = !enabled || duration === 'No Warranty' || !duration;
        updated[index] = {
          ...updated[index],
          warranty: {
            enabled: !isNoWarranty,
            duration: isNoWarranty ? 'No Warranty' : duration
          }
        };
      }
      return updated;
    });
  };

  const clearCart = () => {
    setCart([]);
    setCustomerName('');
    setCustomerPhone('');
    setIsExchangeMode(false);
  };

  const openCameraScanner = (mode: 'pos' | 'inventory' | 'purchases' = 'pos', onScan?: (barcode: string) => void) => {
    setCameraScannerMode(mode);
    if (onScan) {
      setCameraScanCallback(() => onScan);
    } else {
      setCameraScanCallback(null);
    }
    setIsCameraScannerOpen(true);
  };

  // Complete checkout & inventory deduction / restock
  const completeCheckout = async (paymentMethod: PaymentMethod, notes = '', isGst?: boolean): Promise<Invoice> => {
    if (cart.length === 0) {
      throw new Error('Cart is empty');
    }

    const isTaxInvoice = isGst !== undefined ? isGst : isGstInvoiceEnabled;
    const totals = calculateCartTotals(cart, isTaxInvoice);
    const dateObj = new Date();
    const invoiceNumber = `AGG-${dateObj.getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

    const newInvoice: Omit<Invoice, 'id'> = {
      invoiceNumber,
      date: dateObj.toISOString().split('T')[0],
      time: dateObj.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      customerName: customerName.trim() || 'Walk-in Customer',
      customerPhone: customerPhone.trim(),
      items: [...cart],
      subtotal: totals.subtotal,
      totalDiscount: totals.totalDiscount,
      totalGst: totals.totalGst,
      roundOff: totals.roundOff,
      grandTotal: totals.grandTotal,
      totalLandingCost: totals.totalLandingCost,
      cashierProfit: totals.cashierProfit,
      paymentMethod,
      isExchangeBill: cart.some(i => i.quantity < 0 || i.isExchangeReturn),
      exchangeNetDelta: totals.netExchangeDelta,
      isGstInvoice: isTaxInvoice,
      notes,
      template: selectedTemplate,
      showDiscount: showDiscountOnBill,
      showSavings: showSavingsOnBill,
      createdAt: dateObj.toISOString()
    };

    // Save invoice to Dexie
    const invoiceId = await db.invoices.add(newInvoice as Invoice);
    const savedInvoice = { ...newInvoice, id: invoiceId as number };

    // Update product stocks in Dexie:
    // If quantity is positive (sold) -> reduce stock
    // If quantity is negative (exchange return) -> increment stock
    const updatedProductsList: Product[] = [];
    for (const item of cart) {
      if (item.product.id) {
        const prod = await db.products.get(item.product.id);
        if (prod) {
          const newQty = prod.stockQty - item.quantity;
          const updatedProd: Product = {
            ...prod,
            stockQty: Math.max(0, newQty),
            lastSoldDate: dateObj.toISOString().split('T')[0],
            updatedAt: dateObj.toISOString()
          };
          await db.products.update(item.product.id, {
            stockQty: Math.max(0, newQty),
            lastSoldDate: dateObj.toISOString().split('T')[0],
            updatedAt: dateObj.toISOString()
          });
          updatedProductsList.push(updatedProd);
        }
      }
    }

    // Real-Time Firebase Cloud Sync for Invoice & Stock Updates
    if (isCloudSyncEnabled) {
      saveInvoiceToCloud(savedInvoice).catch(e => console.warn('Cloud sync error on invoice save:', e));
      if (updatedProductsList.length > 0) {
        bulkSaveProductsToCloud(updatedProductsList).catch(e => console.warn('Cloud sync error on stock deduction:', e));
      }
    }

    // If Khata (credit) payment, link/update customer party balance in Khata ledger
    if (paymentMethod === 'khata' && customerName.trim()) {
      let existingParty = await db.parties
        .filter(p => p.type === 'customer' && (p.name.toLowerCase() === customerName.toLowerCase() || (customerPhone && p.phone === customerPhone)))
        .first();

      if (existingParty?.id) {
        const newBalance = existingParty.balance + totals.grandTotal;
        await db.parties.update(existingParty.id, {
          balance: newBalance,
          isArchived: newBalance === 0,
          updatedAt: dateObj.toISOString()
        });
        await db.khataTransactions.add({
          partyId: existingParty.id,
          partyName: existingParty.name,
          partyType: 'customer',
          type: 'gave',
          amount: totals.grandTotal,
          date: dateObj.toISOString().split('T')[0],
          invoiceNumber,
          notes: `Credit sale via POS Bill #${invoiceNumber}`,
          paymentMode: 'other',
          createdAt: dateObj.toISOString()
        });
      } else {
        const newPartyId = await db.parties.add({
          type: 'customer',
          name: customerName.trim(),
          phone: customerPhone.trim(),
          balance: totals.grandTotal,
          createdAt: dateObj.toISOString(),
          updatedAt: dateObj.toISOString()
        });
        await db.khataTransactions.add({
          partyId: newPartyId as number,
          partyName: customerName.trim(),
          partyType: 'customer',
          type: 'gave',
          amount: totals.grandTotal,
          date: dateObj.toISOString().split('T')[0],
          invoiceNumber,
          notes: `Credit sale via POS Bill #${invoiceNumber}`,
          paymentMode: 'other',
          createdAt: dateObj.toISOString()
        });
      }
    }

    // Trigger celebration & audio
    playBeep('success');
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 }
    });

    // Refresh store state
    await refreshData();
    clearCart();
    setActiveInvoicePreview(savedInvoice);

    return savedInvoice;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        activeTab,
        setActiveTab,
        shopProfile,
        updateShopProfile,
        selectedTemplate,
        setSelectedTemplate,
        sheetsConfig,
        updateSheetsConfig,
        products,
        inventory: products,
        setInventory,
        lowStockProducts,
        refreshData,
        addProduct,
        updateProduct,
        deleteProduct,
        deleteInvoice,
        wipeAllData,
        masterCategories,
        addCategory,
        updateCategory,
        deleteCategory,
        registerDiscoveredCategories,
        cart,
        customerName,
        setCustomerName,
        customerPhone,
        setCustomerPhone,
        isExchangeMode,
        setIsExchangeMode,
        showCashierProfit,
        setShowCashierProfit,
        showDiscountOnBill,
        setShowDiscountOnBill,
        showSavingsOnBill,
        setShowSavingsOnBill,
        isGstInvoiceEnabled,
        setIsGstInvoiceEnabled,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        updateCartPrice,
        updateCartDiscount,
        toggleCartWarranty,
        clearCart,
        completeCheckout,
        activeInvoicePreview,
        setActiveInvoicePreview,
        isCloudSyncModalOpen,
        setIsCloudSyncModalOpen,
        isCameraScannerOpen,
        setIsCameraScannerOpen,
        cameraScannerMode,
        cameraScanCallback,
        setCameraScanCallback,
        openCameraScanner,
        playBeep,
        isOnline,
        isCloudSyncEnabled,
        setIsCloudSyncEnabled: (enabled: boolean) => {
          setIsCloudSyncEnabled(enabled);
          localStorage.setItem('cloud_sync_enabled', String(enabled));
        },
        cloudSyncStatus,
        lastCloudSyncTimestamp,
        cloudSyncedProductsCount,
        cloudSyncedInvoicesCount,
        pushAllLocalToCloud,
        pullAllFromCloud,
        isCloudSyncing,
        cloudUser,
        loginWithEmailAccount,
        registerWithEmailAccount,
        loginWithGoogleAccount,
        logoutCloudAccount,
        sendPasswordResetLink
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
