import jsPDF from 'jspdf';
import { Product, ShopProfile } from '../types';
import { formatCurrency } from './calculations';

export interface POItem {
  product: Product;
  reorderQty: number;
}

export interface POGenerateOptions {
  brandName: string;
  items: POItem[];
  shopProfile: ShopProfile;
  poNumber?: string;
  date?: string;
  notes?: string;
}

/**
 * Generates an official, high-resolution Purchase Order (PO) PDF for a specific brand/supplier
 */
export function generateBrandPurchaseOrderPdf(options: POGenerateOptions): {
  doc: jsPDF;
  poNumber: string;
  fileName: string;
  blob: Blob;
} {
  const { brandName, items, shopProfile, notes } = options;

  const cleanBrandCode = brandName
    .replace(/[^a-zA-Z0-9]/g, '')
    .substring(0, 4)
    .toUpperCase() || 'GEN';
  
  const now = new Date();
  const dateStr = options.date || now.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
  const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const poNumber = options.poNumber || `PO-${cleanBrandCode}-${yearMonth}-${String(now.getDate()).padStart(2, '0')}`;
  const fileName = `Purchase_Order_${brandName.replace(/\s+/g, '_')}_${yearMonth}.pdf`;

  // Create A4 PDF (210mm x 297mm)
  const doc = new jsPDF({
    orientation: 'p',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 12;
  const contentWidth = pageWidth - margin * 2; // 186mm

  // Sort items by Category, then by Name
  const sortedItems = [...items].sort((a, b) => {
    const catA = (a.product.category || 'Uncategorized').toLowerCase();
    const catB = (b.product.category || 'Uncategorized').toLowerCase();
    if (catA < catB) return -1;
    if (catA > catB) return 1;
    const nameA = (a.product.name || '').toLowerCase();
    const nameB = (b.product.name || '').toLowerCase();
    return nameA.localeCompare(nameB);
  });

  // Header Banner
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(margin, margin, contentWidth, 24, 'F');

  // Title in Banner
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(shopProfile.name.toUpperCase() || 'AMAN GIFT GALLERY', margin + 6, margin + 9);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225); // slate-300
  const storeSub = `${shopProfile.address}, ${shopProfile.city}, ${shopProfile.state} | Phone: ${shopProfile.phone} | GSTIN: ${shopProfile.gstin || 'N/A'}`;
  doc.text(storeSub.substring(0, 85), margin + 6, margin + 15);
  doc.text('PREMIUM CROCKERY • GIFTS • KITCHENWARE • HOME ESSENTIALS', margin + 6, margin + 19.5);

  // PO Badge right side
  doc.setFillColor(79, 70, 229); // indigo-600
  doc.roundedRect(pageWidth - margin - 52, margin + 4, 46, 16, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('PURCHASE ORDER', pageWidth - margin - 29, margin + 11, { align: 'center' });
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.text(poNumber, pageWidth - margin - 29, margin + 16, { align: 'center' });

  // Supplier & PO Metadata Box
  let curY = margin + 28;

  // Box 1: Supplier / Brand Info
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.3);
  doc.roundedRect(margin, curY, (contentWidth / 2) - 2, 28, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139); // slate-500
  doc.text('SUPPLIER / BRAND DISTRIBUTOR', margin + 4, curY + 6);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(`${brandName} Distributorship / Supply`, margin + 4, curY + 13);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`Official Re-Order for: ${brandName} Catalog Items`, margin + 4, curY + 18);
  doc.text('Attn: Authorized Brand Sales Manager / Supplier', margin + 4, curY + 23);

  // Box 2: Order Metadata
  const rightBoxX = margin + (contentWidth / 2) + 2;
  doc.setFillColor(255, 255, 255); // Pure white background (#FFFFFF)
  doc.setDrawColor(226, 232, 240); // Clean border (#E2E8F0)
  doc.roundedRect(rightBoxX, curY, (contentWidth / 2) - 2, 28, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42); // Solid dark black (#0F172A)
  doc.text('ORDER & DISPATCH DETAILS', rightBoxX + 4, curY + 6);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42); // Solid dark black (#0F172A)
  doc.text(`PO Number:`, rightBoxX + 4, curY + 12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(poNumber, rightBoxX + 30, curY + 12);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`PO Date:`, rightBoxX + 4, curY + 17);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(dateStr, rightBoxX + 30, curY + 17);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`Delivery To:`, rightBoxX + 4, curY + 22);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`${shopProfile.name} (${shopProfile.city})`, rightBoxX + 30, curY + 22);

  curY += 33;

  // Table Column Coordinates
  // contentWidth = 186
  // S.No: 10, Item: 76, Barcode: 32, Stock: 22, Reorder: 24, Unit: 22
  const colX = {
    sno: margin + 3,
    item: margin + 14,
    barcode: margin + 92,
    stock: margin + 128,
    reorder: margin + 152,
    unit: margin + 174
  };

  // Table Header
  doc.setFillColor(241, 245, 249); // slate-100
  doc.roundedRect(margin, curY, contentWidth, 8, 1.5, 1.5, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.line(margin, curY + 8, margin + contentWidth, curY + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59); // slate-800
  doc.text('S.NO', colX.sno, curY + 5.5);
  doc.text('ITEM NAME / MODEL SPECIFICATION', colX.item, curY + 5.5);
  doc.text('BARCODE / SKU', colX.barcode, curY + 5.5);
  doc.text('CURR. STOCK', colX.stock, curY + 5.5);
  doc.text('REORDER QTY', colX.reorder, curY + 5.5);
  doc.text('UNIT', colX.unit, curY + 5.5);

  curY += 10;

  // Table Rows
  let totalReorderQty = 0;
  let totalEstValue = 0;

  sortedItems.forEach((item, index) => {
    const isEven = index % 2 === 0;
    const rowHeight = 7.5;

    // Check if new page needed
    if (curY > pageHeight - 50) {
      doc.addPage();
      curY = margin + 10;

      // Repeat Table Header
      doc.setFillColor(241, 245, 249);
      doc.roundedRect(margin, curY, contentWidth, 8, 1.5, 1.5, 'F');
      doc.setDrawColor(203, 213, 225);
      doc.line(margin, curY + 8, margin + contentWidth, curY + 8);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(30, 41, 59);
      doc.text('S.NO', colX.sno, curY + 5.5);
      doc.text('ITEM NAME / MODEL SPECIFICATION', colX.item, curY + 5.5);
      doc.text('BARCODE / SKU', colX.barcode, curY + 5.5);
      doc.text('CURR. STOCK', colX.stock, curY + 5.5);
      doc.text('REORDER QTY', colX.reorder, curY + 5.5);
      doc.text('UNIT', colX.unit, curY + 5.5);

      curY += 10;
    }

    if (!isEven) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, curY - 2, contentWidth, rowHeight, 'F');
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    doc.text(String(index + 1), colX.sno, curY + 3);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    
    const categoryText = item.product.category || 'Uncategorized';
    const fullItemName = `Item Name: ${item.product.name}, Category: ${categoryText}`;
    const itemName = fullItemName.length > 70 
      ? fullItemName.substring(0, 68) + '..'
      : fullItemName;
      
    doc.text(itemName, colX.item, curY + 3);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(item.product.barcode || 'N/A', colX.barcode, curY + 3);

    // Current stock alert color
    const isCritical = item.product.stockQty <= 2;
    if (isCritical) {
      doc.setTextColor(225, 29, 72); // rose-600
      doc.setFont('helvetica', 'bold');
    } else {
      doc.setTextColor(71, 85, 105);
      doc.setFont('helvetica', 'normal');
    }
    doc.text(`${item.product.stockQty} Pcs`, colX.stock, curY + 3);

    // Reorder qty highlight
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(79, 70, 229); // indigo-600
    doc.text(`${item.reorderQty}`, colX.reorder, curY + 3);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    doc.text('Pcs', colX.unit, curY + 3);

    // Divider line
    doc.setDrawColor(241, 245, 249);
    doc.setLineWidth(0.2);
    doc.line(margin, curY + 5.5, margin + contentWidth, curY + 5.5);

    totalReorderQty += item.reorderQty;
    if (item.product.basicPurchaseRate > 0) {
      totalEstValue += (item.product.basicPurchaseRate * item.reorderQty);
    }

    curY += rowHeight;
  });

  curY += 4;

  // Summary & Authorization Footer (keep together or add page if needed)
  if (curY > pageHeight - 55) {
    doc.addPage();
    curY = margin + 10;
  }

  // Summary Container
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin, curY, contentWidth, 38, 2, 2, 'FD');

  // Left Note & Instructions
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);
  doc.text('DISPATCH & PACKAGING INSTRUCTIONS:', margin + 5, curY + 6.5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  const userNotes = notes || '1. Please dispatch fresh stock with original retail packaging.\n2. Ensure safe transit handling for fragile/giftware items.\n3. Mention PO Number on the invoice and delivery challan.';
  const noteLines = doc.splitTextToSize(userNotes, 105);
  doc.text(noteLines, margin + 5, curY + 12);

  // Middle Summary Stats
  const statX = margin + 112;
  doc.setDrawColor(226, 232, 240);
  doc.line(statX, curY + 3, statX, curY + 35);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL LINE ITEMS:', statX + 4, curY + 7);
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(`${items.length} SKUs`, statX + 4, curY + 13);

  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL ORDER QUANTITY:', statX + 4, curY + 20);
  doc.setFontSize(12);
  doc.setTextColor(79, 70, 229);
  doc.text(`${totalReorderQty} Pcs`, statX + 4, curY + 28);

  // Right Signatory Box
  const sigX = margin + 148;
  doc.line(sigX, curY + 3, sigX, curY + 35);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`FOR ${shopProfile.name.toUpperCase()}`, sigX + 4, curY + 7);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text('Authorized Signatory / Store Stamp', sigX + 4, curY + 32);

  // Bottom Footer Disclaimer
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(148, 163, 184);
  doc.text(
    `This is a system-generated Purchase Order created via Aman Gift Gallery POS on ${new Date().toLocaleString('en-IN')}. Page 1 of 1`,
    pageWidth / 2,
    pageHeight - 6,
    { align: 'center' }
  );

  const blob = doc.output('blob');

  return {
    doc,
    poNumber,
    fileName,
    blob
  };
}

/**
 * Smart 1-click PO Share Handler
 * - On Mobile/Tablet: Uses Web Share API with attached PDF file
 * - On Desktop / Fallback: Triggers PDF download + opens WhatsApp note concurrently
 */
export async function sharePurchaseOrderPdf(options: POGenerateOptions): Promise<{
  sharedViaWebShare: boolean;
  poNumber: string;
}> {
  const { brandName, shopProfile } = options;
  const { doc, poNumber, fileName, blob } = generateBrandPurchaseOrderPdf(options);

  const totalUnits = options.items.reduce((sum, it) => sum + it.reorderQty, 0);

  const waText = `📦 *PURCHASE ORDER - ${brandName.toUpperCase()}*
*From:* ${shopProfile.name}
*PO Number:* ${poNumber}
*Total Items:* ${options.items.length} SKUs (${totalUnits} Pcs)
━━━━━━━━━━━━━━━━━━━━━
Attached is our official purchase reorder list PDF. Please review and dispatch at the earliest.`;

  // 1. Try Native Web Share API with File Attachment
  const pdfFile = new File([blob], fileName, { type: 'application/pdf' });

  if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [pdfFile] })) {
    try {
      await navigator.share({
        title: `Purchase Order - ${brandName} (${poNumber})`,
        text: waText,
        files: [pdfFile]
      });
      return { sharedViaWebShare: true, poNumber };
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        // User voluntarily dismissed the share sheet
        return { sharedViaWebShare: true, poNumber };
      }
      console.warn('Native Web Share failed, falling back to download + WhatsApp:', err);
    }
  }

  // 2. Fallback: Save PDF directly & Open WhatsApp
  doc.save(fileName);

  // Concurrently open WhatsApp with pre-filled message
  const waUrl = `https://wa.me/?text=${encodeURIComponent(waText)}`;
  window.open(waUrl, '_blank');

  return { sharedViaWebShare: false, poNumber };
}
