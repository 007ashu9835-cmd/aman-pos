import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';
import { Invoice, ShopProfile } from '../types';
import { formatCurrency, numberToWordsIndian, calculateGstTaxBreakdown } from './calculations';
import { uploadInvoicePdfToFirebaseStorage } from '../lib/firebase';

/**
 * Validates and formats a customer WhatsApp number:
 * - Removes spaces, dashes, parentheses, plus sign, and leading 0s
 * - Auto-prefixes with +91 if not already present
 * - Validates that it corresponds to a 10-digit mobile number
 */
export function formatWhatsAppPhoneNumber(phoneInput?: string): { 
  isValid: boolean; 
  formattedPhone: string; 
  error?: string;
} {
  if (!phoneInput || !phoneInput.trim()) {
    return { 
      isValid: false, 
      formattedPhone: '', 
      error: 'WhatsApp number is missing. Please enter a valid 10-digit mobile number.' 
    };
  }

  // Remove spaces, dashes, parentheses, and plus sign
  let cleaned = phoneInput.trim().replace(/[\s\-\(\)\+]/g, '');
  
  // Remove leading zeroes (e.g. 09876543210 -> 9876543210)
  cleaned = cleaned.replace(/^0+/, '');

  // If 10 digits, prefix with country code 91
  if (/^\d{10}$/.test(cleaned)) {
    return { isValid: true, formattedPhone: `91${cleaned}` };
  }

  // If already 12 digits starting with country code 91
  if (/^91\d{10}$/.test(cleaned)) {
    return { isValid: true, formattedPhone: cleaned };
  }

  return { 
    isValid: false, 
    formattedPhone: '', 
    error: 'Invalid WhatsApp number. Please enter a valid 10-digit mobile number (e.g. 9876543210).' 
  };
}

/**
 * Builds the exact message template for WhatsApp invoice sharing
 */
export function buildWhatsAppMessageText(
  customerName: string,
  shopName: string,
  totalAmount: number | string,
  pdfDownloadUrl: string
): string {
  const cName = customerName?.trim() || 'Customer';
  const sName = shopName?.trim() || 'Aman Gift Gallery';
  const amount = typeof totalAmount === 'number' ? totalAmount.toFixed(2) : totalAmount;

  return `Hello ${cName}, thank you for your purchase at ${sName}!\nYour bill of ₹${amount} is ready.\nView/Download your bill here: ${pdfDownloadUrl}\nThank you for shopping with us!`;
}

/**
 * Executes the complete "Send Bill on WhatsApp" flow:
 * 1. Validates the 10-digit WhatsApp number (removes spaces, dashes, leading 0, prefixes +91)
 * 2. Generates the bill as a PDF
 * 3. Uploads it to Firebase Storage and gets its public download URL
 * 4. Pulls Shop Name, Customer Name, and Total Amount dynamically
 * 5. Builds https://wa.me/<number>?text=<encoded_message>
 * 6. Opens the link in a new tab
 */
export function generateInvoiceTextSummary(receiptLink: string): string {
  let msg = `Welcome to Aman Gift Gallery!\n`;
  msg += `Thank you for purchasing with us.\n\n`;
  msg += `View / Print your bill here:\n`;
  msg += `${receiptLink}\n\n`;
  msg += `Thank you for shopping at Aman Gift Gallery! Have a great day!`;
  return msg;
}

export function generateWhatsAppLink(
  invoice: Invoice,
  shopProfile?: ShopProfile
): string {
  const phoneValidation = formatWhatsAppPhoneNumber(invoice.customerPhone);
  if (!phoneValidation.isValid) {
    throw new Error(phoneValidation.error || 'Please enter a valid 10-digit WhatsApp number.');
  }

  const minItems = (invoice.items || []).map((i: any) => [
    i.name || i.productName || i.product?.name || 'Item',
    Number(i.quantity || i.qty || 1),
    Number(i.customPrice !== undefined ? i.customPrice : (i.product?.sellingPrice ?? i.price ?? i.rate ?? 0)),
    Number(i.product?.mrp || i.mrp || i.originalPrice || i.product?.sellingPrice || i.price || 0)
  ]);

  const compactPayload = {
    inv: invoice.invoiceNumber || invoice.id || `INV-${Date.now()}`,
    dt: invoice.date || new Date().toLocaleDateString('en-IN'),
    c: invoice.customerName?.trim() || 'Customer',
    it: minItems,
    tot: Number((invoice as any).grandTotal || (invoice as any).totalAmount || 0),
    gst: Number((invoice as any).taxAmount || invoice.totalGst || 0)
  };

  const encoded = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(compactPayload)))));
  const PUBLIC_BASE_URL = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-xukte2sfikvqyt5mtmrxur-180193938958.asia-southeast1.run.app';
  const receiptLink = `${PUBLIC_BASE_URL}/#/receipt?data=${encoded}`;
  
  const msg = generateInvoiceTextSummary(receiptLink);
  const encodedMessage = encodeURIComponent(msg);
  return `https://wa.me/${phoneValidation.formattedPhone}?text=${encodedMessage}`;
}

/**
 * Generates an official, sharp vector Tax Invoice PDF using jsPDF directly.
 * Clean, high-contrast, professional, light minimalist enterprise theme.
 */
export function generateDirectInvoicePdf(
  invoice: Invoice,
  shopProfile: ShopProfile
): {
  doc: jsPDF;
  fileName: string;
  blob: Blob;
  file: File;
} {
  const storeName = shopProfile.name || 'AMAN GIFT GALLERY';
  const cleanInvNum = invoice.invoiceNumber.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `Invoice-${cleanInvNum}.pdf`;

  const doc = new jsPDF({
    orientation: 'p',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 12;
  const contentWidth = pageWidth - margin * 2; // 186mm

  // Top Accent Bar (Navy #1E293B)
  doc.setFillColor(30, 41, 59); // slate-800 / navy
  doc.rect(margin, margin, contentWidth, 2.5, 'F');

  // 1. Store Header Section (Clean White / Light Minimalist)
  let curY = margin + 8;

  // Store Name
  doc.setTextColor(15, 23, 42); // slate-900
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text(storeName.toUpperCase(), margin, curY);

  // Store Tagline
  if (shopProfile.tagline) {
    curY += 5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105); // slate-600
    doc.text(shopProfile.tagline, margin, curY);
  }

  // Store Address & Phone
  curY += 4.5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139); // slate-500
  const addressLine = `${shopProfile.address}, ${shopProfile.city}, ${shopProfile.state} - ${shopProfile.pincode}`;
  doc.text(addressLine, margin, curY);

  const isTaxInvoice = Boolean(invoice.isGstInvoice);
  const badgeTitle = isTaxInvoice ? 'TAX INVOICE' : 'RETAIL INVOICE';
  const showShopGstin = Boolean(isTaxInvoice && shopProfile.gstin && shopProfile.gstin.trim());

  curY += 4;
  const contactGstLine = `Ph: ${shopProfile.phone}${shopProfile.altPhone ? ` / ${shopProfile.altPhone}` : ''}${showShopGstin ? `  |  GSTIN: ${shopProfile.gstin}` : ''}`;
  doc.text(contactGstLine, margin, curY);

  // Right Side "TAX INVOICE" / "RETAIL INVOICE" Badge & Invoice Number
  const badgeWidth = isTaxInvoice ? 48 : 54;
  const badgeX = pageWidth - margin - badgeWidth;
  const badgeY = margin + 6;

  doc.setFillColor(241, 245, 249); // slate-100
  doc.setDrawColor(203, 213, 225); // slate-300
  doc.setLineWidth(0.4);
  doc.roundedRect(badgeX, badgeY, badgeWidth, 17, 2, 2, 'FD');

  doc.setFillColor(30, 41, 59); // navy fill for header
  doc.roundedRect(badgeX, badgeY, badgeWidth, 7.5, 2, 2, 'F');
  // Cover bottom rounded corners of top half
  doc.rect(badgeX, badgeY + 4, badgeWidth, 3.5, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(isTaxInvoice ? 8.5 : 7.5);
  doc.text(badgeTitle, badgeX + (badgeWidth / 2), badgeY + 5.2, { align: 'center' });

  doc.setTextColor(15, 23, 42); // slate-900
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.text(`#${invoice.invoiceNumber}`, badgeX + (badgeWidth / 2), badgeY + 13, { align: 'center' });

  // Divider below Store Header
  curY = margin + 26;
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.5);
  doc.line(margin, curY, margin + contentWidth, curY);

  curY += 4;

  // 2. Customer & Invoice Metadata Cards (High Contrast Clean Slate-50)
  const boxWidth = (contentWidth / 2) - 2;
  const boxHeight = 25;

  // Left Card: Customer Details
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.3);
  doc.roundedRect(margin, curY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139); // slate-500
  doc.text('BILLED TO (CUSTOMER)', margin + 4, curY + 5.5);

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42); // slate-900
  const custName = (invoice.customerName || 'Walk-in Retail Customer').substring(0, 36);
  doc.text(custName, margin + 4, curY + 12);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`Phone: ${invoice.customerPhone || 'Not Provided'}`, margin + 4, curY + 17.5);
  const custSubInfo = isTaxInvoice && invoice.customerGstin 
    ? `GSTIN: ${invoice.customerGstin}`
    : `Type: ${isTaxInvoice ? 'Tax Invoice Customer' : 'Retail / Cash Memo'}`;
  doc.text(custSubInfo, margin + 4, curY + 22);

  // Right Card: Invoice & Receipt Details
  const rightBoxX = margin + boxWidth + 4;
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.roundedRect(rightBoxX, curY, boxWidth, boxHeight, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139); // slate-500
  doc.text('INVOICE & RECEIPT DETAILS', rightBoxX + 4, curY + 5.5);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105); // slate-600
  doc.text('Date & Time:', rightBoxX + 4, curY + 11.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`${invoice.date}  ${invoice.time || ''}`, rightBoxX + 24, curY + 11.5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('Payment Mode:', rightBoxX + 4, curY + 16.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text((invoice.paymentMethod || 'CASH').toUpperCase(), rightBoxX + 24, curY + 16.5);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('Status:', rightBoxX + 4, curY + 21.5);

  // Crisp Paid Badge in Box
  const statusMethod = (invoice.paymentMethod || 'CASH').toUpperCase();
  doc.setFillColor(209, 250, 229); // emerald-100
  doc.setDrawColor(167, 243, 208); // emerald-200
  doc.roundedRect(rightBoxX + 23, curY + 17.5, 34, 5.5, 1, 1, 'FD');
  doc.setTextColor(6, 95, 70); // emerald-800
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.text(`PAID (${statusMethod})`, rightBoxX + 40, curY + 21.3, { align: 'center' });

  curY += boxHeight + 5;

  // 3. Items Table Header (Dynamic depending on isTaxInvoice)
  const colX = isTaxInvoice 
    ? {
        sno: margin + 3,
        item: margin + 14,
        hsn: margin + 92,
        qty: margin + 114,
        mrp: margin + 130,
        rate: margin + 150,
        total: margin + contentWidth - 3 // right-aligned
      }
    : {
        sno: margin + 3,
        item: margin + 14,
        hsn: 0,
        qty: margin + 118,
        mrp: margin + 136,
        rate: margin + 154,
        total: margin + contentWidth - 3 // right-aligned
      };

  // Table Header Background (Light Slate-100)
  doc.setFillColor(241, 245, 249); // slate-100
  doc.setDrawColor(203, 213, 225); // slate-300
  doc.setLineWidth(0.3);
  doc.roundedRect(margin, curY, contentWidth, 8, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59); // slate-800
  doc.text('S.NO', colX.sno, curY + 5.5);
  doc.text('ITEM DESCRIPTION', colX.item, curY + 5.5);
  if (isTaxInvoice) {
    doc.text('HSN', colX.hsn, curY + 5.5);
  }
  doc.text('QTY', colX.qty, curY + 5.5);
  doc.text('MRP', colX.mrp, curY + 5.5);
  doc.text('RATE', colX.rate, curY + 5.5);
  doc.text('TOTAL', colX.total, curY + 5.5, { align: 'right' });

  curY += 10;

  // Table Rows
  invoice.items.forEach((item, index) => {
    const isEven = index % 2 === 0;
    const hasValidWarranty = Boolean(item.warranty?.enabled && item.warranty.duration && item.warranty.duration !== 'No Warranty');
    const rowHeight = hasValidWarranty ? 9.5 : 7.5;

    // Check pagination
    if (curY > pageHeight - 58) {
      doc.addPage();
      curY = margin + 10;

      // Repeat Table Header
      doc.setFillColor(241, 245, 249);
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(margin, curY, contentWidth, 8, 1.5, 1.5, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(30, 41, 59);
      doc.text('S.NO', colX.sno, curY + 5.5);
      doc.text('ITEM DESCRIPTION', colX.item, curY + 5.5);
      if (isTaxInvoice) {
        doc.text('HSN', colX.hsn, curY + 5.5);
      }
      doc.text('QTY', colX.qty, curY + 5.5);
      doc.text('MRP', colX.mrp, curY + 5.5);
      doc.text('RATE', colX.rate, curY + 5.5);
      doc.text('TOTAL', colX.total, curY + 5.5, { align: 'right' });

      curY += 10;
    }

    if (!isEven) {
      doc.setFillColor(248, 250, 252); // soft slate
      doc.rect(margin, curY - 2, contentWidth, rowHeight, 'F');
    }

    const isReturn = item.quantity < 0 || item.isExchangeReturn;
    const unitPrice = item.customPrice !== undefined ? item.customPrice : item.product.sellingPrice;
    const lineTotal = unitPrice * item.quantity;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    doc.text(String(index + 1), colX.sno, curY + 3);

    // Item name
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(isReturn ? 225 : 15, isReturn ? 29 : 23, isReturn ? 72 : 42);
    let itemName = (isReturn ? '[RETURN] ' : '') + item.product.name;
    const maxLen = isTaxInvoice ? 40 : 54;
    if (itemName.length > maxLen) {
      itemName = itemName.substring(0, maxLen - 2) + '..';
    }
    doc.text(itemName, colX.item, curY + 3);

    if (hasValidWarranty) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.setTextColor(37, 99, 235); // blue-600
      doc.text(`Warranty: ${item.warranty!.duration}`, colX.item, curY + 6.5);
    }

    // HSN (Only when isTaxInvoice is enabled)
    if (isTaxInvoice) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text(item.product.hsn || item.product.category || '-', colX.hsn, curY + 3);
    }

    // Qty
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(String(Math.abs(item.quantity)), colX.qty, curY + 3);

    // MRP (Sharp, Bold, Crisp - No Blur or Strikethrough)
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(51, 65, 85); // slate-700
    doc.text(`Rs.${(item.product.mrp || unitPrice).toFixed(0)}`, colX.mrp, curY + 3);

    // Unit Price / Rate (Sharp, Bold, Dark)
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(`Rs.${unitPrice.toFixed(0)}`, colX.rate, curY + 3);

    // Line Total
    doc.setFont('helvetica', 'bold');
    if (isReturn) {
      doc.setTextColor(225, 29, 72);
      doc.text(`-Rs.${Math.abs(lineTotal).toFixed(2)}`, colX.total, curY + 3, { align: 'right' });
    } else {
      doc.setTextColor(15, 23, 42);
      doc.text(`Rs.${lineTotal.toFixed(2)}`, colX.total, curY + 3, { align: 'right' });
    }

    // Divider line
    doc.setDrawColor(241, 245, 249);
    doc.setLineWidth(0.2);
    doc.line(margin, curY + rowHeight - 2, margin + contentWidth, curY + rowHeight - 2);

    curY += rowHeight;
  });

  curY += 3;

  // 4. Summary & Calculation Section (Clean, Light, Right-Aligned)
  const gstBreakdown = calculateGstTaxBreakdown(invoice.items, isTaxInvoice);
  const roundOffDiff = invoice.roundOff !== undefined 
    ? invoice.roundOff 
    : 0;
  const hasRoundOff = Math.abs(roundOffDiff) >= 0.005;
  const roundOffPdfText = roundOffDiff > 0 ? `+Rs.${roundOffDiff.toFixed(2)}` : `-Rs.${Math.abs(roundOffDiff).toFixed(2)}`;

  // Calculate dynamic summary box height based on active lines
  let dynamicLinesCount = 2; // Subtotal + Grand Total
  if (invoice.totalDiscount > 0) dynamicLinesCount += 1;
  if (isTaxInvoice && gstBreakdown.totalTax > 0) dynamicLinesCount += 2;
  if (hasRoundOff) dynamicLinesCount += 1;
  const summaryBoxHeight = Math.max(38, 20 + dynamicLinesCount * 4.5);

  if (curY > pageHeight - summaryBoxHeight - 15) {
    doc.addPage();
    curY = margin + 10;
  }

  // Summary Container Box (Clean Minimal Light Slate)
  doc.setFillColor(250, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin, curY, contentWidth, summaryBoxHeight, 2, 2, 'FD');

  // Left Section: Amount in Words & Terms
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59);
  doc.text('AMOUNT IN WORDS:', margin + 4, curY + 5.5);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  const words = numberToWordsIndian(invoice.grandTotal);
  doc.text(words.substring(0, 65), margin + 4, curY + 10.5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59);
  doc.text('TERMS & CONDITIONS:', margin + 4, curY + 17);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  const disclaimer = shopProfile.footerDisclaimer || '1. Goods once sold cannot be returned without original invoice.\n2. Warranty services are handled by respective authorized brand centers.';
  const disclaimerLines = doc.splitTextToSize(disclaimer, 95);
  doc.text(disclaimerLines, margin + 4, curY + 22);

  // Middle Divider
  const calcX = margin + 105;
  doc.setDrawColor(226, 232, 240);
  doc.line(calcX, curY + 2, calcX, curY + summaryBoxHeight - 2);

  // Right Calculations (Clean, Light, Right-Aligned)
  let offsetCalcY = curY + 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(isTaxInvoice && gstBreakdown.totalTax > 0 ? 'Item(s) Subtotal (before tax):' : 'Items Subtotal:', calcX + 4, offsetCalcY);
  doc.text(`Rs.${invoice.subtotal.toFixed(2)}`, margin + contentWidth - 4, offsetCalcY, { align: 'right' });

  if (invoice.totalDiscount > 0) {
    offsetCalcY += 4.5;
    doc.setTextColor(16, 185, 129); // emerald
    doc.text('Total Savings:', calcX + 4, offsetCalcY);
    doc.text(`-Rs.${invoice.totalDiscount.toFixed(2)}`, margin + contentWidth - 4, offsetCalcY, { align: 'right' });
  }

  // Simple 2-Line GST Breakdown (CGST & SGST only)
  if (isTaxInvoice && gstBreakdown.totalTax > 0) {
    const cgstRateLabel = gstBreakdown.slabs.length === 1 ? ` (@${gstBreakdown.slabs[0].cgstRate}%)` : '';
    const sgstRateLabel = gstBreakdown.slabs.length === 1 ? ` (@${gstBreakdown.slabs[0].sgstRate}%)` : '';

    offsetCalcY += 4.5;
    doc.setTextColor(71, 85, 105);
    doc.text(`CGST${cgstRateLabel}:`, calcX + 4, offsetCalcY);
    doc.text(`Rs.${gstBreakdown.totalCgst.toFixed(2)}`, margin + contentWidth - 4, offsetCalcY, { align: 'right' });

    offsetCalcY += 4.5;
    doc.text(`SGST${sgstRateLabel}:`, calcX + 4, offsetCalcY);
    doc.text(`Rs.${gstBreakdown.totalSgst.toFixed(2)}`, margin + contentWidth - 4, offsetCalcY, { align: 'right' });
  }

  // Conditional Round Off line
  if (hasRoundOff) {
    offsetCalcY += 4.5;
    doc.setTextColor(100, 116, 139); // slate-500
    doc.setFont('helvetica', 'normal');
    doc.text('Round Off:', calcX + 4, offsetCalcY);
    doc.text(roundOffPdfText, margin + contentWidth - 4, offsetCalcY, { align: 'right' });
  }

  // Grand Total Line (Clean, Light, Bold)
  offsetCalcY += 6;
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.3);
  doc.line(calcX + 2, offsetCalcY - 2, margin + contentWidth - 2, offsetCalcY - 2);

  doc.setTextColor(15, 23, 42); // slate-900
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(isTaxInvoice && gstBreakdown.totalTax > 0 ? 'Grand Total (after tax):' : 'Grand Total:', calcX + 4, offsetCalcY + 2.5);
  doc.setFontSize(10.5);
  doc.text(`Rs.${invoice.grandTotal.toFixed(2)}`, margin + contentWidth - 4, offsetCalcY + 2.5, { align: 'right' });

  // 5. Signatory Block
  curY += summaryBoxHeight + 5;
  if (curY > pageHeight - 22) {
    doc.addPage();
    curY = margin + 10;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59); // slate-800
  doc.text(`FOR ${storeName.toUpperCase()}`, margin + contentWidth - 4, curY + 4, { align: 'right' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('Authorized Signatory / Digital Cashier Stamp', margin + contentWidth - 4, curY + 9, { align: 'right' });

  // Bottom Footer Disclaimer
  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(148, 163, 184);
  doc.text(
    `Thank you for shopping at ${storeName}. System-generated invoice created on ${new Date().toLocaleString('en-IN')}.`,
    pageWidth / 2,
    pageHeight - 6,
    { align: 'center' }
  );

  const blob = doc.output('blob');
  const file = new File([blob], fileName, { type: 'application/pdf' });

  return {
    doc,
    fileName,
    blob,
    file
  };
}

/**
 * Generates an in-memory PDF Blob and File object from an HTML element using html2canvas-pro and jsPDF,
 * falling back to direct vector jsPDF if the element is not found.
 */
export async function generateInvoicePdfBlob(
  elementId?: string, 
  filename?: string,
  invoice?: Invoice,
  shopProfile?: ShopProfile
): Promise<{ blob: Blob; file: File; dataUrl: string; pdf: jsPDF } | null> {
  const cleanFilename = (filename || 'invoice.pdf').endsWith('.pdf') 
    ? (filename || 'invoice.pdf') 
    : `${filename || 'invoice'}.pdf`;

  // Check if element exists in DOM
  const element = elementId ? document.getElementById(elementId) : null;

  if (!element) {
    // If element is not rendered in DOM (e.g. background POS share before modal opens)
    if (invoice && shopProfile) {
      const { doc, blob, file } = generateDirectInvoicePdf(invoice, shopProfile);
      const dataUrl = doc.output('datauristring');
      return { blob, file, dataUrl, pdf: doc };
    }
    console.warn(`Element #${elementId} not found and no invoice data provided`);
    return null;
  }

  try {
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff'
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgHeight = (canvas.height * pageWidth) / canvas.width;

    if (imgHeight <= pageHeight) {
      pdf.addImage(imgData, 'PNG', 0, 0, pageWidth, imgHeight, undefined, 'FAST');
    } else {
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, pageWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, pageWidth, imgHeight, undefined, 'FAST');
        heightLeft -= pageHeight;
      }
    }

    const blob = pdf.output('blob');
    const dataUrl = pdf.output('datauristring');
    const file = new File([blob], cleanFilename, { type: 'application/pdf' });

    return { blob, file, dataUrl, pdf };
  } catch (error) {
    console.error('Error in generateInvoicePdfBlob html2canvas, falling back to direct jsPDF:', error);
    if (invoice && shopProfile) {
      const { doc, blob, file } = generateDirectInvoicePdf(invoice, shopProfile);
      const dataUrl = doc.output('datauristring');
      return { blob, file, dataUrl, pdf: doc };
    }
    return null;
  }
}

/**
 * Direct PDF Download using vector jsPDF or html2canvas.
 */
export async function downloadInvoicePdf(
  invoice: Invoice,
  shopProfile: ShopProfile,
  elementId?: string
): Promise<void> {
  const cleanFilename = `Invoice-${invoice.invoiceNumber || 'Bill'}.pdf`;

  try {
    const { doc, fileName } = generateDirectInvoicePdf(invoice, shopProfile);
    doc.save(fileName || cleanFilename);
  } catch (err) {
    console.warn('Direct PDF download error, attempting DOM canvas fallback:', err);
    if (elementId) {
      const result = await generateInvoicePdfBlob(elementId, cleanFilename, invoice, shopProfile);
      if (result) {
        result.pdf.save(cleanFilename);
      } else {
        printInvoiceElement(elementId);
      }
    }
  }
}

/**
 * Direct Browser Print using an isolated hidden iframe targeted strictly at the invoice container.
 */
export function printInvoiceElement(elementId: string): void {
  const element = document.getElementById(elementId);
  if (!element) {
    window.print();
    return;
  }

  try {
    const existingIframe = document.getElementById('pos-print-iframe');
    if (existingIframe) {
      document.body.removeChild(existingIframe);
    }

    const iframe = document.createElement('iframe');
    iframe.id = 'pos-print-iframe';
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0px';
    iframe.style.height = '0px';
    iframe.style.border = '0';
    iframe.style.zIndex = '-9999';
    iframe.style.visibility = 'hidden';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (!doc) {
      window.print();
      return;
    }

    let stylesHtml = '';
    document.querySelectorAll('style, link[rel="stylesheet"]').forEach((node) => {
      stylesHtml += node.outerHTML;
    });

    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Invoice Receipt</title>
          ${stylesHtml}
          <style>
            @page {
              margin: 4mm;
              size: auto;
            }
            body {
              margin: 0;
              padding: 6px;
              background: #ffffff !important;
              color: #0f172a !important;
              font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            #invoice-render-container {
              box-shadow: none !important;
              margin: 0 auto !important;
              width: 100% !important;
              max-width: 100% !important;
            }
          </style>
        </head>
        <body>
          <div style="width: 100%; display: flex; justify-content: center;">
            ${element.outerHTML}
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.focus();
                window.print();
              }, 250);
            };
          </script>
        </body>
      </html>
    `);
    doc.close();
  } catch (err) {
    console.error('Iframe print error, falling back to window.print():', err);
    window.print();
  }
}

/**
 * Intelligent "Save & WhatsApp / Share PDF" workflow:
 * 
 * 1. Direct Web Share API for PDF Files (`navigator.share`):
 *    - Immediately generates the vector PDF Blob and File object.
 *    - Checks if `navigator.canShare && navigator.canShare({ files: [pdfFile] })` is supported
 *      (Android, iOS, iPadOS, Safari, Chrome Mobile).
 *    - Triggers `navigator.share({ files: [pdfFile], title: 'Tax Invoice', text: 'Here is your bill from AMAN GIFT GALLERY.' })`.
 *    - Directly opens the native mobile share sheet with the attached PDF file.
 * 
 * 2. Fallback for Desktop / Non-Supporting Browsers:
 *    - Automatically triggers the direct PDF download (`Invoice-XXXXX.pdf`).
 *    - Simultaneously opens `https://wa.me/${phone}?text=${encodedMessage}` with a pre-filled summary.
 */
