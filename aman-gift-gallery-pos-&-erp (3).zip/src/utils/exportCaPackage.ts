import * as XLSX from 'xlsx';
import { Invoice, PurchaseEntry, ShopProfile } from '../types';
import { formatCurrency } from './calculations';

export function exportMonthlyCaPackage(
  invoices: Invoice[], 
  month: number, 
  year: number, 
  shopName: string = 'Aman Gift Gallery'
) {
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June', 
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const periodStr = `${monthNames[month - 1] || 'Month'}_${year}`;

  // 1. GSTR-1 B2C Invoices Sheet
  const b2cRows = invoices.map((inv) => {
    const totalTaxable = inv.grandTotal - inv.totalGst;
    const cgst = inv.totalGst / 2;
    const sgst = inv.totalGst / 2;
    return {
      'Invoice No': inv.invoiceNumber,
      'Invoice Date': inv.date,
      'Invoice Time': inv.time,
      'Customer Name': inv.customerName || 'Walk-in Retail Customer',
      'Customer Phone': inv.customerPhone || '',
      'Place of Supply': '20-Jharkhand',
      'Total Invoice Value (₹)': Number(inv.grandTotal.toFixed(2)),
      'Taxable Value (₹)': Number(totalTaxable.toFixed(2)),
      'CGST 9% / Half (₹)': Number(cgst.toFixed(2)),
      'SGST 9% / Half (₹)': Number(sgst.toFixed(2)),
      'IGST (₹)': 0,
      'Payment Mode': (inv.paymentMethod || 'CASH').toUpperCase(),
      'Is Exchange Bill': inv.isExchangeBill ? 'YES' : 'NO'
    };
  });

  // 2. HSN Summary Sheet
  const hsnMap: Record<string, { desc: string; qty: number; totalVal: number; taxRate: number; taxableVal: number; gstVal: number }> = {};
  
  for (const inv of invoices) {
    for (const item of inv.items) {
      if (item.quantity <= 0) continue;
      const hsn = item.product.hsn || '999999';
      const netVal = (item.customPrice || item.product.sellingPrice) * item.quantity;
      const taxRate = item.product.gstPercent || 18;
      const taxVal = netVal - (netVal / (1 + taxRate / 100));
      const taxable = netVal - taxVal;

      if (!hsnMap[hsn]) {
        hsnMap[hsn] = {
          desc: item.product.category + ' (' + item.product.brand + ')',
          qty: 0,
          totalVal: 0,
          taxRate,
          taxableVal: 0,
          gstVal: 0
        };
      }
      hsnMap[hsn].qty += item.quantity;
      hsnMap[hsn].totalVal += netVal;
      hsnMap[hsn].taxableVal += taxable;
      hsnMap[hsn].gstVal += taxVal;
    }
  }

  const hsnRows = Object.entries(hsnMap).map(([hsn, data]) => ({
    'HSN Code': hsn,
    'Description': data.desc,
    'Total Quantity (Pcs)': data.qty,
    'Total Value (₹)': Number(data.totalVal.toFixed(2)),
    'Taxable Value (₹)': Number(data.taxableVal.toFixed(2)),
    'GST Rate (%)': `${data.taxRate}%`,
    'Central Tax / CGST (₹)': Number((data.gstVal / 2).toFixed(2)),
    'State Tax / SGST (₹)': Number((data.gstVal / 2).toFixed(2)),
    'Integrated Tax / IGST (₹)': 0
  }));

  // 3. GSTR-3B Computation Sheet
  const totalSales = invoices.reduce((sum, i) => sum + i.grandTotal, 0);
  const totalOutputGst = invoices.reduce((sum, i) => sum + i.totalGst, 0);
  const taxableSales = totalSales - totalOutputGst;

  const gstr3bRows = [
    { Section: 'Store Trade Name', Value: shopName },
    { Section: 'Filing Period', Value: periodStr },
    { Section: 'State Jurisdiction', Value: 'Jharkhand (Code 20)' },
    { Section: '-----------------------------', Value: '-----------------------------' },
    { Section: '3.1 Details of Outward Supplies (Sales)', Value: '' },
    { Section: 'Total Taxable Turnover (₹)', Value: Number(taxableSales.toFixed(2)) },
    { Section: 'Total Output CGST Liability (₹)', Value: Number((totalOutputGst / 2).toFixed(2)) },
    { Section: 'Total Output SGST Liability (₹)', Value: Number((totalOutputGst / 2).toFixed(2)) },
    { Section: 'Total Output GST (₹)', Value: Number(totalOutputGst.toFixed(2)) },
    { Section: '-----------------------------', Value: '-----------------------------' },
    { Section: 'Net Gross Sales Collected (₹)', Value: Number(totalSales.toFixed(2)) },
    { Section: 'Total Count of Invoices Issued', Value: invoices.length }
  ];

  const wb = XLSX.utils.book_new();

  const wsB2C = XLSX.utils.json_to_sheet(b2cRows);
  XLSX.utils.book_append_sheet(wb, wsB2C, 'GSTR-1 B2CS Invoices');

  const wsHSN = XLSX.utils.json_to_sheet(hsnRows);
  XLSX.utils.book_append_sheet(wb, wsHSN, 'GSTR-1 HSN Summary');

  const ws3B = XLSX.utils.json_to_sheet(gstr3bRows);
  XLSX.utils.book_append_sheet(wb, ws3B, 'GSTR-3B Computation');

  const filename = `CA_Package_${shopName.replace(/\s+/g, '_')}_${periodStr}.xlsx`;
  XLSX.writeFile(wb, filename);
}

export function exportGstr1Excel(invoices: Invoice[], shopProfile: ShopProfile, monthName: string) {
  exportMonthlyCaPackage(invoices, new Date().getMonth() + 1, new Date().getFullYear(), shopProfile.name);
}

export function exportGstr3bSummary(
  invoices: Invoice[], 
  purchases: PurchaseEntry[], 
  shopProfile: ShopProfile, 
  monthName: string
) {
  exportMonthlyCaPackage(invoices, new Date().getMonth() + 1, new Date().getFullYear(), shopProfile.name);
}

export function generateCaWhatsAppMessage(
  invoices: Invoice[], 
  purchases: PurchaseEntry[], 
  shopProfile: ShopProfile, 
  monthName: string
): string {
  const totalSales = invoices.reduce((sum, i) => sum + i.grandTotal, 0);
  const totalOutputGst = invoices.reduce((sum, i) => sum + i.totalGst, 0);

  const text = `*GST Return Filing Data - ${shopProfile.name}*
📍 *GSTIN:* ${shopProfile.gstin || '20AABCA1234F1Z5'}
📅 *Month/Period:* ${monthName}
🧾 *Total Sales Invoices:* ${invoices.length} Bills
💰 *Total Gross Sales:* ${formatCurrency(totalSales)}
🏛️ *Output GST (Sales):* ${formatCurrency(totalOutputGst)}

_Respected Sir/Madam, please find the attached GSTR-1 and GSTR-3B computed Excel package generated directly from Aman Gift Gallery POS ERP._`;

  return encodeURIComponent(text);
}
