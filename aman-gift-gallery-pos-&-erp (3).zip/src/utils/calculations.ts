import { CartItem } from '../types';

export function calculateLandingCost(basicRate: number, gstPercent: number): number {
  const rate = Number(basicRate) || 0;
  const gst = Number(gstPercent) || 0;
  return Number((rate + (rate * gst) / 100).toFixed(2));
}

export function formatCurrency(amount: number): string {
  const num = Number(amount) || 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(num);
}

export function formatNumber(amount: number): string {
  const num = Number(amount) || 0;
  return new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
  }).format(num);
}

export function formatRoundOff(roundOff: number, prefix: string = '₹'): string {
  const num = Number(roundOff) || 0;
  if (Math.abs(num) < 0.005) return '';
  const sign = num > 0 ? '+' : '-';
  return `${sign}${prefix}${Math.abs(num).toFixed(2)}`;
}

export interface GstSlabSummary {
  gstRate: number; // e.g. 18
  cgstRate: number; // e.g. 9
  sgstRate: number; // e.g. 9
  hsn: string;
  taxableAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  totalTax: number;
  totalAmount: number;
}

export interface DetailedGstBreakdown {
  totalTaxableAmount: number;
  totalCgst: number;
  totalSgst: number;
  totalTax: number;
  totalGrossAmount: number;
  slabs: GstSlabSummary[];
  hasMultipleRates: boolean;
}

export function calculateGstTaxBreakdown(items: CartItem[], isGstInvoiceEnabled: boolean = true): DetailedGstBreakdown {
  const slabMap = new Map<string, GstSlabSummary>();
  let totalTaxableAmount = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalTax = 0;
  let totalGrossAmount = 0;

  if (!isGstInvoiceEnabled) {
    for (const item of items) {
      if (item.quantity < 0 || item.isExchangeReturn) continue;
      const unitPrice = item.customPrice !== undefined ? item.customPrice : (item.product.mrp || item.product.sellingPrice || 0);
      const qty = Math.abs(item.quantity);
      const discount = item.discountPercent || 0;
      const lineGross = unitPrice * qty;
      const lineDiscount = (lineGross * discount) / 100;
      const lineNet = lineGross - lineDiscount;
      totalTaxableAmount += lineNet;
      totalGrossAmount += lineNet;
    }
    return {
      totalTaxableAmount: Number(totalTaxableAmount.toFixed(2)),
      totalCgst: 0,
      totalSgst: 0,
      totalTax: 0,
      totalGrossAmount: Number(totalGrossAmount.toFixed(2)),
      slabs: [],
      hasMultipleRates: false,
    };
  }

  for (const item of items) {
    if (item.quantity < 0 || item.isExchangeReturn) continue; // Skip returns for tax invoice forward calculation

    const unitPrice = item.customPrice !== undefined ? item.customPrice : (item.product.mrp || item.product.sellingPrice || 0);
    const qty = Math.abs(item.quantity);
    const discount = item.discountPercent || 0;

    const lineGross = unitPrice * qty;
    const lineDiscount = (lineGross * discount) / 100;
    const lineNet = lineGross - lineDiscount;

    // Inclusive GST calculation:
    // The entered price is the FINAL price.
    // Taxable Amount = Final Price / (1 + GST%)
    // GST Amount = Final Price - Taxable Amount
    const gstRate = Number(item.product.gstPercent) || 0;
    let taxableAmount = lineNet;
    let itemTax = 0;
    
    if (gstRate > 0) {
      taxableAmount = lineNet / (1 + (gstRate / 100));
      itemTax = lineNet - taxableAmount;
    }
    
    const cgst = itemTax / 2;
    const sgst = itemTax / 2;
    const hsn = item.product.hsn || item.product.category || '999999';

    totalTaxableAmount += taxableAmount;
    totalTax += itemTax;
    totalCgst += cgst;
    totalSgst += sgst;
    totalGrossAmount += lineNet;

    if (gstRate > 0) {
      const key = `${gstRate}%-${hsn}`;
      if (!slabMap.has(key)) {
        slabMap.set(key, {
          gstRate,
          cgstRate: gstRate / 2,
          sgstRate: gstRate / 2,
          hsn,
          taxableAmount: 0,
          cgstAmount: 0,
          sgstAmount: 0,
          totalTax: 0,
          totalAmount: 0,
        });
      }

      const entry = slabMap.get(key)!;
      entry.taxableAmount += taxableAmount;
      entry.cgstAmount += cgst;
      entry.sgstAmount += sgst;
      entry.totalTax += itemTax;
      entry.totalAmount += lineNet;
    }
  }

  const slabs = Array.from(slabMap.values()).map(s => ({
    ...s,
    taxableAmount: Number(s.taxableAmount.toFixed(2)),
    cgstAmount: Number(s.cgstAmount.toFixed(2)),
    sgstAmount: Number(s.sgstAmount.toFixed(2)),
    totalTax: Number(s.totalTax.toFixed(2)),
    totalAmount: Number(s.totalAmount.toFixed(2)),
  })).sort((a, b) => a.gstRate - b.gstRate);

  const distinctRates = new Set(slabs.map(s => s.gstRate));

  return {
    totalTaxableAmount: Number(totalTaxableAmount.toFixed(2)),
    totalCgst: Number(totalCgst.toFixed(2)),
    totalSgst: Number(totalSgst.toFixed(2)),
    totalTax: Number(totalTax.toFixed(2)),
    totalGrossAmount: Number(totalGrossAmount.toFixed(2)),
    slabs,
    hasMultipleRates: distinctRates.size > 1,
  };
}

export interface CartCalculationResult {
  totalItemsCount: number;
  subtotal: number;
  totalDiscount: number;
  totalGst: number;
  totalTaxableAmount: number;
  cgstAmount: number;
  sgstAmount: number;
  grandTotal: number;
  roundOff: number;
  totalPurchaseCost: number;
  totalLandingCost?: number; // Alias for backward compatibility
  cashierProfit: number;
  profitMarginPercent: number;
  exchangeCredit: number; // Total value of returned items
  purchasedDebit: number; // Total value of new items
  netExchangeDelta: number; // purchasedDebit - exchangeCredit
  exchangeDelta?: number; // Alias for netExchangeDelta
  gstBreakdown: DetailedGstBreakdown;
}

export function calculateCartTotals(items: CartItem[], isGstInvoiceEnabled: boolean = true): CartCalculationResult {
  let subtotal = 0;
  let totalDiscount = 0;
  let totalGst = 0;
  let totalTaxableAmount = 0;
  let totalPurchaseCost = 0;
  let totalItemsCount = 0;
  let exchangeCredit = 0;
  let purchasedDebit = 0;

  for (const item of items) {
    const unitPrice = item.customPrice !== undefined ? item.customPrice : (item.product.mrp || item.product.sellingPrice || 0);
    const qty = item.quantity;
    const discount = item.discountPercent || 0;
    const lineGross = unitPrice * Math.abs(qty);
    const lineDiscount = (lineGross * discount) / 100;
    const lineNet = lineGross - lineDiscount;

    const gstRate = isGstInvoiceEnabled ? (Number(item.product.gstPercent) || 0) : 0;
    let lineTaxable = lineNet;
    let itemTax = 0;
    if (gstRate > 0) {
      lineTaxable = lineNet / (1 + (gstRate / 100));
      itemTax = lineNet - lineTaxable;
    }
    const lineCost = (item.product.basicPurchaseRate || 0) * Math.abs(qty);

    if (qty < 0 || item.isExchangeReturn) {
      exchangeCredit += lineNet;
    } else {
      purchasedDebit += lineNet;
      totalItemsCount += qty;
      subtotal += lineTaxable;
      totalDiscount += lineDiscount;
      totalTaxableAmount += lineTaxable;
      totalGst += itemTax;
      totalPurchaseCost += lineCost;
    }
  }

  // Formula: Grand Total = Item Subtotal (net of discounts) + CGST + SGST - Exchange Return Credit
  const netPayablePreRound = purchasedDebit - exchangeCredit;
  const grandTotal = Math.round(netPayablePreRound);
  const roundOff = Number((grandTotal - netPayablePreRound).toFixed(2));
  
  const cashierProfit = Number(((purchasedDebit - totalGst) - totalPurchaseCost).toFixed(2));
  const profitMarginPercent = (purchasedDebit - totalGst) > 0 
     ? Number(((cashierProfit / (purchasedDebit - totalGst)) * 100).toFixed(1)) 
     : 0;

  const gstBreakdown = calculateGstTaxBreakdown(items, isGstInvoiceEnabled);

  return {
    totalItemsCount,
    subtotal: Number(subtotal.toFixed(2)),
    totalDiscount: Number(totalDiscount.toFixed(2)),
    totalGst: Number(totalGst.toFixed(2)),
    totalTaxableAmount: Number(totalTaxableAmount.toFixed(2)),
    cgstAmount: Number((totalGst / 2).toFixed(2)),
    sgstAmount: Number((totalGst / 2).toFixed(2)),
    grandTotal,
    roundOff,
    totalPurchaseCost: Number(totalPurchaseCost.toFixed(2)),
    totalLandingCost: Number(totalPurchaseCost.toFixed(2)),
    cashierProfit,
    profitMarginPercent,
    exchangeCredit: Number(exchangeCredit.toFixed(2)),
    purchasedDebit: Number(purchasedDebit.toFixed(2)),
    netExchangeDelta: Number((purchasedDebit - exchangeCredit).toFixed(2)),
    exchangeDelta: Number((purchasedDebit - exchangeCredit).toFixed(2)),
    gstBreakdown,
  };
}

export function numberToWordsIndian(num: number): string {
  const a = [
    '', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ',
    'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '
  ];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const n = ('000000000' + Math.floor(Math.abs(num))).substr(-9);
  const m = n.match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!m) return '';
  let str = '';
  str += Number(m[1]) !== 0 ? (a[Number(m[1])] || b[m[1][0] as any] + ' ' + a[m[1][1] as any]) + 'Crore ' : '';
  str += Number(m[2]) !== 0 ? (a[Number(m[2])] || b[m[2][0] as any] + ' ' + a[m[2][1] as any]) + 'Lakh ' : '';
  str += Number(m[3]) !== 0 ? (a[Number(m[3])] || b[m[3][0] as any] + ' ' + a[m[3][1] as any]) + 'Thousand ' : '';
  str += Number(m[4]) !== 0 ? (a[Number(m[4])] || b[m[4][0] as any] + ' ' + a[m[4][1] as any]) + 'Hundred ' : '';
  str += Number(m[5]) !== 0 ? ((str !== '') ? 'and ' : '') + (a[Number(m[5])] || b[m[5][0] as any] + ' ' + a[m[5][1] as any]) : '';
  return (str.trim() || 'Zero') + ' Rupees Only';
}
