/**
 * Client-Side Image Compression & Resizing Utility for Bill & Barcode Scanner
 * Reduces image dimensions to max 800px width/height and compresses with JPEG quality 0.6
 * Prevents payload timeouts and excessive base64 memory overhead when sending to Gemini AI.
 */

export async function compressImageToDataUrl(
  fileOrBlob: File | Blob,
  maxWidth = 800,
  quality = 0.6
): Promise<string> {
  return new Promise((resolve, reject) => {
    // If not in browser environment
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(fileOrBlob);
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;

        // Calculate proportional aspect ratio bounding to maxWidth
        if (width > maxWidth || height > maxWidth) {
          if (width >= height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxWidth) / height);
            height = maxWidth;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }

        // Draw with white background (handles transparent PNGs correctly)
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        // Convert to high-efficiency compressed JPEG DataURL
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };

      img.onerror = () => {
        // Fallback to original data URL if image rendering fails
        resolve(event.target?.result as string);
      };

      img.src = event.target?.result as string;
    };

    reader.onerror = reject;
    reader.readAsDataURL(fileOrBlob);
  });
}
