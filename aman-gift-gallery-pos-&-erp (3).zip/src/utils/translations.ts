import { Language } from '../types';

export const translations = {
  en: {
    appTitle: 'Aman Gift Gallery',
    tagline: 'An Exclusive Gift, Crockery, Toy & Home Essentials Gallery',
    
    // Sidebar Navigation Labels
    pos: 'New Bill / Sale',
    dashboard: 'Dashboard & Brands',
    inventory: 'Stock / Inventory',
    purchases: 'Purchase / Inward',
    reports: 'GST & CA Reports',
    khata: 'Khata / Party Ledger',
    settings: 'Shop Settings & Profile',
    
    // Quick Actions / Header
    offlineMode: 'Offline Ready (IndexedDB)',
    onlineMode: 'Connected',
    todaySales: "Today's Sales",
    todayProfit: "Today's Gross Profit",
    stockValuation: 'Stock Valuation',
    lowStockAlerts: 'Low Stock Alerts',
    brandAnalytics: 'Brand Analytics',
    quickBill: 'New Quick Bill',
    scanProduct: 'Scan / Search Barcode or Name...',
    exchangeMode: 'Exchange Mode',
    exitExchange: 'Exit Exchange',
    clearCart: 'Clear Cart',
    cashierProfitBox: 'Private Cashier Profit',
    margin: 'Margin',
    totalItems: 'Total Items',
    subtotal: 'Subtotal',
    discount: 'Discount',
    taxGst: 'Tax (GST)',
    roundOff: 'Round Off',
    grandTotal: 'Grand Total',
    exchangeCredit: 'Returned Exchange Credit',
    netPayable: 'Net Payable',
    refundToCustomer: 'Refund to Customer',
    settleBill: 'Print & Settle Bill (F12)',
    
    // Customer
    customerInfo: 'Customer Info (Optional)',
    customerName: 'Customer Name',
    customerPhone: 'Phone Number',
    warranty: 'Warranty',
    warrantyDuration: 'Warranty Duration',
    noWarranty: 'No Warranty',
    
    // Inventory
    allCategories: 'All Items',
    allBrands: 'All Brands',
    barcode: 'Barcode',
    itemName: 'Item Name',
    brand: 'Brand',
    category: 'Category',
    stock: 'Stock Qty',
    landingCost: 'Landing Cost',
    mrp: 'MRP',
    sellingPrice: 'Selling Price',
    action: 'Action',
    addProduct: 'Add New Product',
    deadStockTracker: 'Dead Stock Tracker (60+ Days)',
    generateReorderList: 'Generate Supplier Re-Order List',
    printBarcodeLabels: 'Print Barcode Stickers',
    adjustWastage: 'Damage / Defect Deduction',
    
    // Purchases
    geminiOcrTitle: 'Gemini AI Invoice & Chalan OCR',
    uploadBillPhoto: 'Upload / Capture Physical Bill',
    parseBillWithGemini: 'Extract with Gemini AI',
    sheetsSyncTitle: 'Google Sheets 2-Way Live Sync',
    syncNow: 'Sync Now with Google Sheets',
    basicRate: 'Basic Rate',
    gstPercent: 'GST %',
    totalAmount: 'Total Amount',
    supplier: 'Supplier Name',
    voucherNo: 'Bill / Voucher No',
    
    // Khata
    customers: 'Customers (ग्राहक)',
    suppliers: 'Suppliers (सप्लायर)',
    totalReceivable: 'Total Receivable (लेना है)',
    totalPayable: 'Total Payable (देना है)',
    gotReceived: '+ Got / Received (आया)',
    gaveCredit: '- Gave / Credit (दिया)',
    whatsappReminder: 'Send WhatsApp Reminder',
    archivedAccounts: 'Settled Accounts (₹0 Balance)',
    
    // CA GST Hub
    gstr1Sales: 'Export GSTR-1 Sales (Excel/CSV)',
    gstr3bTax: 'Export GSTR-3B Tax Summary (PDF/Excel)',
    shareToCa: '1-Click Send Package to CA',
    
    // Templates
    invoiceTemplate: 'Invoice Template',
    templateNavy: 'Modern Navy Blue',
    templateMinimal: 'Minimal Gray Corporate',
    templateBold: 'Retail Bold Promo',
    templateThermal: 'Thermal Receipt (2"/3")',
    
    // Settings & Sign
    shopDetails: 'Shop Identity & Profile',
    signatureUpload: 'Digital Signature Uploader',
    removeBackground: 'Auto-Remove Signature Background',
    saveSettings: 'Save Settings',
  },
  hi: {
    appTitle: 'अमन गिफ्ट गैलरी',
    tagline: 'गिफ्ट, क्रॉकरी, खिलौने और होम एसेंशियल्स की एक्सक्लूसिव गैलरी',
    
    // Sidebar Navigation Labels
    pos: '🛒 नया बिल / Sale',
    dashboard: '📊 दुकान डैशबोर्ड / Brands',
    inventory: '📦 स्टॉक गोदाम / Inventory',
    purchases: '📥 माल खरीद / Purchase Inward',
    reports: '📑 GST & CA रिपोर्ट / Tax',
    khata: '📒 खाता & उधारी / Ledger',
    settings: '⚙️ दुकान सेटिंग्स / Settings',
    
    // Quick Actions / Header
    offlineMode: 'ऑफ़लाइन तैयार (IndexedDB)',
    onlineMode: 'कनेक्टेड',
    todaySales: 'आज की कुल बिक्री',
    todayProfit: 'आज का सकल मुनाफा',
    stockValuation: 'कुल स्टॉक मूल्यांकन',
    lowStockAlerts: 'कम स्टॉक अलर्ट्स',
    brandAnalytics: 'ब्रांड विश्लेषण',
    quickBill: 'नया बिल बनाएं',
    scanProduct: 'बारकोड स्कैन करें या नाम खोजें...',
    exchangeMode: 'एक्सचेंज मोड (बदलाव)',
    exitExchange: 'एक्सचेंज समाप्त करें',
    clearCart: 'कार्ट खाली करें',
    cashierProfitBox: 'कैशियर मुनाफा (निजी)',
    margin: 'मार्जिन',
    totalItems: 'कुल आइटम',
    subtotal: 'उप-योग',
    discount: 'छूट (डिस्काउंट)',
    taxGst: 'टैक्स (जीएसटी)',
    roundOff: 'राउंड ऑफ',
    grandTotal: 'कुल देय राशि',
    exchangeCredit: 'वापस किया गया सामान',
    netPayable: 'ग्राहक से लेना है',
    refundToCustomer: 'ग्राहक को वापस करना है',
    settleBill: 'बिल प्रिंट व सहेजें (F12)',
    
    // Customer
    customerInfo: 'ग्राहक विवरण (वैकल्पिक)',
    customerName: 'ग्राहक का नाम',
    customerPhone: 'मोबाइल नंबर',
    warranty: 'वारंटी',
    warrantyDuration: 'वारंटी अवधि',
    noWarranty: 'वारंटी नहीं',
    
    // Inventory
    allCategories: 'सभी श्रेणियां',
    allBrands: 'सभी ब्रांड्स',
    barcode: 'बारकोड',
    itemName: 'सामान का नाम',
    brand: 'ब्रांड',
    category: 'श्रेणी',
    stock: 'स्टॉक मात्रा',
    landingCost: 'लागत मूल्य (Landing Cost)',
    mrp: 'एमआरपी (MRP)',
    sellingPrice: 'बिक्री दर (Selling Rate)',
    action: 'कार्रवाई',
    addProduct: 'नया आइटम जोड़ें',
    deadStockTracker: 'डेड स्टॉक ट्रैकर (60+ दिन से बिक्री नहीं)',
    generateReorderList: 'सप्लायर री-ऑर्डर लिस्ट बनाएं',
    printBarcodeLabels: 'बारकोड स्टिकर प्रिंट करें',
    adjustWastage: 'डैमेज / टूट-फूट कटौती',
    
    // Purchases
    geminiOcrTitle: 'जेमिनी एआई चालान व बिल ओसीआर',
    uploadBillPhoto: 'बिल की फोटो अपलोड या खींचें',
    parseBillWithGemini: 'एआई से डेटा निकालें',
    sheetsSyncTitle: 'गूगल शीट्स 2-वे लाइव सिंक',
    syncNow: 'गूगल शीट्स में अभी सिंक करें',
    basicRate: 'मूल दर (Basic Rate)',
    gstPercent: 'जीएसटी %',
    totalAmount: 'कुल राशि',
    supplier: 'सप्लायर का नाम',
    voucherNo: 'बिल / वाउचर नंबर',
    
    // Khata
    customers: 'ग्राहक (Customers)',
    suppliers: 'सप्लायर (Suppliers)',
    totalReceivable: 'कुल लेना है (Receivable)',
    totalPayable: 'कुल देना है (Payable)',
    gotReceived: '+ आया / प्राप्त हुआ (Got)',
    gaveCredit: '- दिया / उधारी (Gave)',
    whatsappReminder: 'व्हाट्सएप पर तगादा भेजें',
    archivedAccounts: 'चुकता खाते (₹0 बैलेंस)',
    
    // CA GST Hub
    gstr1Sales: 'GSTR-1 सेल्स एक्सपोर्ट (एक्सेल)',
    gstr3bTax: 'GSTR-3B टैक्स सारांश (पीडीएफ)',
    shareToCa: '1-क्लिक में सीए को व्हाट्सएप भेजें',
    
    // Templates
    invoiceTemplate: 'इनवॉइस टेम्पलेट',
    templateNavy: 'मॉडर्न नेवी ब्लू',
    templateMinimal: 'मिनिमल ग्रे कॉर्पोरेट',
    templateBold: 'रिटेल बोल्ड प्रोमो',
    templateThermal: 'थर्मल पर्ची (2"/3")',
    
    // Settings & Sign
    shopDetails: 'दुकान का विवरण',
    signatureUpload: 'डिजिटल हस्ताक्षर अपलोडर',
    removeBackground: 'हस्ताक्षर का बैकग्राउंड हटाएं',
    saveSettings: 'सेटिंग्स सहेजें',
  }
};

export function getTranslation(lang: Language) {
  return translations[lang] || translations.en;
}
