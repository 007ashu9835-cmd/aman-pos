import { 
  MultiFormatReader, 
  BarcodeFormat, 
  DecodeHintType, 
  RGBLuminanceSource, 
  HybridBinarizer, 
  GlobalHistogramBinarizer,
  BinaryBitmap 
} from '@zxing/library';

// Setup ZXing MultiFormatReader configured for retail barcode formats
const createZXingReader = () => {
  const reader = new MultiFormatReader();
  const hints = new Map<DecodeHintType, any>();
  hints.set(DecodeHintType.POSSIBLE_FORMATS, [
    BarcodeFormat.EAN_13,
    BarcodeFormat.CODE_128,
    BarcodeFormat.UPC_A,
    BarcodeFormat.UPC_E,
    BarcodeFormat.CODE_39,
    BarcodeFormat.CODE_93,
    BarcodeFormat.EAN_8,
    BarcodeFormat.ITF,
    BarcodeFormat.QR_CODE,
    BarcodeFormat.DATA_MATRIX
  ]);
  hints.set(DecodeHintType.TRY_HARDER, true);
  reader.setHints(hints);
  return reader;
};

/**
 * Decodes barcode text from a canvas using ZXing with both Hybrid and Histogram binarizers.
 */
function decodeFromCanvas(canvas: HTMLCanvasElement, reader: MultiFormatReader): string | null {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;

  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imgData.data;
  const lumSource = new RGBLuminanceSource(
    new Uint8ClampedArray(data.buffer),
    canvas.width,
    canvas.height
  );

  // Pass 1: HybridBinarizer
  try {
    const bitmap = new BinaryBitmap(new HybridBinarizer(lumSource));
    const result = reader.decodeWithState(bitmap);
    if (result && result.getText()) {
      reader.reset();
      return result.getText();
    }
  } catch {
    reader.reset();
  }

  // Pass 2: GlobalHistogramBinarizer (better for uneven lighting or shadows)
  try {
    const bitmap = new BinaryBitmap(new GlobalHistogramBinarizer(lumSource));
    const result = reader.decodeWithState(bitmap);
    if (result && result.getText()) {
      reader.reset();
      return result.getText();
    }
  } catch {
    reader.reset();
  }

  return null;
}

/**
 * Loads a File or Blob into an HTMLImageElement safely.
 */
export function loadImageFromFile(file: File | Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(err);
    };
    img.src = url;
  });
}

/**
 * Plays an audible success or error beep using Web Audio API.
 */
export function playScanAudioTone(isSuccess = true): void {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const audioCtx = new AudioContextClass();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'sine';
    if (isSuccess) {
      // Crisp 2-tone chime for barcode success
      osc.frequency.setValueAtTime(1760, audioCtx.currentTime); // A6
      osc.frequency.setValueAtTime(2637, audioCtx.currentTime + 0.08); // E7
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.2);
    } else {
      // Low double buzz for failure
      osc.frequency.setValueAtTime(300, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    }
  } catch {
    // Audio tone ignored if blocked by browser policy
  }

  // Haptic feedback for mobile devices
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate(isSuccess ? [50, 40, 90] : [150, 50, 150]);
    } catch {}
  }
}

/**
 * Universal High-Precision Barcode Image Decoder:
 * Decodes barcode from File/Blob or Image with multi-tier processing:
 * 1. Native Web BarcodeDetector API (fastest GPU-accelerated)
 * 2. Full-image ZXing Dual-Binarizer
 * 3. Scaled down / normalized canvas pass
 * 4. Center Region of Interest (ROI) crop pass (for zoomed-in camera shots)
 * 5. High-contrast grayscale boosted pass
 */
export async function decodeBarcodeFromImage(fileOrImage: File | Blob | HTMLImageElement): Promise<string | null> {
  let img: HTMLImageElement;
  if (fileOrImage instanceof HTMLImageElement) {
    img = fileOrImage;
  } else {
    img = await loadImageFromFile(fileOrImage);
  }

  // Tier 1: Native BarcodeDetector API if supported
  if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
    try {
      const detector = new (window as any).BarcodeDetector({
        formats: [
          'ean_13',
          'code_128',
          'upc_a',
          'upc_e',
          'code_39',
          'code_93',
          'ean_8',
          'itf',
          'qr_code',
          'data_matrix'
        ]
      });
      const detected = await detector.detect(img);
      if (detected && detected.length > 0 && detected[0]?.rawValue) {
        return detected[0].rawValue.trim();
      }
    } catch {
      // Continue to Tier 2 ZXing
    }
  }

  const reader = createZXingReader();
  const natW = img.naturalWidth || img.width || 800;
  const natH = img.naturalHeight || img.height || 600;

  // Tier 2: Normal Direct Canvas Pass
  const canvas = document.createElement('canvas');
  canvas.width = natW;
  canvas.height = natH;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;

  ctx.drawImage(img, 0, 0, natW, natH);
  let code = decodeFromCanvas(canvas, reader);
  if (code) return code.trim();

  // Tier 3: Normalized Resized Canvas Pass (Ideal for high-res 12MP-48MP phone camera snaps)
  // Large phone camera photos are often 4000x3000px, which causes ZXing performance slowdowns
  // Resizing to max 1280px maintains sharp barcode edges while making decoding 5x faster and more accurate.
  const maxDim = 1280;
  if (natW > maxDim || natH > maxDim) {
    const scale = Math.min(maxDim / natW, maxDim / natH);
    const scaledW = Math.round(natW * scale);
    const scaledH = Math.round(natH * scale);

    const scaledCanvas = document.createElement('canvas');
    scaledCanvas.width = scaledW;
    scaledCanvas.height = scaledH;
    const sCtx = scaledCanvas.getContext('2d', { willReadFrequently: true });
    if (sCtx) {
      sCtx.imageSmoothingEnabled = true;
      sCtx.imageSmoothingQuality = 'high';
      sCtx.drawImage(img, 0, 0, scaledW, scaledH);
      code = decodeFromCanvas(scaledCanvas, reader);
      if (code) return code.trim();
    }
  }

  // Tier 4: Center ROI Crop (Users typically center the barcode in photo)
  const cropCanvas = document.createElement('canvas');
  const cropW = Math.floor(natW * 0.70);
  const cropH = Math.floor(natH * 0.60);
  const cropX = Math.floor((natW - cropW) / 2);
  const cropY = Math.floor((natH - cropH) / 2);

  cropCanvas.width = cropW;
  cropCanvas.height = cropH;
  const cCtx = cropCanvas.getContext('2d', { willReadFrequently: true });
  if (cCtx) {
    cCtx.drawImage(img, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
    code = decodeFromCanvas(cropCanvas, reader);
    if (code) return code.trim();
  }

  // Tier 5: High-Contrast Binarized / Grayscale Boost Pass
  const boostCanvas = document.createElement('canvas');
  boostCanvas.width = canvas.width;
  boostCanvas.height = canvas.height;
  const bCtx = boostCanvas.getContext('2d', { willReadFrequently: true });
  if (bCtx) {
    bCtx.drawImage(canvas, 0, 0);
    const imgData = bCtx.getImageData(0, 0, boostCanvas.width, boostCanvas.height);
    const d = imgData.data;
    // Contrast enhancement
    const factor = (259 * (128 + 255)) / (255 * (259 - 128));
    for (let i = 0; i < d.length; i += 4) {
      // Grayscale
      const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      const contrast = factor * (gray - 128) + 128;
      const clamped = Math.max(0, Math.min(255, contrast));
      d[i] = clamped;
      d[i + 1] = clamped;
      d[i + 2] = clamped;
    }
    bCtx.putImageData(imgData, 0, 0);
    code = decodeFromCanvas(boostCanvas, reader);
    if (code) return code.trim();
  }

  return null;
}
