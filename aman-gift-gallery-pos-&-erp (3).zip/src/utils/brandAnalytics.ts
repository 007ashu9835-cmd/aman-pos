import { Product, Invoice } from '../types';
import { BrandPerformanceData } from '../components/common/BrandDrilldownModal';

export function calculateBrandPerformance(
  products: Product[],
  invoices: Invoice[]
): BrandPerformanceData[] {
  const brandStatsMap: Record<string, BrandPerformanceData> = {};

  const now = new Date().getTime();

  // Initialize catalog entries
  for (const prod of products) {
    const b = (prod.brand || 'Unbranded').trim();
    const brandKey = b || 'Unbranded';

    if (!brandStatsMap[brandKey]) {
      brandStatsMap[brandKey] = {
        brand: brandKey,
        totalProducts: 0,
        totalStockUnits: 0,
        inventoryValuation: 0,
        estimatedRevenue: 0,
        totalUnitsSold: 0,
        totalSalesValue: 0,
        totalProfitContribution: 0,
        topModels: []
      };
    }

    brandStatsMap[brandKey].totalProducts += 1;
    brandStatsMap[brandKey].totalStockUnits += prod.stockQty;
    brandStatsMap[brandKey].inventoryValuation += (prod.landingCost * prod.stockQty);
    brandStatsMap[brandKey].estimatedRevenue += (prod.sellingPrice * prod.stockQty);

    // Calculate days since inward / creation / last sold
    const inwardTime = prod.createdAt ? new Date(prod.createdAt).getTime() : now;
    const daysSinceInward = Math.max(0, Math.floor((now - inwardTime) / (1000 * 60 * 60 * 24)));

    brandStatsMap[brandKey].topModels.push({
      id: prod.id,
      name: prod.name,
      barcode: prod.barcode,
      stock: prod.stockQty,
      price: prod.sellingPrice,
      mrp: prod.mrp,
      costPrice: prod.landingCost || prod.basicPurchaseRate,
      soldQty: 0,
      revenue: 0,
      profit: 0,
      daysSinceInward,
      lastSoldDate: prod.lastSoldDate
    });
  }

  // Aggregate actual sales and profits from invoices
  for (const inv of invoices) {
    const invoiceTime = inv.date ? new Date(inv.date).getTime() : now;

    for (const item of inv.items) {
      if (item.quantity <= 0) continue;
      const b = (item.product.brand || 'Unbranded').trim();
      const brandKey = b || 'Unbranded';

      if (!brandStatsMap[brandKey]) {
        brandStatsMap[brandKey] = {
          brand: brandKey,
          totalProducts: 0,
          totalStockUnits: 0,
          inventoryValuation: 0,
          estimatedRevenue: 0,
          totalUnitsSold: 0,
          totalSalesValue: 0,
          totalProfitContribution: 0,
          topModels: []
        };
      }

      const itemRate = item.customPrice ?? item.product.sellingPrice;
      const itemSellingTotal = itemRate * item.quantity;
      const itemCostRate = item.product.landingCost || item.product.basicPurchaseRate;
      const itemCostTotal = itemCostRate * item.quantity;
      const itemProfit = itemSellingTotal - itemCostTotal;

      brandStatsMap[brandKey].totalUnitsSold += item.quantity;
      brandStatsMap[brandKey].totalSalesValue += itemSellingTotal;
      brandStatsMap[brandKey].totalProfitContribution += itemProfit;

      let model = brandStatsMap[brandKey].topModels.find(
        m => (item.product.id && m.id === item.product.id) || m.name.toLowerCase() === item.product.name.toLowerCase()
      );

      if (model) {
        model.soldQty += item.quantity;
        model.revenue += itemSellingTotal;
        model.profit += itemProfit;
        if (inv.date && (!model.lastSoldDate || new Date(inv.date) > new Date(model.lastSoldDate))) {
          model.lastSoldDate = inv.date;
        }
      } else {
        const inwardTime = item.product.createdAt ? new Date(item.product.createdAt).getTime() : invoiceTime;
        const daysSinceInward = Math.max(0, Math.floor((now - inwardTime) / (1000 * 60 * 60 * 24)));

        brandStatsMap[brandKey].topModels.push({
          id: item.product.id,
          name: item.product.name,
          barcode: item.product.barcode,
          stock: item.product.stockQty || 0,
          price: itemRate,
          mrp: item.product.mrp || itemRate,
          costPrice: itemCostRate,
          soldQty: item.quantity,
          revenue: itemSellingTotal,
          profit: itemProfit,
          daysSinceInward,
          lastSoldDate: inv.date
        });
      }
    }
  }

  return Object.values(brandStatsMap);
}
