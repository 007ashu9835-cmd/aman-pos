import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  deleteDoc, 
  onSnapshot, 
  writeBatch,
  query,
  where,
  orderBy,
  limit,
  Unsubscribe
} from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { 
  getAuth, 
  signInAnonymously,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  updateProfile,
  User
} from 'firebase/auth';
import { Product, Invoice, ShopProfile } from '../types';
import firebaseConfigData from '../../firebase-applet-config.json';

// Initialize Firebase App
const firebaseConfig = {
  projectId: firebaseConfigData.projectId,
  appId: firebaseConfigData.appId,
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  storageBucket: firebaseConfigData.storageBucket || `${firebaseConfigData.projectId}.firebasestorage.app`,
  messagingSenderId: firebaseConfigData.messagingSenderId
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Target Firestore Database instance
const databaseId = firebaseConfigData.firestoreDatabaseId && firebaseConfigData.firestoreDatabaseId !== '(default)'
  ? firebaseConfigData.firestoreDatabaseId
  : undefined;

export const firestore = databaseId ? getFirestore(app, databaseId) : getFirestore(app);

// Initialize Firebase Cloud Storage
export const storage = getStorage(app);
export const auth = getAuth(app);

export const googleAuthProvider = new GoogleAuthProvider();

export interface CloudAccountProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  isAnonymous: boolean;
}

/**
 * Get active Firebase User UID and email metadata for scoping operations
 */
export function getActiveUserMeta(): { uid: string; userEmail: string } {
  const current = auth.currentUser;
  const uid = current && !current.isAnonymous ? current.uid : (localStorage.getItem('app_master_uid') || '007ashu9835_admin');
  const userEmail = current && !current.isAnonymous ? (current.email || '007ashu9835@gmail.com') : (localStorage.getItem('app_master_email') || '007ashu9835@gmail.com');
  return { uid, userEmail };
}

/**
 * Sign in with Master Email & Password for Cloud Data Sync.
 * If user is not found, automatically creates the account for a seamless login experience.
 */
export async function loginWithEmailCloud(email: string, pass: string): Promise<User> {
  const cleanEmail = email.trim().toLowerCase();
  try {
    const cred = await signInWithEmailAndPassword(auth, cleanEmail, pass);
    if (cred.user) {
      localStorage.setItem('app_master_uid', cred.user.uid);
      if (cred.user.email) localStorage.setItem('app_master_email', cred.user.email);
    }
    return cred.user;
  } catch (err: any) {
    const code = err?.code || '';
    // If user not found or invalid-credential on first login attempt, attempt seamless account registration
    if (code === 'auth/user-not-found' || code === 'auth/invalid-credential') {
      try {
        const newCred = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
        if (newCred.user) {
          await updateProfile(newCred.user, {
            displayName: cleanEmail.split('@')[0] || 'Store Admin'
          }).catch(() => {});
          localStorage.setItem('app_master_uid', newCred.user.uid);
          if (newCred.user.email) localStorage.setItem('app_master_email', newCred.user.email);
        }
        return newCred.user;
      } catch (regErr: any) {
        if (regErr?.code === 'auth/email-already-in-use') {
          throw err;
        }
        throw regErr;
      }
    }
    throw err;
  }
}

/**
 * Register new Cloud Sync account with Email & Password
 */
export async function registerWithEmailCloud(email: string, pass: string, displayName?: string): Promise<User> {
  const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
  if (displayName && cred.user) {
    await updateProfile(cred.user, { displayName });
  }
  if (cred.user) {
    localStorage.setItem('app_master_uid', cred.user.uid);
    if (cred.user.email) localStorage.setItem('app_master_email', cred.user.email);
  }
  return cred.user;
}

/**
 * Sign in with Google Account popup for Cloud Data Sync
 */
export async function loginWithGoogleCloud(): Promise<User> {
  googleAuthProvider.setCustomParameters({ prompt: 'select_account' });
  try {
    const result = await signInWithPopup(auth, googleAuthProvider);
    if (result.user) {
      localStorage.setItem('app_master_uid', result.user.uid);
      if (result.user.email) localStorage.setItem('app_master_email', result.user.email);
    }
    return result.user;
  } catch (err: any) {
    if (err?.code === 'auth/unauthorized-domain') {
      throw new Error('This domain is not authorized in Firebase Console. Please log in directly using Master Email & Password.');
    }
    throw err;
  }
}

/**
 * Sign out of current Cloud Account
 */
export async function logoutCloudUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (err) {
    console.warn('Firebase signOut error:', err);
  }
  localStorage.removeItem('firebase_cloud_authenticated');
  localStorage.removeItem('app_master_uid');
  localStorage.removeItem('app_master_email');
  localStorage.removeItem('cloud_user_account');
  localStorage.setItem('app_force_relogin', 'true');
  sessionStorage.clear();
}

/**
 * Send password reset email
 */
export async function sendCloudPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

/**
 * Listen for auth state changes
 */
export function subscribeToCloudAuthState(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, callback);
}

export const PRODUCTS_COLLECTION = 'products';
export const INVOICES_COLLECTION = 'invoices';
export const SETTINGS_COLLECTION = 'settings';

/**
 * Remove undefined values from objects before writing to Firestore
 */
function sanitizeForFirestore<T extends Record<string, any>>(obj: T): T {
  const clean: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (value && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date)) {
        clean[key] = sanitizeForFirestore(value);
      } else if (Array.isArray(value)) {
        clean[key] = value.map(item => (item && typeof item === 'object' ? sanitizeForFirestore(item) : item));
      } else {
        clean[key] = value;
      }
    }
  }
  return clean as T;
}

// ----------------------------------------------------
// Real-Time Subscriptions
// ----------------------------------------------------

/**
 * Subscribe to all products in Firestore with real-time updates
 */
export function subscribeToProducts(
  onUpdate: (products: Product[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const meta = getActiveUserMeta();
  const productsRef = query(collection(firestore, PRODUCTS_COLLECTION), where('ownerUid', '==', meta.uid));
  return onSnapshot(
    productsRef,
    (snapshot) => {
      const prods = snapshot.docs.map((docSnap, idx) => {
        const data = docSnap.data();
        const rawId = data.id !== undefined ? data.id : docSnap.id;
        const parsedNum = typeof rawId === 'number' ? rawId : parseInt(String(rawId).replace(/\D/g, ''), 10);
        const validId = typeof parsedNum === 'number' && !isNaN(parsedNum) && parsedNum > 0 ? parsedNum : (idx + 1);

        return {
          ...data,
          id: validId,
          barcode: data.barcode || data.sku || docSnap.id || `AGG-${10000 + idx}`,
          vendor: data.vendor || 'General'
        } as Product;
      });
      onUpdate(prods);
    },
    (err) => {
      console.warn('Firestore products listener warning:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Subscribe to all invoices in Firestore with real-time updates
 */
export function subscribeToInvoices(
  onUpdate: (invoices: Invoice[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const meta = getActiveUserMeta();
  const invoicesRef = query(collection(firestore, INVOICES_COLLECTION), where('ownerUid', '==', meta.uid));
  return onSnapshot(
    invoicesRef,
    (snapshot) => {
      const invs: Invoice[] = [];
      snapshot.docs.forEach((docSnap, idx) => {
        const data = docSnap.data();
        const rawId = data.id !== undefined ? data.id : undefined;
        const parsedNum = typeof rawId === 'number' ? rawId : (rawId ? parseInt(String(rawId).replace(/\D/g, ''), 10) : undefined);
        const validId = typeof parsedNum === 'number' && !isNaN(parsedNum) && parsedNum > 0 ? parsedNum : (idx + 1);

        invs.push({
          ...data,
          id: validId
        } as Invoice);
      });
      // Sort newest first
      invs.sort((a, b) => {
        const tA = new Date(a.createdAt || a.date).getTime() || 0;
        const tB = new Date(b.createdAt || b.date).getTime() || 0;
        return tB - tA;
      });
      onUpdate(invs);
    },
    (err) => {
      console.warn('Firestore invoices listener warning:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Subscribe to Master Categories
 */
export function subscribeToMasterCategories(
  onUpdate: (categories: string[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const meta = getActiveUserMeta();
  const catDocRef = doc(firestore, SETTINGS_COLLECTION, `masterCategories_${meta.uid}`);
  return onSnapshot(
    catDocRef,
    (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (Array.isArray(data?.categories)) {
          onUpdate(data.categories);
        }
      }
    },
    (err) => {
      console.warn('Firestore categories listener warning:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Subscribe to Shop Profile
 */
export function subscribeToShopProfile(
  onUpdate: (profile: ShopProfile) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const meta = getActiveUserMeta();
  const profileDocRef = doc(firestore, SETTINGS_COLLECTION, `shopProfile_${meta.uid}`);
  return onSnapshot(
    profileDocRef,
    (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data) {
          onUpdate(data as ShopProfile);
        }
      }
    },
    (err) => {
      console.warn('Firestore profile listener warning:', err);
      if (onError) onError(err);
    }
  );
}

// ----------------------------------------------------
// Product Cloud Operations
// ----------------------------------------------------

export async function saveProductToCloud(product: Product): Promise<void> {
  const meta = getActiveUserMeta();
  const docId = String(product.barcode || product.id || `PROD-${Date.now()}`);
  const clean = sanitizeForFirestore({
    ...product,
    ownerUid: meta.uid,
    userEmail: meta.userEmail,
    updatedAt: product.updatedAt || new Date().toISOString()
  });
  await setDoc(doc(firestore, PRODUCTS_COLLECTION, docId), clean, { merge: true });
}

export async function saveItemToDb(item: any): Promise<void> {
  const prod: Product = {
    id: typeof item.id === 'number' ? item.id : (parseInt(String(item.id).replace(/\D/g, ''), 10) || undefined),
    barcode: item.sku || item.barcode || String(item.id) || `AGG-${Date.now()}`,
    name: item['Item Name'] || item.name || 'Item',
    brand: item.brand || item.Brand || 'General',
    category: (item.Category || item.category || 'General') as any,
    hsn: item.hsn || item.HSN || '999999',
    stockQty: Number(item['Stock left '] || item['Stock left'] || item.stock || item.stockQty || 0),
    minThreshold: Number(item['Reorder Level'] || item.reorderLevel || item.minThreshold || 2),
    basicPurchaseRate: Number(item['purchase price'] || item.purchasePrice || item.basicPurchaseRate || 0),
    gstPercent: Number(item.gstPercent !== undefined ? item.gstPercent : (item.gst || 18)),
    landingCost: Number(item.landingCost || (Number(item['purchase price'] || item.purchasePrice || item.basicPurchaseRate || 0) * 1.18)),
    mrp: Number(item.MRP || item.mrp || (Number(item['purchase price'] || item.purchasePrice || item.basicPurchaseRate || 0) * 1.35) || 100),
    sellingPrice: Number(item.sellingPrice || item.MRP || item.mrp || (Number(item['purchase price'] || item.purchasePrice || item.basicPurchaseRate || 0) * 1.35) || 100),
    vendor: item.vendor || item.Vendor || item.supplier || item.Supplier || 'General',
    createdAt: item.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...(typeof item === 'object' ? item : {})
  };
  await saveProductToCloud(prod);
}

export const addItem = saveItemToDb;
export const saveItemToCloudDb = saveItemToDb;

export async function bulkSaveProductsToCloud(products: Product[]): Promise<void> {
  const meta = getActiveUserMeta();
  const chunks: Product[][] = [];
  const chunkSize = 400; // Firestore batch limit is 500
  for (let i = 0; i < products.length; i += chunkSize) {
    chunks.push(products.slice(i, i + chunkSize));
  }

  for (const chunk of chunks) {
    const batch = writeBatch(firestore);
    for (const prod of chunk) {
      const docId = String(prod.barcode || prod.id || `PROD-${Date.now()}-${Math.random()}`);
      const clean = sanitizeForFirestore({
        ...prod,
        ownerUid: meta.uid,
        userEmail: meta.userEmail,
        vendor: prod.vendor || 'General',
        updatedAt: prod.updatedAt || new Date().toISOString()
      });
      batch.set(doc(firestore, PRODUCTS_COLLECTION, docId), clean, { merge: true });
    }
    await batch.commit();
  }
}

export async function batchSaveToInventory(
  formattedInventory: Array<{
    id?: string | number;
    name: string;
    category?: string;
    purchasePrice?: number;
    stock?: number;
    stockQty?: number;
    reorderLevel?: number;
    minThreshold?: number;
    sku?: string;
    barcode?: string;
    mrp?: number;
    brand?: string;
    vendor?: string;
    supplier?: string;
    [key: string]: any;
  }>
): Promise<void> {
  const converted: Product[] = formattedInventory.map((item, idx) => ({
    id: typeof item.id === 'number' ? item.id : (parseInt(String(item.id).replace(/\D/g, ''), 10) || idx + 1),
    barcode: item.sku || item.barcode || String(item.id) || `AGG-${10000 + idx}`,
    name: item.name || 'Item',
    brand: item.brand || 'General',
    category: (item.category || 'General') as any,
    vendor: item.vendor || item.Vendor || item.supplier || item.Supplier || 'General',
    hsn: item.hsn || '999999',
    stockQty: item.stock !== undefined ? Number(item.stock) : (item.stockQty !== undefined ? Number(item.stockQty) : 0),
    minThreshold: item.reorderLevel !== undefined ? Number(item.reorderLevel) : (item.minThreshold !== undefined ? Number(item.minThreshold) : 2),
    basicPurchaseRate: Number(item.purchasePrice || item.basicPurchaseRate || 0),
    gstPercent: item.gstPercent !== undefined ? Number(item.gstPercent) : 18,
    landingCost: Number(item.landingCost || (Number(item.purchasePrice || 0) * 1.18)),
    mrp: Number(item.mrp || (Number(item.purchasePrice || 0) * 1.35) || 100),
    sellingPrice: Number(item.sellingPrice || item.mrp || (Number(item.purchasePrice || 0) * 1.35) || 100),
    createdAt: item.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }));

  await bulkSaveProductsToCloud(converted);
}

export async function writeBatchToCloud(
  data: { products?: Product[]; invoices?: Invoice[]; parsedProductsList?: Product[]; sales?: any } | Product[]
): Promise<void> {
  if (Array.isArray(data)) {
    await bulkSaveProductsToCloud(data);
    return;
  }
  if (data.products && data.products.length > 0) {
    await bulkSaveProductsToCloud(data.products);
  } else if (data.parsedProductsList && data.parsedProductsList.length > 0) {
    await bulkSaveProductsToCloud(data.parsedProductsList);
  }
  if (data.invoices && data.invoices.length > 0) {
    await bulkSaveInvoicesToCloud(data.invoices);
  }
}

export async function deleteProductFromCloud(productIdOrBarcode: string | number): Promise<void> {
  const docId = String(productIdOrBarcode);
  await deleteDoc(doc(firestore, PRODUCTS_COLLECTION, docId));
}

// ----------------------------------------------------
// Invoice & Sales Cloud Operations
// ----------------------------------------------------

export async function saveInvoiceToCloud(invoice: Invoice): Promise<void> {
  const meta = getActiveUserMeta();
  const docId = String(invoice.invoiceNumber || `INV-${Date.now()}`);
  const clean = sanitizeForFirestore({
    ...invoice,
    ownerUid: meta.uid,
    userEmail: meta.userEmail,
    createdAt: invoice.createdAt || new Date().toISOString()
  });
  await setDoc(doc(firestore, INVOICES_COLLECTION, docId), clean, { merge: true });
}

export async function bulkSaveInvoicesToCloud(invoices: Invoice[]): Promise<void> {
  const meta = getActiveUserMeta();
  const chunks: Invoice[][] = [];
  const chunkSize = 400;
  for (let i = 0; i < invoices.length; i += chunkSize) {
    chunks.push(invoices.slice(i, i + chunkSize));
  }

  for (const chunk of chunks) {
    const batch = writeBatch(firestore);
    for (const inv of chunk) {
      const docId = String(inv.invoiceNumber || `INV-${Date.now()}-${Math.random()}`);
      const clean = sanitizeForFirestore({
        ...inv,
        ownerUid: meta.uid,
        userEmail: meta.userEmail,
        createdAt: inv.createdAt || new Date().toISOString()
      });
      batch.set(doc(firestore, INVOICES_COLLECTION, docId), clean, { merge: true });
    }
    await batch.commit();
  }
}

export async function deleteInvoiceFromCloud(invoiceNumber: string): Promise<void> {
  await deleteDoc(doc(firestore, INVOICES_COLLECTION, invoiceNumber));
}

// ----------------------------------------------------
// Settings & Categories Cloud Operations
// ----------------------------------------------------

export async function saveCategoriesToCloud(categories: string[]): Promise<void> {
  const meta = getActiveUserMeta();
  const clean = sanitizeForFirestore({
    categories,
    ownerUid: meta.uid,
    userEmail: meta.userEmail,
    updatedAt: new Date().toISOString()
  });
  await setDoc(doc(firestore, SETTINGS_COLLECTION, `masterCategories_${meta.uid}`), clean, { merge: true });
}

export async function saveShopProfileToCloud(profile: ShopProfile): Promise<void> {
  const meta = getActiveUserMeta();
  const clean = sanitizeForFirestore({
    ...profile,
    ownerUid: meta.uid,
    userEmail: meta.userEmail,
    updatedAt: new Date().toISOString()
  });
  await setDoc(doc(firestore, SETTINGS_COLLECTION, `shopProfile_${meta.uid}`), clean, { merge: true });
}

// ----------------------------------------------------
// Fetch Full Collections (Pull from Cloud)
// ----------------------------------------------------

export async function fetchAllProductsFromCloud(): Promise<Product[]> {
  try {
    const meta = getActiveUserMeta();
    const snapshot = await getDocs(query(collection(firestore, PRODUCTS_COLLECTION), where('ownerUid', '==', meta.uid)));
    const prods: Product[] = [];
    snapshot.docs.forEach((docSnap, idx) => {
      const data = docSnap.data();
      const rawId = data.id !== undefined ? data.id : docSnap.id;
      const parsedNum = typeof rawId === 'number' ? rawId : parseInt(String(rawId).replace(/\D/g, ''), 10);
      const validId = typeof parsedNum === 'number' && !isNaN(parsedNum) && parsedNum > 0 ? parsedNum : (idx + 1);

      prods.push({
        ...data,
        id: validId,
        barcode: data.barcode || data.sku || docSnap.id || `AGG-${10000 + idx}`,
        vendor: data.vendor || 'General'
      } as Product);
    });
    return prods;
  } catch (err: any) {
    console.warn('fetchAllProductsFromCloud notice (offline or empty):', err?.message || err);
    return [];
  }
}

export async function fetchAllInvoicesFromCloud(): Promise<Invoice[]> {
  try {
    const meta = getActiveUserMeta();
    const snapshot = await getDocs(query(collection(firestore, INVOICES_COLLECTION), where('ownerUid', '==', meta.uid)));
    const invs: Invoice[] = [];
    snapshot.docs.forEach((docSnap, idx) => {
      const data = docSnap.data();
      const rawId = data.id !== undefined ? data.id : undefined;
      const parsedNum = typeof rawId === 'number' ? rawId : (rawId ? parseInt(String(rawId).replace(/\D/g, ''), 10) : undefined);
      const validId = typeof parsedNum === 'number' && !isNaN(parsedNum) && parsedNum > 0 ? parsedNum : (idx + 1);

      invs.push({
        ...data,
        id: validId
      } as Invoice);
    });
    return invs;
  } catch (err: any) {
    console.warn('fetchAllInvoicesFromCloud notice (offline or empty):', err?.message || err);
    return [];
  }
}

export async function fetchInvoiceByNumber(invoiceNumber: string): Promise<Invoice | null> {
  try {
    const docRef = doc(firestore, INVOICES_COLLECTION, invoiceNumber);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        ...data,
        id: data.id ? Number(data.id) : undefined
      } as Invoice;
    }
    return null;
  } catch (err: any) {
    console.warn('fetchInvoiceByNumber notice:', err?.message || err);
    return null;
  }
}

export async function fetchMasterCategoriesFromCloud(): Promise<string[] | null> {
  try {
    const meta = getActiveUserMeta();
    const docSnap = await getDoc(doc(firestore, SETTINGS_COLLECTION, `masterCategories_${meta.uid}`));
    if (docSnap.exists()) {
      const data = docSnap.data();
      if (Array.isArray(data?.categories)) {
        return data.categories;
      }
    }
    return null;
  } catch (err: any) {
    console.warn('fetchMasterCategoriesFromCloud notice (offline or empty):', err?.message || err);
    return null;
  }
}

export async function fetchShopProfileFromCloud(): Promise<ShopProfile | null> {
  try {
    const meta = getActiveUserMeta();
    const docSnap = await getDoc(doc(firestore, SETTINGS_COLLECTION, `shopProfile_${meta.uid}`));
    if (docSnap.exists()) {
      return docSnap.data() as ShopProfile;
    }
    return null;
  } catch (err: any) {
    console.warn('fetchShopProfileFromCloud notice (offline or empty):', err?.message || err);
    return null;
  }
}

/**
 * Uploads an invoice PDF Blob directly to Firebase Storage and returns its public download URL.
 */
export async function uploadInvoicePdfToFirebaseStorage(
  pdfBlob: Blob,
  invoiceNumber: string
): Promise<string> {
  const cleanInvNum = (invoiceNumber || 'INV-001').replace(/[^a-zA-Z0-9_-]/g, '_');
  const uniqueId = Math.random().toString(36).substring(2, 8);
  const fileName = `invoices/${cleanInvNum}_${Date.now()}_${uniqueId}.pdf`;
  const storageRef = ref(storage, fileName);

  const metadata = {
    contentType: 'application/pdf',
    customMetadata: {
      invoiceNumber: cleanInvNum,
      uploadedAt: new Date().toISOString()
    }
  };

  await uploadBytes(storageRef, pdfBlob, metadata);
  const downloadUrl = await getDownloadURL(storageRef);
  return downloadUrl;
}

/**
 * Permanently deletes all products and invoices from Firestore and resets categories.
 */
export async function clearAllCloudData(): Promise<void> {
  try {
    const meta = getActiveUserMeta();
    // 1. Delete all products from Firestore
    const productsSnapshot = await getDocs(query(collection(firestore, PRODUCTS_COLLECTION), where('ownerUid', '==', meta.uid)));
    const productDocs = productsSnapshot.docs;
    for (let i = 0; i < productDocs.length; i += 400) {
      const batch = writeBatch(firestore);
      productDocs.slice(i, i + 400).forEach(d => batch.delete(d.ref));
      await batch.commit();
    }

    // 2. Delete all invoices from Firestore
    const invoicesSnapshot = await getDocs(query(collection(firestore, INVOICES_COLLECTION), where('ownerUid', '==', meta.uid)));
    const invoiceDocs = invoicesSnapshot.docs;
    for (let i = 0; i < invoiceDocs.length; i += 400) {
      const batch = writeBatch(firestore);
      invoiceDocs.slice(i, i + 400).forEach(d => batch.delete(d.ref));
      await batch.commit();
    }

    // 3. Reset categories in Firestore
    await setDoc(doc(firestore, SETTINGS_COLLECTION, `masterCategories_${meta.uid}`), {
      categories: [],
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.warn('Error clearing cloud Firestore data:', err);
  }
}

